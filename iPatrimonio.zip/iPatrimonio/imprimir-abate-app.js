﻿function ImprimirAbateApp() {
  const [abate, setAbate] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const abateId = urlParams.get('id');
    if (!abateId) {
      window.location.href = 'ver-abate.html';
      return;
    }
    loadAbate(abateId);
  }, []);

  async function loadAbate(abateId) {
    try {
      const result = await dbGetObject('abate', abateId);
      if (!result || !result.objectData) {
        window.location.href = 'ver-abate.html';
        return;
      }
      setAbate(result);
      setTimeout(() => window.print(), 500);
    } catch (error) {
      console.error('Error loading abate:', error);
      window.location.href = 'ver-abate.html';
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <div className="text-center py-8">Carregando...</div>;
  if (!abate) return <div className="text-center py-8">Abate não encontrado</div>;

  return (
    <div className="max-w-4xl mx-auto">
      <button onClick={() => window.print()} className="no-print mb-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Imprimir</button>
      
      <div className="border-2 border-gray-800 p-8">
        <div className="text-center mb-6">
          <img src="assets/logo.png" alt="UCM Logo" className="h-16 mx-auto mb-2" />
          <h1 className="text-2xl font-bold">UNIVERSIDADE CATÓLICA DE MOÇAMBIQUE</h1>
          <h2 className="text-xl font-semibold">FACULDADE DE DIREITO</h2>
          <h3 className="text-lg font-semibold mt-4">TERMO DE ABATE DE BEM</h3>
        </div>

        <div className="space-y-4 mb-6">
          <div><strong>Descrição do Bem:</strong> {abate.objectData.descricaoBem}</div>

          <div className="grid grid-cols-2 gap-4">
            <div><strong>Cor:</strong> {abate.objectData.cor || '-'}</div>
            <div><strong>Estado do Bem:</strong> {abate.objectData.estadoBem}</div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div><strong>Data Aquisição:</strong> {new Date(abate.objectData.dataAquisicao).toLocaleDateString('pt-BR')}</div>
            <div><strong>Valor Aquisição:</strong> {parseFloat(abate.objectData.valorAquisicao).toFixed(2)} MT</div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div><strong>Localização:</strong> {abate.objectData.localizacao}</div>
            <div><strong>Valor Atual:</strong> {parseFloat(abate.objectData.valor).toFixed(2)} MT</div>
          </div>

          <div><strong>Data do Abate:</strong> {new Date(abate.objectData.dataAbate).toLocaleDateString('pt-BR')}</div>

          <div><strong>Motivo do Abate:</strong><br/>{abate.objectData.motivoAbate}</div>

          {abate.objectData.observacoes && (
            <div><strong>Observações:</strong><br/>{abate.objectData.observacoes}</div>
          )}

          <div><strong>Responsável:</strong> {abate.objectData.responsavel}</div>
        </div>

        <div className="mt-12 flex justify-around items-end">
          <div className="text-center">
            <div className="mt-16 inline-block w-64">
              <div className="border-t-2 border-gray-800 pt-1">
                <p className="text-sm font-signature text-xl">{abate.objectData.responsavel}</p>
              </div>
              <p className="text-xs text-gray-600 mt-1">Assinatura do Responsável</p>
              <p className="text-xs text-gray-600">{abate.objectData.responsavel}</p>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-sm text-gray-600">
          <p>Nampula, {new Date(abate.objectData.dataAbate).toLocaleDateString('pt-BR')}</p>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ImprimirAbateApp />);