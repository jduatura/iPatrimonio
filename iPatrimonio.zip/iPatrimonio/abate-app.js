function AbateApp() {
  const [user, setUser] = React.useState(null);
  const [showForm, setShowForm] = React.useState(false);
  const [abates, setAbates] = React.useState([]);
  const [alert, setAlert] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    
    // Apenas Patrimonio ou Administracao podem acessar
    const isAdministracao = currentUser.department === 'Administração';
    if (currentUser.role !== 'patrimonio' && !isAdministracao) {
      window.location.href = 'dashboard.html';
      return;
    }
    
    setUser(currentUser);
    loadAbates();
  }, []);

  async function loadAbates() {
    try {
      const result = await dbListObjects('abate', 100, true);
      setAbates(result.items || []);
    } catch (error) {
      console.error('Error loading abates:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete(abateId) {
    if (!confirm('Tem certeza que deseja excluir este registro de abate?')) return;
    
    try {
      await dbDeleteObject('abate', abateId);
      setAlert({ type: 'success', message: 'Abate excluído com sucesso!' });
      loadAbates();
    } catch (error) {
      setAlert({ type: 'error', message: 'Erro ao excluir abate' });
    }
  }

  if (loading) return <div className="text-center py-8">Carregando...</div>;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      <main className="flex-grow p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <button
              onClick={() => window.location.href = 'dashboard.html'}
              className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
            >
              <div className="icon-arrow-left text-lg"></div>
              <span>Voltar</span>
            </button>
            <h1 className="text-3xl font-bold">Abate de Bens</h1>
            <p className="text-gray-600">Registre e gerencie o abate de bens patrimoniais</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="btn btn-primary flex items-center gap-2"
          >
            <div className="icon-plus text-lg"></div>
            <span>Novo Abate</span>
          </button>
        </div>

        {showForm && <AbateForm user={user} onClose={() => { setShowForm(false); loadAbates(); }} setAlert={setAlert} />}

        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="p-4 border-b">
            <h2 className="text-xl font-semibold">Registros de Abate</h2>
          </div>
          {abates.length === 0 ? (
            <p className="text-gray-500 p-4">Nenhum registro de abate encontrado</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nº Guia</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Descrição</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Localização</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valor</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Data</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {abates.map((abate) => (
                    <tr key={abate.objectId}>
                      <td className="px-4 py-3">{abate.objectData.numeroGuia || '-'}</td>
                      <td className="px-4 py-3 max-w-xs truncate" title={abate.objectData.descricaoBem}>{abate.objectData.descricaoBem}</td>
                      <td className="px-4 py-3">{abate.objectData.estadoBem}</td>
                      <td className="px-4 py-3">{abate.objectData.localizacao}</td>
                      <td className="px-4 py-3">{parseFloat(abate.objectData.valor).toFixed(2)} MT</td>
                      <td className="px-4 py-3">{new Date(abate.objectData.dataAbate).toLocaleDateString('pt-BR')}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => window.open(`imprimir-abate.html?id=${abate.objectId}`, '_blank')} className="text-blue-600 hover:text-blue-800 mr-3" title="Imprimir">
                          <div className="icon-printer text-lg"></div>
                        </button>
                        <button onClick={() => handleDelete(abate.objectId)} className="text-red-600 hover:text-red-800" title="Excluir">
                          <div className="icon-trash-2 text-lg"></div>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
      {alert && <Alert message={alert.message} type={alert.type} onClose={() => setAlert(null)} />}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<AbateApp />);