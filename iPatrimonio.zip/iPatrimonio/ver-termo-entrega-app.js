function VerTermoEntregaApp() {
  const [user, setUser] = React.useState(null);
  const [termos, setTermos] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [searchTerm, setSearchTerm] = React.useState('');

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    // Allow admin and Administração department
    if (currentUser.role !== 'admin' && currentUser.department !== 'Administração') {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadTermos();
  }, []);

  const loadTermos = async () => {
    try {
      const result = await dbListObjects('termo_entrega', 100, true);
      setTermos(result.items || []);
    } catch (error) {
      console.error('Error loading termos:', error);
      setTermos([]);
    } finally {
      setLoading(false);
    }
  };

  const filteredTermos = termos.filter(termo => {
    const search = searchTerm.toLowerCase();
    const data = termo.objectData;
    const departamento = data.departamento || '';
    const responsavel = data.responsavelRecebimento || data.responsavelEntrega || '';
    return departamento.toLowerCase().includes(search) ||
           responsavel.toLowerCase().includes(search);
  });

  if (!user) return null;

  return (
    <div className="bg-gray-100 min-h-screen flex flex-col">
      <Header user={user} />
      
      <main className="flex-grow p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-800">Ver Termos de Entrega</h1>
            <button onClick={() => window.location.href = 'dashboard.html'} className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300">
              Voltar
            </button>
          </div>

          <div className="card mb-6">
            <input
              type="text"
              placeholder="Pesquisar por departamento ou responsável..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-field"
            />
          </div>

          {loading ? (
            <div className="card text-center py-12">
              <p className="text-gray-500 text-lg">Carregando...</p>
            </div>
          ) : filteredTermos.length === 0 ? (
            <div className="card text-center py-12">
              <div className="icon-inbox text-5xl text-gray-300 mx-auto mb-4 w-fit"></div>
              <p className="text-gray-500 text-lg">Nenhum termo encontrado</p>
            </div>
          ) : (
            <div className="card">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Departamento</th>
                      <th className="text-left py-3 px-4">Recebido Por</th>
                      <th className="text-left py-3 px-4">Data Entrega</th>
                      <th className="text-left py-3 px-4">N° Termo</th>
                      <th className="text-left py-3 px-4">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTermos.map(termo => {
                      const data = termo.objectData.dataEntrega ? new Date(termo.objectData.dataEntrega) : null;
                      const dataFormatada = data && !isNaN(data.getTime()) 
                        ? data.toLocaleDateString('pt-BR')
                        : '-';
                      
                      return (
                        <tr key={termo.objectId} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4">{termo.objectData.departamento || '-'}</td>
                          <td className="py-3 px-4">{termo.objectData.responsavelRecebimento || '-'}</td>
                          <td className="py-3 px-4">{dataFormatada}</td>
                          <td className="py-3 px-4">N° {termo.objectData.numeroTermo || '-'}</td>
                          <td className="py-3 px-4">
                            <button
                              onClick={() => window.open(`imprimir-termo.html?id=${termo.objectId}`, '_blank')}
                              className="text-blue-600 hover:text-blue-800 font-medium"
                            >
                              Ver Detalhes
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<VerTermoEntregaApp />);

