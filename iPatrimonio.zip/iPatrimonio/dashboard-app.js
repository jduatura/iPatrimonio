function DashboardApp() {
  try {
    const [user, setUser] = React.useState(null);

    React.useEffect(() => {
      const currentUser = getCurrentUser();
      if (!currentUser) {
        window.location.href = 'login.html';
        return;
      }
      setUser(currentUser);
    }, []);

    const handleLogout = () => {
      logout();
    };

    if (!user) return null;

    const isAdministracao = user.department === 'Administração';

    return (
      <div className="bg-gray-100 min-h-screen flex flex-col" data-name="dashboard-app" data-file="dashboard-app.js">
        <header className="bg-white shadow-md py-3 md:py-4">
          <div className="px-4 md:px-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div className="flex items-center space-x-3 md:space-x-4">
              <img src="assets/logo.png" alt="UCM Logo" className="h-10 md:h-12 w-auto" />
              <div>
                <h1 className="text-lg md:text-2xl font-semibold text-[var(--primary-color)]">iPatrimônio</h1>
                <p className="text-xs md:text-sm text-gray-600">UCM - FADIR</p>
              </div>
            </div>
            <div className="flex items-center gap-2 md:gap-3 w-full sm:w-auto justify-end">
              <NotificationCenter user={user} />
              
              <button 
                onClick={() => window.location.href = 'profile.html'}
                className="bg-blue-100 text-blue-600 w-9 h-9 md:w-10 md:h-10 rounded-full flex items-center justify-center font-bold text-base md:text-lg hover:bg-blue-200 transition" 
                title="Meu Perfil"
              >
                {user.name.charAt(0).toUpperCase()}
              </button>

              <button 
                onClick={handleLogout}
                className="flex items-center gap-1.5 md:gap-2 bg-red-600 text-white px-2.5 py-1.5 md:px-3 rounded-lg font-medium hover:bg-red-700 transition text-xs md:text-sm"
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" className="w-4 h-4 md:w-5 md:h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6A2.25 2.25 0 005.25 5.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9" />
                </svg>
                <span className="hidden sm:inline">Sair</span>
              </button>
            </div>
          </div>
        </header>

        <main className="flex-grow">
          {user.role === 'admin' && <AdminDashboard user={user} />}
          {user.role === 'patrimonio' && <PatrimonioDashboard user={user} />}
          {(user.role === 'tecnico' || user.department === 'Manutenção') && <TecnicoDashboard user={user} />}
          {isAdministracao && user.role !== 'admin' && user.role !== 'tecnico' && <AdministracaoDashboard user={user} />}
          {!isAdministracao && user.role !== 'admin' && user.role !== 'patrimonio' && user.role !== 'tecnico' && user.department !== 'Manutenção' && <UserDashboard user={user} />}
        </main>

        <footer className="bg-white py-2 md:py-3 text-center text-gray-500 text-xs md:text-sm border-t">
          © <span id="year"></span> - iPatrimônio | UCM-FADIR
        </footer>
      </div>
    );
  } catch (error) {
    console.error('DashboardApp error:', error);
    return null;
  }
}

function AdminDashboard({ user }) {
  const menuItems = [
    { icon: '👥', label: 'Usuários', route: 'usuarios.html' },
    { icon: '🏢', label: 'Departamentos', route: 'departamentos.html' },
    { icon: '📋', label: 'Logs de Auditoria', route: 'logs-auditoria.html' },
    { icon: '💾', label: 'Backup', route: 'backup.html' }
  ];

  return (
    <main className="flex flex-col items-center justify-center flex-grow px-4 text-center py-6 md:py-10">
      <h2 className="text-lg md:text-xl font-semibold text-gray-800 mb-3 md:mb-4">
        Bem-vindo(a), {user.name}!
      </h2>
      <p className="text-sm md:text-base text-gray-500 mb-6 md:mb-8">Administrador do Sistema - Selecione uma opção abaixo.</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 max-w-4xl w-full">
        {menuItems.map((item, idx) => (
          <button
            key={idx}
            onClick={() => window.location.href = item.route}
            className="bg-white shadow-md hover:shadow-lg p-5 md:p-6 rounded-xl border hover:border-indigo-500 transition flex flex-col items-center justify-center cursor-pointer"
          >
            <div className="text-3xl md:text-4xl mb-2 md:mb-3">{item.icon}</div>
            <p className="text-sm md:text-base text-gray-700 font-medium">{item.label}</p>
          </button>
        ))}
      </div>
    </main>
  );
}

function AdministracaoDashboard({ user }) {
  const menuItems = [
    { icon: '👥', label: 'Gestão de Usuários', route: 'usuarios.html' },
    { icon: '🏢', label: 'Departamentos', route: 'departamentos.html' },
    { icon: '💼', label: 'Gestão de Bens', route: 'bens.html' },
    { icon: '🛠️', label: 'Gestão de Manutenção', route: 'manutencao.html' },
    { icon: '➕', label: 'Nova Requisição', route: 'nova-requisicao.html' },
    { icon: '📋', label: 'Requisições', route: 'requisicoes.html' },
    { icon: '📄', label: 'Minhas Requisições', route: 'minhas-requisicoes.html' },
    { icon: '🔍', label: 'Pesquisar Bens', route: 'pesquisar-bens.html' },
    { icon: '🔄', label: 'Movimentação', route: 'movimentacao.html' },
    { icon: '📤', label: 'Controle de Saída', route: 'mapa-controle-saida.html' },
    { icon: '📝', label: 'Termo de Entrega', route: 'termo-entrega.html' },
    { icon: '❌', label: 'Abate de Bens', route: 'abate.html' },
    { icon: '📊', label: 'Relatórios', route: 'relatorios.html' }
  ];

  return (
    <main className="flex flex-col items-center justify-center flex-grow px-4 text-center py-6 md:py-10">
      <h2 className="text-lg md:text-xl font-semibold text-gray-800 mb-3 md:mb-4">
        Bem-vindo(a), {user.name}!
      </h2>
      <p className="text-sm md:text-base text-gray-500 mb-6 md:mb-8">Departamento de Administração - Selecione uma opção abaixo.</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 max-w-5xl w-full">
        {menuItems.map((item, idx) => (
          <button
            key={idx}
            onClick={() => window.location.href = item.route}
            className="bg-white shadow-md hover:shadow-lg p-5 md:p-6 rounded-xl border hover:border-indigo-500 transition flex flex-col items-center justify-center cursor-pointer"
          >
            <div className="text-3xl md:text-4xl mb-2 md:mb-3">{item.icon}</div>
            <p className="text-sm md:text-base text-gray-700 font-medium">{item.label}</p>
          </button>
        ))}
      </div>
    </main>
  );
}

function PatrimonioDashboard({ user }) {
  const menuItems = [
    { icon: '💼', label: 'Gestão de Bens', route: 'bens.html' },
    { icon: '🛠️', label: 'Gestão de Manutenção', route: 'manutencao.html' },
    { icon: '➕', label: 'Nova Requisição', route: 'nova-requisicao.html' },
    { icon: '📋', label: 'Requisições', route: 'requisicoes-patrimonio.html' },
    { icon: '📄', label: 'Minhas Requisições', route: 'minhas-requisicoes.html' },
    { icon: '🔍', label: 'Pesquisar Bens', route: 'pesquisar-bens.html' },
    { icon: '🔄', label: 'Movimentação', route: 'movimentacao.html' },
    { icon: '📤', label: 'Controle de Saída', route: 'mapa-controle-saida.html' },
    { icon: '📝', label: 'Termo de Entrega', route: 'termo-entrega.html' },
    { icon: '❌', label: 'Abate de Bens', route: 'abate.html' },
    { icon: '📊', label: 'Relatórios', route: 'relatorios.html' }
  ];

  return (
    <main className="flex flex-col items-center justify-center flex-grow px-4 text-center py-6 md:py-10">
      <h2 className="text-lg md:text-xl font-semibold text-gray-800 mb-3 md:mb-4">
        Bem-vindo(a), {user.name}!
      </h2>
      <p className="text-sm md:text-base text-gray-500 mb-6 md:mb-8">Selecione uma das opções abaixo para continuar.</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 max-w-6xl w-full">
        {menuItems.map((item, idx) => (
          <button
            key={idx}
            onClick={() => window.location.href = item.route}
            className="bg-white shadow-md hover:shadow-lg p-5 md:p-6 rounded-xl border hover:border-indigo-500 transition flex flex-col items-center justify-center cursor-pointer"
          >
            <div className="text-3xl md:text-4xl mb-2 md:mb-3">{item.icon}</div>
            <p className="text-sm md:text-base text-gray-700 font-medium">{item.label}</p>
          </button>
        ))}
      </div>
    </main>
  );
}

function TecnicoDashboard({ user }) {
  const menuItems = [
    { icon: '🛠️', label: 'Painel de Manutenção', route: 'manutencao.html' },
    { icon: '➕', label: 'Reportar Avaria', route: 'manutencao.html?action=reportar' },
    { icon: '📄', label: 'Minhas Requisições', route: 'minhas-requisicoes.html' }
  ];

  return (
    <main className="flex flex-col items-center justify-center flex-grow px-4 text-center py-6 md:py-10">
      <h2 className="text-lg md:text-xl font-semibold text-gray-800 mb-3 md:mb-4">
        Bem-vindo(a), {user.name}!
      </h2>
      <p className="text-sm md:text-base text-gray-500 mb-6 md:mb-8">Equipa Técnica de Manutenção - Ordens de Trabalho e Diagnósticos.</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6 max-w-4xl w-full">
        {menuItems.map((item, idx) => (
          <button
            key={idx}
            onClick={() => window.location.href = item.route}
            className="bg-white shadow-md hover:shadow-lg p-5 md:p-6 rounded-xl border hover:border-blue-500 transition flex flex-col items-center justify-center cursor-pointer"
          >
            <div className="text-3xl md:text-4xl mb-2 md:mb-3">{item.icon}</div>
            <p className="text-sm md:text-base text-gray-700 font-medium">{item.label}</p>
          </button>
        ))}
      </div>
    </main>
  );
}

function UserDashboard({ user }) {
  const menuItems = [
    { icon: '➕', label: 'Nova Requisição', route: 'nova-requisicao.html' },
    { icon: '📋', label: 'Minhas Requisições', route: 'minhas-requisicoes.html' },
    { icon: '🛠️', label: 'Reportar Avaria / Manutenção', route: 'manutencao.html' }
  ];

  return (
    <main className="flex flex-col items-center justify-center flex-grow px-4 text-center py-6 md:py-10">
      <h2 className="text-lg md:text-xl font-semibold text-gray-800 mb-3 md:mb-4">
        Bem-vindo(a), {user.name}!
      </h2>
      <p className="text-sm md:text-base text-gray-500 mb-6 md:mb-8">Selecione uma das opções abaixo para continuar.</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 max-w-5xl w-full">
        {menuItems.map((item, idx) => (
          <button
            key={idx}
            onClick={() => window.location.href = item.route}
            className="bg-white shadow-md hover:shadow-lg p-5 md:p-6 rounded-xl border hover:border-indigo-500 transition flex flex-col items-center justify-center cursor-pointer"
          >
            <div className="text-3xl md:text-4xl mb-2 md:mb-3">{item.icon}</div>
            <p className="text-sm md:text-base text-gray-700 font-medium">{item.label}</p>
          </button>
        ))}
      </div>
    </main>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<DashboardApp />);

// Atualizar ano no rodapé
setTimeout(() => {
  const yearElement = document.getElementById('year');
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }
}, 100);


