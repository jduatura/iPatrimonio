function ImprimirMovimentacaoApp() {
  const [movimentacao, setMovimentacao] = React.useState(null);
  const [user, setUser] = React.useState(null);

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'index.html';
      return;
    }
    setUser(currentUser);

    const urlParams = new URLSearchParams(window.location.search);
    const movId = urlParams.get('id');
    if (movId) {
      loadMovimentacao(movId);
    }
  }, []);

  const loadMovimentacao = async (id) => {
    try {
      const mov = await dbGetObject('movimentacao', id);
      setMovimentacao(mov);
    } catch (error) {
      console.error('Error loading movimentacao:', error);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (!movimentacao || !user) {
    return <div className="text-center py-8">Carregando...</div>;
  }

  const data = movimentacao.objectData;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="no-print mb-4 flex justify-end gap-2">
        <button onClick={handlePrint} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
          Imprimir
        </button>
        <button onClick={() => window.close()} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300">
          Fechar
        </button>
      </div>

      <div className="border-2 border-gray-300 p-8">
        <div className="flex items-start gap-4 mb-6 border-b pb-4">
          <img src="assets/logo.png" alt="UCM Logo" className="h-16" />
          <div className="flex-1">
            <h1 className="text-xl font-bold">UNIVERSIDADE CATÓLICA DE MOÇAMBIQUE</h1>
            <h2 className="text-lg font-semibold">Faculdade de Direito</h2>
            <p className="text-sm mt-2">Av. 25 de Setembro, 618</p>
            <p className="text-sm">C.P. 48-Nampula-Moçambique</p>
            <p className="text-sm">Tel: (+258) 26 21 61 77 | Fax: (+258) 26 21 57 65</p>
            <p className="text-sm">E-mail: fdir@ucm.ac.mz</p>
          </div>
        </div>

        <div className="mb-6">
          <p className="text-sm mb-2">Nampula, {new Date(data.dataMovimentacao).toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
          <p className="text-sm mb-4">
            <strong>Do:</strong> Departamento de Património e Aprovisionamento<br/>
            <strong>Ref. N°</strong> {data.numeroReferencia}
          </p>
          <p className="text-sm font-bold mb-2">Assunto: Pedido de Movimentação de Bens</p>
        </div>

        <div className="mb-6 text-sm">
          <p className="mb-4">
            O Departamento do Património e Aprovisionamento da Faculdade de Direito, vem por este meio, 
            informar as seguintes movimentações do <strong>{data.departamentoOrigem}</strong> para 
            a <strong>{data.departamentoDestino}</strong>, para os devidos efeitos:
          </p>
          
          <ul className="list-none space-y-1 mb-4">
            {data.bensMovimentados && data.bensMovimentados.map((bem, idx) => (
              <li key={idx}>✓ {bem.quantidade} {bem.bemNome}</li>
            ))}
          </ul>

          <p className="mb-8">Sem mais de momento, cordiais saudações.</p>
        </div>

        <div className="grid grid-cols-3 gap-6 mt-12 text-xs">
          <div className="border border-gray-200 rounded-lg p-4 bg-gray-50/50 text-center flex flex-col justify-between">
            <div>
              <span className="inline-block w-2 h-2 rounded-full bg-[var(--primary-color)] mb-1"></span>
              <p className="font-bold text-[var(--primary-color)] uppercase tracking-wider text-[11px]">Verificado pelo Património</p>
            </div>
            <div className="mt-8 pt-2 border-t-2 border-gray-400">
              <p className="font-signature text-xl" style={{ color: '#1e40af', fontFamily: "'Dancing Script', 'Brush Script MT', cursive" }}>
                {user.name}
              </p>
              <p className="text-[10px] text-gray-500 uppercase tracking-wider mt-1">Nome & Assinatura</p>
            </div>
          </div>

          <div className="border border-gray-200 rounded-lg p-4 bg-gray-50/50 text-center flex flex-col justify-between">
            <div>
              <span className="inline-block w-2 h-2 rounded-full bg-gray-500 mb-1"></span>
              <p className="font-bold text-gray-700 uppercase tracking-wider text-[11px]">Recebido no Destino</p>
            </div>
            <div className="mt-8 pt-2 border-t-2 border-gray-400">
              <p className="font-signature text-xl" style={{ color: '#374151', fontFamily: "'Dancing Script', 'Brush Script MT', cursive" }}>
                {data.responsavelDestino || data.departamentoDestino}
              </p>
              <p className="text-[10px] text-gray-500 uppercase tracking-wider mt-1">Nome & Assinatura</p>
            </div>
          </div>

          <div className="border border-gray-200 rounded-lg p-4 bg-gray-50/50 text-center flex flex-col justify-between">
            <div>
              <span className="inline-block w-2 h-2 rounded-full bg-gray-500 mb-1"></span>
              <p className="font-bold text-gray-700 uppercase tracking-wider text-[11px]">Autorizado pela Administração</p>
            </div>
            <div className="mt-8 pt-2 border-t-2 border-gray-400">
              <p className="font-signature text-xl" style={{ color: '#374151', fontFamily: "'Dancing Script', 'Brush Script MT', cursive" }}>
                Administração FADIR
              </p>
              <p className="text-[10px] text-gray-500 uppercase tracking-wider mt-1">Assinatura & Carimbo</p>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-4 border-t text-xs text-gray-600 text-center">
          <p>Universidade Católica de Moçambique (Sede central)</p>
          <p>Rua Comandante Gaivão 688 CP 821-Beira-Moçambique</p>
          <p>Tel: (+258) 23 324809 | Fax: (+258) 23 324858</p>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ImprimirMovimentacaoApp />);

