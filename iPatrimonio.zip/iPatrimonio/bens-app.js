function BensApp() {
  const [user, setUser] = React.useState(null);
  const [bens, setBens] = React.useState([]);
  const [showModal, setShowModal] = React.useState(false);
  const [editingBem, setEditingBem] = React.useState(null);
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');
  const [selectedBem, setSelectedBem] = React.useState(null);
  const [isScannerOpen, setIsScannerOpen] = React.useState(false);
  
  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    const isAdministracao = currentUser.department === 'Administração';
    if (currentUser.role !== 'patrimonio' && !isAdministracao) {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadBens();

    // Se houver parâmetro de código na URL
    const urlParams = new URLSearchParams(window.location.search);
    const codeParam = urlParams.get('code') || urlParams.get('codigo');
    if (codeParam) {
      dbListObjects('bem', 1000).then(result => {
        const match = (result.items || []).find(b => b.objectData.codigo === codeParam);
        if (match) setSelectedBem(match.objectData);
      });
    }
  }, []);

  const loadBens = async () => {
    const result = await dbListObjects('bem', 100);
    setBens(result.items);
  };

  const handleScanSuccess = (scannedData) => {
    setIsScannerOpen(false);
    if (scannedData) {
      let scannedCode = scannedData;
      try {
        const url = new URL(scannedData);
        scannedCode = url.searchParams.get('codigo') || url.searchParams.get('code') || scannedData;
      } catch (e) {
        // Not a URL, use as is
      }
      
      const match = bens.find(b => b.objectData.codigo === scannedCode);
      if (match) {
        setSelectedBem(match.objectData);
      } else {
        setAlertMessage(`Bem com o código ${scannedCode} não foi encontrado.`);
        setAlertType('error');
        setShowAlert(true);
      }
    }
  };

  const loadDepartamentos = async () => {
    try {
      const result = await listDepartamentosUnique();
      if (result && result.items && result.items.length > 0) {
        const deptNames = result.items.map(dept => dept.objectData.nome);
        return deptNames;
      }
      return [];
    } catch (error) {
      console.error('Error loading departments:', error);
      return [];
    }
  };

  const handleAddBem = async (bemData) => {
    if (editingBem) {
      const bem = await dbGetObject('bem', editingBem.objectId);
      await dbUpdateObject('bem', editingBem.objectId, {
        ...bemData,
        codigo: bem.objectData.codigo,
        createdAt: bem.objectData.createdAt
      });
      await logAuditAction(AUDIT_ACTIONS.EDITAR_BEM, `Bem editado: ${bemData.nome} (${bem.objectData.codigo})`, user);
      setAlertMessage('Bem atualizado com sucesso!');
      setAlertType('success');
      setShowAlert(true);
      setShowModal(false);
      setEditingBem(null);
      loadBens();
    } else {
      const checkResult = await dbListObjects('bem', 1000);
      const codigoExists = checkResult.items.some(b => b.objectData.codigo === bemData.codigo);
      
      if (codigoExists) {
        setAlertMessage('Já existe um bem cadastrado com este código!');
        setAlertType('error');
        setShowAlert(true);
        return;
      }
      const quantidade = parseInt(bemData.quantidade) || 1;
      
      const result = await dbListObjects('bem', 1000);
      const prefix = bemData.codigo.substring(0, 2);
      const existingCodes = result.items
        .map(b => b.objectData.codigo)
        .filter(c => c && c.startsWith(prefix))
        .map(c => {
          const match = c.match(/\d+$/);
          return match ? parseInt(match[0]) : 0;
        })
        .filter(n => !isNaN(n));
      
      const maxNumber = existingCodes.length > 0 ? Math.max(...existingCodes) : 0;
      
      for (let i = 0; i < quantidade; i++) {
        const sequentialNumber = maxNumber + i + 1;
        const codigoUnico = `${prefix}-${String(sequentialNumber).padStart(4, '0')}`;
        await dbCreateObject('bem', {
          ...bemData,
          codigo: codigoUnico,
          quantidade: 1
        });
      }
      await logAuditAction(AUDIT_ACTIONS.CRIAR_BEM, `${quantidade} bem(ns) cadastrado(s): ${bemData.nome}`, user);
      
      // Process pending requests for this item
      if (typeof processPendingRequests === 'function') {
        await processPendingRequests(bemData.nome, bemData.departamento);
      }
      
      setAlertMessage(`${quantidade} bem(ns) cadastrado(s) com sucesso!`);
      setAlertType('success');
      setShowAlert(true);
      setShowModal(false);
      setEditingBem(null);
      await loadBens();
    }
  };

  const handleEditBem = (bem) => {
    setEditingBem(bem);
    setShowModal(true);
  };

  const handlePrintEtiqueta = (bemData) => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Etiqueta - ${bemData.codigo}</title>
        <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
        <style>
          @page { size: 10cm 5cm; margin: 0; }
          body { 
            margin: 0; 
            padding: 0.4cm;
            font-family: Arial, sans-serif;
          }
          .etiqueta {
            width: 9.2cm;
            height: 4.2cm;
            border: 2px solid #000;
            padding: 0.3cm;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
          }
          .header {
            text-align: center;
            border-bottom: 1px solid #000;
            padding-bottom: 0.1cm;
            margin-bottom: 0.2cm;
          }
          .header h3 {
            margin: 0;
            font-size: 11pt;
            font-weight: bold;
          }
          .body-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 0.3cm;
          }
          .content {
            font-size: 9pt;
            flex: 1;
          }
          .content p {
            margin: 0.1cm 0;
          }
          .qr-container {
            width: 80px;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
          }
        </style>
      </head>
      <body>
        <div class="etiqueta">
          <div class="header">
            <h3>UCM - FADIR PATRIMÔNIO</h3>
          </div>
          <div class="body-content">
            <div class="content">
              <p><strong>Código:</strong> ${bemData.codigo}</p>
              <p><strong>Nº Inv:</strong> ${bemData.numeroInventario || 'N/A'}</p>
              <p><strong>Descrição:</strong> ${bemData.nome}</p>
              <p><strong>Depto:</strong> ${bemData.departamento || 'N/A'}</p>
            </div>
            <div id="qrcode" class="qr-container"></div>
          </div>
        </div>
        <script>
          const origin = window.location.origin + window.location.pathname.replace('/bens.html', '');
          const qrUrl = origin + "/bens.html?codigo=" + "${bemData.codigo}";
          new QRCode(document.getElementById("qrcode"), {
            text: qrUrl,
            width: 80,
            height: 80
          });
          setTimeout(function() {
            window.print();
            window.close();
          }, 400);
        </script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingBem(null);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} currentPage="bens" />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      <main className="flex-grow p-4 md:p-6">
        <button
          onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
        >
          <div className="icon-arrow-left text-lg"></div>
          <span>Voltar</span>
        </button>
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 mb-4 md:mb-6">
          <h1 className="text-xl md:text-3xl font-bold">Gestão de Bens</h1>
          <div className="flex gap-2">
            <button 
              onClick={() => setIsScannerOpen(true)} 
              className="btn bg-blue-600 text-white hover:bg-blue-700 flex items-center gap-1.5 text-sm md:text-base"
              title="Escanear QR Code com a câmera"
            >
              <div className="icon-qr-code text-base md:text-lg"></div>
              <span>Escanear QR</span>
            </button>
            <button onClick={() => setShowModal(true)} className="btn btn-primary flex items-center gap-1.5 md:gap-2 text-sm md:text-base">
              <div className="icon-plus text-base md:text-lg"></div>
              <span>Cadastrar Bem</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {bens.map(bem => (
            <BemCard key={bem.objectId} bem={bem} onEdit={handleEditBem} onPrintEtiqueta={handlePrintEtiqueta} onViewDetails={(bData) => setSelectedBem(bData)} />
          ))}
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
      {showModal && <BemModal onClose={handleCloseModal} onSave={handleAddBem} editingBem={editingBem} />}
      {selectedBem && <BemDetailCard bem={selectedBem} onClose={() => setSelectedBem(null)} />}
      <QRScannerModal 
        isOpen={isScannerOpen} 
        onClose={() => setIsScannerOpen(false)} 
        onScanSuccess={handleScanSuccess} 
      />
    </div>
  );
}

function BemCard({ bem, onEdit, onPrintEtiqueta, onViewDetails }) {
  const [expanded, setExpanded] = React.useState(false);
  const bemData = bem.objectData;
  const statusColors = {
    disponivel: 'bg-blue-50 text-[var(--primary-color)] border border-blue-200',
    em_uso: 'bg-gray-50 text-gray-700 border border-gray-200',
    manutencao: 'bg-gray-200 text-gray-800 border border-gray-300',
    ABATIDO: 'bg-red-50 text-red-700 border border-red-200 font-bold'
  };

  const estadoColors = {
    bom: 'bg-blue-50 text-[var(--primary-color)] border border-blue-200',
    razoavel: 'bg-gray-50 text-gray-700 border border-gray-200',
    estragado: 'bg-red-50 text-red-700 border border-red-200',
    ABATIDO: 'bg-red-50 text-red-700 border border-red-200 font-bold'
  };

  return (
    <div className="card">
      <div className="flex flex-col gap-3 mb-4">
        <div className="flex items-start gap-3 cursor-pointer" onClick={() => onViewDetails && onViewDetails(bemData)}>
          <div className="w-20 h-20 rounded-lg flex items-center justify-center overflow-hidden border-2 bg-gray-100 flex-shrink-0" 
            style={{
              borderColor: bemData.foto ? '#e5e7eb' : '#3b82f6'
            }}>
            {bemData.foto ? (
              <img src={bemData.foto} alt={bemData.nome} className="w-full h-full object-cover" />
            ) : (
              <div className="icon-package text-2xl text-blue-600"></div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-base mb-1 break-words hover:text-blue-600 transition">{bemData.nome}</h3>
            <p className="text-xs text-gray-500 mb-2">Código: {bemData.codigo}</p>
            <div className="flex flex-wrap items-center gap-1.5">
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[bemData.status]}`}>
                {bemData.status === 'ABATIDO' ? 'Abatido' : bemData.status === 'disponivel' ? 'Disponível' : bemData.status === 'em_uso' ? 'Em Uso' : 'Manutenção'}
              </span>
              {bemData.estadoConservacao && (
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${estadoColors[bemData.estadoConservacao]}`}>
                  {bemData.estadoConservacao === 'ABATIDO' ? 'Abatido' : bemData.estadoConservacao === 'bom' ? 'Bom' : 
                   bemData.estadoConservacao === 'razoavel' ? 'Razoável' : 'Avariado'}
                </span>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={() => onViewDetails && onViewDetails(bemData)}
            className="flex-1 flex items-center justify-center gap-1 px-2.5 py-2 bg-gray-100 text-gray-800 rounded-lg hover:bg-gray-200 transition"
            title="Ver estado e localização"
          >
            <div className="icon-eye text-sm"></div>
            <span className="text-xs font-medium">Detalhes</span>
          </button>
          <button
            onClick={() => onEdit(bem)}
            className="flex-1 flex items-center justify-center gap-1 px-2.5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
          >
            <div className="icon-edit text-sm"></div>
            <span className="text-xs font-medium">Editar</span>
          </button>
          <button
            onClick={() => onPrintEtiqueta(bemData)}
            className="flex-1 flex items-center justify-center gap-1 px-2.5 py-2 bg-[var(--primary-color)] text-white rounded-lg hover:bg-[var(--secondary-color)] transition"
          >
            <div className="icon-tag text-sm"></div>
            <span className="text-xs font-medium">Etiqueta</span>
          </button>
        </div>
      </div>

      <div className="mb-3 pb-3 border-b">
        <span className="text-gray-500 text-xs">Número de Elemento:</span>
        <p className="font-bold text-purple-700 text-sm break-all">{bemData.numeroElemento || 'N/A'}</p>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
        <div>
          <span className="text-gray-500 text-xs">Marca:</span>
          <p className="font-medium">{bemData.marca || 'N/A'}</p>
        </div>
        <div>
          <span className="text-gray-500 text-xs">Modelo:</span>
          <p className="font-medium">{bemData.modelo || 'N/A'}</p>
        </div>
        <div>
          <span className="text-gray-500 text-xs">Categoria:</span>
          <p className="font-medium">{bemData.categoria || 'N/A'}</p>
        </div>
        <div>
          <span className="text-gray-500 text-xs">N° Série:</span>
          <p className="font-medium">{bemData.numeroSerie || 'N/A'}</p>
        </div>
        <div>
          <span className="text-gray-500 text-xs">N° Inventário:</span>
          <p className="font-medium">{bemData.numeroInventario || 'N/A'}</p>
        </div>
        <div>
          <span className="text-gray-500 text-xs">Fornecedor:</span>
          <p className="font-medium">{bemData.fornecedor || 'N/A'}</p>
        </div>
        <div className="sm:col-span-2">
          <span className="text-gray-500 text-xs">Cores:</span>
          <div className="flex flex-wrap gap-1 mt-1">
            {bemData.cor && bemData.cor.trim() ? bemData.cor.split(',').map((cor, idx) => (
              <span key={idx} className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded text-xs font-medium">
                {cor.trim()}
              </span>
            )) : <span className="font-medium">N/A</span>}
          </div>
        </div>
        <div>
          <span className="text-gray-500 text-xs">Departamento:</span>
          <p className="font-medium break-words">{bemData.departamento || 'N/A'}</p>
        </div>
        <div>
          <span className="text-gray-500 text-xs">Localização:</span>
          <p className="font-medium break-words">{bemData.localizacao || bemData.departamento || 'Instalações UCM-FADIR'}</p>
        </div>
        <div className="sm:col-span-2 bg-blue-50 rounded-lg p-3 border border-blue-200">
          <span className="text-gray-600 text-xs font-medium">Responsável:</span>
          <p className="font-bold text-blue-900 text-sm mt-1 break-words">{bemData.responsavelAtual || 'N/A'}</p>
        </div>
        <div className="bg-gray-50 rounded-lg p-2 border border-gray-200">
          <span className="text-gray-600 text-xs">Valor Original:</span>
          <p className="font-bold text-gray-800 text-sm">{bemData.preco ? `${parseFloat(bemData.preco).toFixed(2)} MZN` : 'N/A'}</p>
        </div>
        <div className="bg-gray-50 rounded-lg p-2 border border-gray-200">
          <span className="text-gray-600 text-xs">Valor Atual:</span>
          <p className="font-bold text-gray-800 text-sm">
            {bemData.valorAtual && bemData.valorAtual !== '0' ? 
              `${parseFloat(bemData.valorAtual).toFixed(2)} MZN` : 
              bemData.preco ? `${parseFloat(bemData.preco).toFixed(2)} MZN` : 'N/A'}
          </p>
        </div>
        <div>
          <span className="text-gray-500 text-xs">Data Aquisição:</span>
          <p className="font-medium text-sm">{bemData.dataAquisicao ? new Date(bemData.dataAquisicao).toLocaleDateString('pt-BR') : 'N/A'}</p>
        </div>
        <div>
          <span className="text-gray-500 text-xs">Ano:</span>
          <p className="font-medium text-base">{bemData.dataAquisicao ? new Date(bemData.dataAquisicao).getFullYear() : 'N/A'}</p>
        </div>
      </div>

      <button
        onClick={() => setExpanded(!expanded)}
        className="mt-4 w-full text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center justify-center gap-1 py-2 border-t"
      >
        {expanded ? 'Ver menos detalhes' : 'Ver todos os detalhes'}
        <div className={`icon-chevron-down text-sm transition-transform ${expanded ? 'rotate-180' : ''}`}></div>
      </button>

      {expanded && (
        <div className="mt-3 pt-3 border-t grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <span className="text-gray-500 text-xs">Edifício:</span>
            <p className="font-medium break-words">{bemData.edificio || 'N/A'}</p>
          </div>
          <div>
            <span className="text-gray-500 text-xs">Piso:</span>
            <p className="font-medium">{bemData.piso || 'N/A'}</p>
          </div>
          <div>
            <span className="text-gray-500 text-xs">Sala:</span>
            <p className="font-medium break-words">{bemData.sala || 'N/A'}</p>
          </div>
          <div>
            <span className="text-gray-500 text-xs">Serviço:</span>
            <p className="font-medium break-words">{bemData.servico || 'N/A'}</p>
          </div>
          <div>
            <span className="text-gray-500 text-xs">N° Inventário:</span>
            <p className="font-medium">{bemData.numeroInventario || 'N/A'}</p>
          </div>
          <div>
            <span className="text-gray-500 text-xs">Fornecedor:</span>
            <p className="font-medium break-words">{bemData.fornecedor || 'N/A'}</p>
          </div>
          <div>
            <span className="text-gray-500 text-xs">Classificação:</span>
            <p className="font-medium">{bemData.classificacao || 'N/A'}</p>
          </div>
        </div>
      )}
    </div>
  );
}

function BemModal({ onClose, onSave, editingBem }) {
  const [isGeneratingCode, setIsGeneratingCode] = React.useState(false);
  const [usuarios, setUsuarios] = React.useState([]);
  const [departamentos, setDepartamentos] = React.useState([]);
  
  const generateUniqueCode = async () => {
    setIsGeneratingCode(true);
    try {
      const result = await dbListObjects('bem', 1000);
      const prefix = '702172700';
      const existingCodes = result.items
        .map(b => b.objectData.codigo)
        .filter(c => c && c.startsWith(prefix))
        .map(c => {
          const suffix = c.replace(prefix, '');
          return suffix ? parseInt(suffix) : 0;
        })
        .filter(c => !isNaN(c));
      const maxSuffix = existingCodes.length > 0 ? Math.max(...existingCodes) : 0;
      const newCode = prefix + (maxSuffix + 1).toString().padStart(4, '0');
      
      // Generate inventory number automatically
      const existingInventoryNumbers = result.items
        .map(b => b.objectData.numeroInventario)
        .filter(n => n && !isNaN(parseInt(n)))
        .map(n => parseInt(n))
        .filter(n => !isNaN(n));
      const maxInventoryNumber = existingInventoryNumbers.length > 0 ? Math.max(...existingInventoryNumbers) : 22614;
      const newInventoryNumber = (maxInventoryNumber + 1).toString();
      
      setFormData(prev => ({...prev, codigo: newCode, numeroInventario: newInventoryNumber}));
    } catch (error) {
      console.error('Error generating code:', error);
    }
    setIsGeneratingCode(false);
  };

  React.useEffect(() => {
    if (!editingBem) {
      generateUniqueCode();
    }
    loadUsuarios();
    loadDepartamentosForModal();
  }, []);

  const loadUsuarios = async () => {
    try {
      const result = await dbListObjects('usuario', 100);
      setUsuarios(result.items);
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  // Helper: monta string de localização a partir dos dados do departamento
  const buildLocalizacao = (dept) => {
    if (!dept || !dept.objectData) return '';
    // Departamentos têm o campo direto 'localizacao',
    // diferente dos bens que podem ter edifício/sala/piso independentes.
    return dept.objectData.localizacao || '';
  };

  const loadDepartamentosForModal = async () => {
    try {
      const result = await listDepartamentosUnique();
      if (result && result.items && result.items.length > 0) {
        const deptNames = result.items.map(dept => dept.objectData.nome);
        setDepartamentos(deptNames);

        // Se já há um departamento selecionado (modo edição ou pré-seleção),
        // busca a localização automaticamente
        const currentDept = formData.departamento;
        if (currentDept && !formData.localizacao) {
          const dept = result.items.find(d => d.objectData.nome === currentDept);
          if (dept) {
            const localizacao = buildLocalizacao(dept);
            if (localizacao) {
              setFormData(prev => ({...prev, localizacao}));
            }
          }
        }
      }
    } catch (error) {
      console.error('Error loading departments:', error);
    }
  };

  const [cores, setCores] = React.useState(
    editingBem && editingBem.objectData.cor 
      ? editingBem.objectData.cor.split(',').map(c => c.trim())
      : []
  );
  const [corInput, setCorInput] = React.useState('');
  const [photoPreview, setPhotoPreview] = React.useState(editingBem ? editingBem.objectData.foto : '');

  React.useEffect(() => {
    if (editingBem && editingBem.objectData.foto) {
      setPhotoPreview(editingBem.objectData.foto);
    }
  }, [editingBem]);

  function validateImageUrl(url) {
    if (!url) return true;
    try {
      const urlObj = new URL(url);
      const pathname = urlObj.pathname.toLowerCase();
      const imagePattern = /\.(jpg|jpeg|png|gif|webp|bmp)$/i;
      return imagePattern.test(pathname) || url.startsWith('data:image/');
    } catch {
      return url.startsWith('data:image/');
    }
  }

  function handlePhotoUrlChange(e) {
    const url = e.target.value.trim();
    setFormData({...formData, foto: url});
    
    if (!url) {
      setPhotoPreview('');
      setErrors({...errors, foto: ''});
      return;
    }
    
    if (validateImageUrl(url)) {
      setPhotoPreview(url);
      setErrors({...errors, foto: ''});
    } else {
      setPhotoPreview('');
      setErrors({...errors, foto: 'URL de imagem inválida. Use formatos: JPG, PNG, GIF, WEBP'});
    }
  }

  function handlePhotoFileChange(e) {
    const file = e.target.files[0];
    if (file) {
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        setErrors({...errors, foto: 'Tipo de arquivo inválido. Use: JPG, PNG, GIF, WEBP'});
        e.target.value = '';
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        setErrors({...errors, foto: 'Arquivo muito grande. Tamanho máximo: 5MB'});
        e.target.value = '';
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({...formData, foto: reader.result});
        setPhotoPreview(reader.result);
        setErrors({...errors, foto: ''});
      };
      reader.readAsDataURL(file);
    }
  }

  const [formData, setFormData] = React.useState(
    editingBem ? {
      codigo: editingBem.objectData.codigo,
      nome: editingBem.objectData.nome,
      numeroElemento: editingBem.objectData.numeroElemento || `ELEM-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      marca: editingBem.objectData.marca || '',
      modelo: editingBem.objectData.modelo || '',
      numeroSerie: editingBem.objectData.numeroSerie || '',
      preco: editingBem.objectData.preco,
      descricao: editingBem.objectData.descricao,
      categoria: editingBem.objectData.categoria,
      departamento: editingBem.objectData.departamento || '',
      localizacao: editingBem.objectData.localizacao || '',
      dataAquisicao: editingBem.objectData.dataAquisicao || '',
      dataUtilizacao: editingBem.objectData.dataUtilizacao || '',
      dataInventario: editingBem.objectData.dataInventario || '',
      fornecedor: editingBem.objectData.fornecedor || '',
      status: editingBem.objectData.status,
      responsavelAtual: editingBem.objectData.responsavelAtual || '',
      historicoMovimentacao: editingBem.objectData.historicoMovimentacao || [],
      foto: editingBem.objectData.foto || '',
      cor: editingBem.objectData.cor || '',

      estadoConservacao: editingBem.objectData.estadoConservacao || 'bom',
      valorAtual: editingBem.objectData.valorAtual || editingBem.objectData.preco || '',
      quantidade: editingBem.objectData.quantidade || 1,

      edificio: editingBem.objectData.edificio || '',
      piso: editingBem.objectData.piso || '',
      sala: editingBem.objectData.sala || '',
      servico: editingBem.objectData.servico || '',
      classificacao: editingBem.objectData.classificacao || '',
      taxa: editingBem.objectData.taxa || '',
      classe: editingBem.objectData.classe || '',
      investimento: editingBem.objectData.investimento || '',
      numeroInventario: editingBem.objectData.numeroInventario || '',
      financiamento: editingBem.objectData.financiamento || '',
      percentualFinanciamento: editingBem.objectData.percentualFinanciamento || '100',
      planoFinanceiro: editingBem.objectData.planoFinanceiro || '',
      enquadramento: editingBem.objectData.enquadramento || '',
      taxaManual: editingBem.objectData.taxaManual || '0.00',
      contaInvestimento: editingBem.objectData.contaInvestimento || '',
      descricaoContaInvestimento: editingBem.objectData.descricaoContaInvestimento || '',

      atividade: editingBem.objectData.atividade || '702-Faculdade de Direito',
      estabelecimento: editingBem.objectData.estabelecimento || '',
      observacoes: editingBem.objectData.observacoes || ''
    } : {
      codigo: '',
      nome: '',
      numeroElemento: `ELEM-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      marca: '',
      modelo: '',
      numeroSerie: '',
      preco: '',
      descricao: '',
      categoria: '',
      departamento: '',
      localizacao: '',
      dataAquisicao: '',
      dataUtilizacao: '',
      dataInventario: '',
      fornecedor: '',
      status: 'disponivel',
      responsavelAtual: '',
      historicoMovimentacao: [],
      foto: '',
      cor: '',

      estadoConservacao: 'bom',
      valorAtual: '',
      quantidade: 1,

      edificio: '',
      piso: '',
      sala: '',
      servico: '',
      classificacao: '',
      taxa: '',
      classe: '',
      investimento: '',
      numeroInventario: '',
      financiamento: '',
      percentualFinanciamento: '100',
      planoFinanceiro: '',
      enquadramento: '',
      taxaManual: '0.00',
      contaInvestimento: '',
      descricaoContaInvestimento: '',

      atividade: '702-Faculdade de Direito',
      estabelecimento: '',
      observacoes: ''
    }
  );

  const [errors, setErrors] = React.useState({});

  function handlePhotoFileChange(e) {
    const file = e.target.files[0];
    if (file) {
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        setErrors({...errors, foto: 'Tipo de arquivo inválido. Use: JPG, PNG, GIF, WEBP'});
        e.target.value = '';
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        setErrors({...errors, foto: 'Arquivo muito grande. Tamanho máximo: 5MB'});
        e.target.value = '';
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({...formData, foto: reader.result});
        setPhotoPreview(reader.result);
        setErrors({...errors, foto: ''});
      };
      reader.readAsDataURL(file);
    }
  }

  const handleAddCor = () => {
    if (corInput.trim() && !cores.includes(corInput.trim())) {
      const newCores = [...cores, corInput.trim()];
      setCores(newCores);
      setFormData({...formData, cor: newCores.join(', ')});
      setCorInput('');
    }
  };

  const handleRemoveCor = (index) => {
    const newCores = cores.filter((_, i) => i !== index);
    setCores(newCores);
    setFormData({...formData, cor: newCores.join(', ')});
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.codigo.trim()) {
      newErrors.codigo = 'Código é obrigatório';
    }
    
    if (!formData.nome.trim()) {
      newErrors.nome = 'Nome é obrigatório';
    } else if (formData.nome.length < 3) {
      newErrors.nome = 'Nome deve ter no mínimo 3 caracteres';
    }
    
    if (!formData.descricao.trim()) {
      newErrors.descricao = 'Descrição é obrigatória';
    } else if (formData.descricao.length < 5) {
      newErrors.descricao = 'Descrição deve ter no mínimo 5 caracteres';
    }
    
    if (!formData.marca.trim()) {
      newErrors.marca = 'Marca é obrigatória';
    } else if (formData.marca.length < 2) {
      newErrors.marca = 'Marca deve ter no mínimo 2 caracteres';
    }

    if (!formData.modelo.trim()) {
      newErrors.modelo = 'Modelo é obrigatório';
    } else if (formData.modelo.length < 2) {
      newErrors.modelo = 'Modelo deve ter no mínimo 2 caracteres';
    }

    if (!formData.numeroSerie.trim()) {
      newErrors.numeroSerie = 'Número de série é obrigatório';
    }
    
    if (!formData.preco) {
      newErrors.preco = 'Preço é obrigatório';
    } else if (isNaN(parseFloat(formData.preco)) || parseFloat(formData.preco) <= 0) {
      newErrors.preco = 'Preço deve ser maior que zero';
    }
    
    if (!formData.categoria.trim()) {
      newErrors.categoria = 'Categoria é obrigatória';
    }
    
    if (!formData.departamento) {
      newErrors.departamento = 'Departamento é obrigatório';
    }
    
    if (!formData.dataAquisicao) {
      newErrors.dataAquisicao = 'Data de aquisição é obrigatória';
    } else {
      const selectedDate = new Date(formData.dataAquisicao);
      selectedDate.setHours(0, 0, 0, 0);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (selectedDate > today) {
        newErrors.dataAquisicao = 'Data não pode ser no futuro';
      }
    }
    
    if (!formData.dataUtilizacao) {
      newErrors.dataUtilizacao = 'Data de utilização é obrigatória';
    } else if (formData.dataAquisicao) {
      const dataUtil = new Date(formData.dataUtilizacao);
      const dataAq = new Date(formData.dataAquisicao);
      if (dataUtil < dataAq) {
        newErrors.dataUtilizacao = 'Data de utilização não pode ser anterior à data de aquisição';
      }
    }
    
    if (!formData.dataInventario) {
      newErrors.dataInventario = 'Data de inventário é obrigatória';
    } else if (formData.dataAquisicao) {
      const dataInv = new Date(formData.dataInventario);
      const dataAq = new Date(formData.dataAquisicao);
      if (dataInv < dataAq) {
        newErrors.dataInventario = 'Data de inventário não pode ser anterior à data de aquisição';
      }
    }
    
    if (!formData.numeroInventario || !formData.numeroInventario.trim()) {
      newErrors.numeroInventario = 'Número de inventário é obrigatório';
    }

    if (!formData.fornecedor.trim()) {
      newErrors.fornecedor = 'Fornecedor é obrigatório';
    } else if (formData.fornecedor.length < 3) {
      newErrors.fornecedor = 'Fornecedor deve ter no mínimo 3 caracteres';
    }



    if (!formData.classificacao.trim()) {
      newErrors.classificacao = 'Classificação é obrigatória';
    }

    if (!formData.taxa) {
      newErrors.taxa = 'Taxa é obrigatória';
    } else if (isNaN(parseFloat(formData.taxa)) || parseFloat(formData.taxa) < 0) {
      newErrors.taxa = 'Taxa inválida';
    }

    if (!formData.classe.trim()) {
      newErrors.classe = 'Classe é obrigatória';
    }

    if (!formData.investimento.trim()) {
      newErrors.investimento = 'Investimento é obrigatório';
    }

    if (cores.length === 0) {
      newErrors.cor = 'Adicione pelo menos uma cor';
    }
    
    if (!formData.foto || !formData.foto.trim()) {
      newErrors.foto = 'Foto do bem é obrigatória';
    } else if (!validateImageUrl(formData.foto)) {
      newErrors.foto = 'URL de imagem inválida. Use formatos: JPG, PNG, GIF, WEBP';
    }
    
    if (!formData.responsavelAtual.trim()) {
      newErrors.responsavelAtual = 'Responsável é obrigatório';
    }
    

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      onSave(formData);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <h2 className="text-2xl font-bold mb-4">{editingBem ? 'Editar Bem' : 'Cadastrar Novo Bem'}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Código Patrimonial *</label>
            <div className="flex gap-2">
              <input 
                type="text" 
                className={`input-field ${errors.codigo ? 'border-red-500' : ''} ${editingBem ? 'bg-gray-100 cursor-not-allowed' : ''}`}
                value={formData.codigo} 
                onChange={(e) => {
                  if (!editingBem) {
                    const value = e.target.value;
                    if (value === '' || /^\d+$/.test(value)) {
                      setFormData({...formData, codigo: value});
                      setErrors({...errors, codigo: ''});
                    }
                  }
                }} 
                placeholder="Ex: 702007460001"
                disabled={isGeneratingCode || editingBem}
                readOnly={editingBem}
              />
              {!editingBem && (
                <button
                  type="button"
                  onClick={generateUniqueCode}
                  disabled={isGeneratingCode}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition disabled:opacity-50"
                  title="Gerar código automático"
                >
                  <div className="icon-refresh-cw text-lg"></div>
                </button>
              )}
            </div>
            {editingBem && <p className="text-xs text-gray-500 mt-1">O código não pode ser alterado</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Denominação *</label>
            <input 
              type="text" 
              className={`input-field ${errors.nome ? 'border-red-500' : ''}`}
              value={formData.nome}
              onChange={(e) => {
                setFormData({...formData, nome: e.target.value});
                setErrors({...errors, nome: ''});
              }} 
              placeholder="Ex: Computador Desktop"
            />
            {errors.nome && <p className="text-red-500 text-xs mt-1">{errors.nome}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Número de Elemento (Automático)</label>
            <input 
              type="text" 
              className="input-field bg-gray-100 cursor-not-allowed"
              value={formData.numeroElemento}
              readOnly
              disabled
              title="Gerado automaticamente para identificar o elemento"
            />
            <p className="text-xs text-gray-500 mt-1">Este número é gerado automaticamente e identifica unicamente este bem</p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Foto do Bem *</label>
            <div className={`border-2 border-dashed rounded-lg p-4 text-center transition ${errors.foto ? 'border-red-500' : 'border-gray-300 hover:border-blue-500'}`}>
              {photoPreview ? (
                <div className="mb-3">
                  <img src={photoPreview} alt="Preview" className="max-h-48 mx-auto rounded-lg" />
                  <button 
                    type="button"
                    onClick={() => {
                      setPhotoPreview('');
                      setFormData({...formData, foto: ''});
                      const fileInput = document.getElementById('fotoUpload');
                      if (fileInput) fileInput.value = '';
                    }}
                    className="mt-2 text-sm text-red-600 hover:text-red-800 font-medium"
                  >
                    Remover foto
                  </button>
                </div>
              ) : (
                <div className="icon-upload text-4xl text-gray-400 mx-auto mb-2 w-fit"></div>
              )}
              <input 
                type="file" 
                id="fotoUpload" 
                accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
                onChange={handlePhotoFileChange}
                className="hidden"
              />
              <label 
                htmlFor="fotoUpload" 
                className="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 cursor-pointer mb-3"
              >
                Escolher Arquivo
              </label>
              <p className="text-sm text-gray-600 mb-2">ou cole a URL da foto abaixo</p>
              <input 
                type="url" 
                className={`input-field ${errors.foto ? 'border-red-500' : ''}`}
                value={formData.foto || ''}
                onChange={handlePhotoUrlChange}
                placeholder="https://exemplo.com/foto.jpg"
              />
              <p className="text-xs text-gray-500 mt-2">Formatos: JPG, PNG, GIF, WEBP (máx. 5MB)</p>
              {errors.foto && <p className="text-red-500 text-xs mt-1">{errors.foto}</p>}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Descrição *</label>
            <textarea 
              className={`input-field ${errors.descricao ? 'border-red-500' : ''}`}
              rows="3" 
              value={formData.descricao}
              onChange={(e) => {
                setFormData({...formData, descricao: e.target.value});
                setErrors({...errors, descricao: ''});
              }} 
              placeholder="Descreva detalhadamente o bem..."
            />
            {errors.descricao && <p className="text-red-500 text-xs mt-1">{errors.descricao}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Marca *</label>
              <input 
                type="text" 
                className={`input-field ${errors.marca ? 'border-red-500' : ''}`}
                value={formData.marca}
                onChange={(e) => {
                  setFormData({...formData, marca: e.target.value});
                  setErrors({...errors, marca: ''});
                }}
                placeholder="Ex: Lenovo"
              />
              {errors.marca && <p className="text-red-500 text-xs mt-1">{errors.marca}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Modelo *</label>
              <input 
                type="text" 
                className={`input-field ${errors.modelo ? 'border-red-500' : ''}`}
                value={formData.modelo}
                onChange={(e) => {
                  setFormData({...formData, modelo: e.target.value});
                  setErrors({...errors, modelo: ''});
                }}
                placeholder="Ex: ThinkPad X1"
              />
              {errors.modelo && <p className="text-red-500 text-xs mt-1">{errors.modelo}</p>}
            </div>
          </div>


          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Quantidade *</label>
              <input 
                type="number" 
                className="input-field"
                value={formData.quantidade}
                min="1"
                onChange={(e) => {
                  const value = e.target.value;
                  if (value === '' || parseInt(value) >= 1) {
                    setFormData({...formData, quantidade: value});
                  }
                }}
                disabled={editingBem}
                placeholder="Ex: 5"
              />
              {editingBem && (
                <p className="text-xs text-gray-500 mt-1">Quantidade não pode ser alterada</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Preço Original (MZN) *</label>
              <input 
                type="text" 
                className={`input-field ${errors.preco ? 'border-red-500' : ''}`}
                value={formData.preco}
                onChange={(e) => {
                  const value = e.target.value;
                  if (value === '' || /^\d*\.?\d*$/.test(value)) {
                    const precoNum = parseFloat(value) || 0;
                    let valorAtual = precoNum;
                    
                    // Calculate depreciation based on acquisition date
                    if (value && formData.dataAquisicao) {
                      const aquisicaoDate = new Date(formData.dataAquisicao);
                      const currentDate = new Date();
                      const yearsElapsed = (currentDate - aquisicaoDate) / (1000 * 60 * 60 * 24 * 365.25);
                      const depreciationRate = 0.10; // 10% per year
                      const depreciationFactor = Math.max(0, 1 - (yearsElapsed * depreciationRate));
                      valorAtual = (precoNum * depreciationFactor).toFixed(2);
                    } else if (value && formData.estadoConservacao) {
                      if (formData.estadoConservacao === 'razoavel') {
                        valorAtual = (precoNum * 0.6).toFixed(2);
                      } else if (formData.estadoConservacao === 'estragado') {
                        valorAtual = (precoNum * 0.3).toFixed(2);
                      } else {
                        valorAtual = value;
                      }
                    }
                    
                    setFormData({...formData, preco: value, valorAtual: valorAtual.toString()});
                    setErrors({...errors, preco: ''});
                  }
                }} 
                placeholder="Ex: 25000.00"
              />
              {errors.preco && <p className="text-red-500 text-xs mt-1">{errors.preco}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Valor Atual (MZN)</label>
              <input 
                type="text" 
                className="input-field bg-gray-100"
                value={formData.valorAtual}
                readOnly
                placeholder="Calculado automaticamente"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Categoria *</label>
              <select 
                className={`input-field ${errors.categoria ? 'border-red-500' : ''}`}
                value={formData.categoria}
                onChange={(e) => {
                  setFormData({...formData, categoria: e.target.value});
                  setErrors({...errors, categoria: ''});
                }}>
                <option value="">Selecione...</option>
                <option value="Material">Material</option>
                <option value="Consumível">Consumível</option>
              </select>
              {errors.categoria && <p className="text-red-500 text-xs mt-1">{errors.categoria}</p>}
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Status</label>
              <select 
                className="input-field" 
                value={formData.status}
                onChange={(e) => setFormData({...formData, status: e.target.value})}>
                <option value="disponivel">Disponível</option>
                <option value="em_uso">Em Uso</option>
                <option value="manutencao">Manutenção</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Estado de Conservação</label>
              <select 
                className="input-field" 
                value={formData.estadoConservacao}
                onChange={(e) => {
                  const estado = e.target.value;
                  const precoNum = parseFloat(formData.preco || 0);
                  let valorAtual = precoNum;
                  
                  // Apply depreciation first if acquisition date exists
                  if (formData.dataAquisicao) {
                    const aquisicaoDate = new Date(formData.dataAquisicao);
                    const currentDate = new Date();
                    const yearsElapsed = (currentDate - aquisicaoDate) / (1000 * 60 * 60 * 24 * 365.25);
                    const depreciationRate = 0.10;
                    const depreciationFactor = Math.max(0, 1 - (yearsElapsed * depreciationRate));
                    valorAtual = precoNum * depreciationFactor;
                  }
                  
                  // Then apply conservation state adjustment
                  if (estado === 'razoavel') valorAtual *= 0.6;
                  else if (estado === 'estragado') valorAtual *= 0.3;
                  
                  setFormData({...formData, estadoConservacao: estado, valorAtual: valorAtual.toFixed(2)});
                }}>
                <option value="bom">Bom (100%)</option>
                <option value="razoavel">Razoável (60%)</option>
                <option value="estragado">Estragado (30%)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Cores do Bem *</label>
              <div className="flex gap-2 mb-2">
                <input 
                  type="text" 
                  className={`input-field ${errors.cor ? 'border-red-500' : ''}`}
                  value={corInput}
                  onChange={(e) => setCorInput(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddCor();
                    }
                  }}
                  placeholder="Ex: Preto, Branco..."
                />
                <button
                  type="button"
                  onClick={handleAddCor}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                >
                  <div className="icon-plus text-lg"></div>
                </button>
              </div>
              {errors.cor && <p className="text-red-500 text-xs mb-2">{errors.cor}</p>}
              {cores.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {cores.map((cor, index) => (
                    <span key={index} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm flex items-center gap-2">
                      {cor}
                      <button
                        type="button"
                        onClick={() => handleRemoveCor(index)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <div className="icon-x text-sm"></div>
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Departamento Destinado *</label>
            <select 
              className={`input-field ${errors.departamento ? 'border-red-500' : ''}`}
              value={formData.departamento}
              onChange={async (e) => {
                const deptName = e.target.value;
                setFormData({...formData, departamento: deptName, localizacao: ''});
                setErrors({...errors, departamento: ''});
                
                if (deptName) {
                  try {
                    const deptResult = await dbListObjects('departamento', 100);
                    const dept = deptResult.items.find(d => d.objectData.nome === deptName);
                    if (dept) {
                      const localizacao = buildLocalizacao(dept);
                      setFormData(prev => ({...prev, localizacao: localizacao || 'N/A'}));
                    } else {
                      setFormData(prev => ({...prev, localizacao: 'N/A'}));
                    }
                  } catch (error) {
                    console.error('Error loading department location:', error);
                    setFormData(prev => ({...prev, localizacao: 'N/A'}));
                  }
                }
              }}>
              <option value="">Selecione...</option>
              {departamentos.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
            {errors.departamento && <p className="text-red-500 text-xs mt-1">{errors.departamento}</p>}
            {formData.departamento && (
              <p className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                <span className="icon-map-pin text-gray-400"></span>
                <span className="font-medium text-gray-600">Localização:</span>
                <span className={formData.localizacao && formData.localizacao !== 'N/A' ? 'text-gray-700' : 'text-gray-400 italic'}>
                  {formData.localizacao || 'A carregar...'}
                </span>
              </p>
            )}
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Data de Aquisição *</label>
              <input 
                type="date" 
                className={`input-field ${errors.dataAquisicao ? 'border-red-500' : ''}`}
                value={formData.dataAquisicao}
                max={new Date().toISOString().split('T')[0]}
                onChange={(e) => {
                  const newDate = e.target.value;
                  let valorAtual = formData.preco;
                  
                  // Recalculate depreciation when date changes
                  if (formData.preco && newDate) {
                    const precoNum = parseFloat(formData.preco) || 0;
                    const aquisicaoDate = new Date(newDate);
                    const currentDate = new Date();
                    const yearsElapsed = (currentDate - aquisicaoDate) / (1000 * 60 * 60 * 24 * 365.25);
                    const depreciationRate = 0.10; // 10% per year
                    const depreciationFactor = Math.max(0, 1 - (yearsElapsed * depreciationRate));
                    valorAtual = (precoNum * depreciationFactor).toFixed(2);
                  }
                  
                  setFormData({...formData, dataAquisicao: newDate, valorAtual: valorAtual});
                  setErrors({...errors, dataAquisicao: '', dataUtilizacao: '', dataInventario: ''});
                }} 
              />
              {errors.dataAquisicao && <p className="text-red-500 text-xs mt-1">{errors.dataAquisicao}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Data de Utilização *</label>
              <input 
                type="date" 
                className={`input-field ${errors.dataUtilizacao ? 'border-red-500' : ''}`}
                value={formData.dataUtilizacao}
                min={formData.dataAquisicao || undefined}
                max={new Date().toISOString().split('T')[0]}
                onChange={(e) => {
                  setFormData({...formData, dataUtilizacao: e.target.value});
                  setErrors({...errors, dataUtilizacao: ''});
                }} 
              />
              {errors.dataUtilizacao && <p className="text-red-500 text-xs mt-1">{errors.dataUtilizacao}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Data de Inventário *</label>
              <input 
                type="date" 
                className={`input-field ${errors.dataInventario ? 'border-red-500' : ''}`}
                value={formData.dataInventario}
                min={formData.dataAquisicao || undefined}
                max={new Date().toISOString().split('T')[0]}
                onChange={(e) => {
                  setFormData({...formData, dataInventario: e.target.value});
                  setErrors({...errors, dataInventario: ''});
                }} 
              />
              {errors.dataInventario && <p className="text-red-500 text-xs mt-1">{errors.dataInventario}</p>}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">N° Inventário (Automático) *</label>
              <input 
                type="text" 
                className={`input-field bg-gray-100 cursor-not-allowed ${errors.numeroInventario ? 'border-red-500' : ''}`}
                value={formData.numeroInventario}
                readOnly
                disabled
                placeholder="Gerado automaticamente"
              />
              <p className="text-xs text-gray-500 mt-1">Número gerado automaticamente</p>
              {errors.numeroInventario && <p className="text-red-500 text-xs mt-1">{errors.numeroInventario}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">N° de Série *</label>
              <input 
                type="text" 
                className={`input-field ${errors.numeroSerie ? 'border-red-500' : ''}`}
                value={formData.numeroSerie}
                onChange={(e) => {
                  setFormData({...formData, numeroSerie: e.target.value});
                  setErrors({...errors, numeroSerie: ''});
                }} 
                placeholder="Ex: SN123456789"
              />
              {errors.numeroSerie && <p className="text-red-500 text-xs mt-1">{errors.numeroSerie}</p>}
            </div>
          </div>



          <div>
            <label className="block text-sm font-medium mb-2">Classificação *</label>
            <input 
              type="text" 
              className={`input-field ${errors.classificacao ? 'border-red-500' : ''}`}
              value={formData.classificacao}
              onChange={(e) => {
                const value = e.target.value;
                // Aceitar apenas números
                if (value === '' || /^\d+$/.test(value)) {
                  let taxa = '0.00';
                  
                  // Calcular taxa baseada na classificação
                  if (value.startsWith('111')) {
                    taxa = '25.00'; // Edifícios e outras construções
                  } else if (value.startsWith('112')) {
                    taxa = '16.67'; // Equipamento básico
                  } else if (value.startsWith('113')) {
                    taxa = '25.00'; // Equipamento de transporte
                  } else if (value.startsWith('114')) {
                    taxa = '33.33'; // Equipamento administrativo
                  } else if (value.startsWith('115')) {
                    taxa = '20.00'; // Outros equipamentos
                  }
                  
                  setFormData({...formData, classificacao: value, taxa: taxa});
                  setErrors({...errors, classificacao: ''});
                }
              }} 
              placeholder="Ex: 111309"
            />
            {errors.classificacao && <p className="text-red-500 text-xs mt-1">{errors.classificacao}</p>}
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Taxa (%) *</label>
              <input 
                type="text" 
                className={`input-field bg-gray-100 cursor-not-allowed ${errors.taxa ? 'border-red-500' : ''}`}
                value={formData.taxa}
                readOnly
                disabled
                placeholder="Calculada automaticamente"
              />
              <p className="text-xs text-gray-500 mt-1">Taxa calculada automaticamente baseada na classificação</p>
              {errors.taxa && <p className="text-red-500 text-xs mt-1">{errors.taxa}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Classe *</label>
              <input 
                type="text" 
                className={`input-field ${errors.classe ? 'border-red-500' : ''}`}
                value={formData.classe}
                onChange={(e) => {
                  setFormData({...formData, classe: e.target.value});
                  setErrors({...errors, classe: ''});
                }} 
                placeholder="Ex: A, B, C..."
              />
              {errors.classe && <p className="text-red-500 text-xs mt-1">{errors.classe}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Investimento *</label>
              <input 
                type="text" 
                className={`input-field ${errors.investimento ? 'border-red-500' : ''}`}
                value={formData.investimento}
                onChange={(e) => {
                  const value = e.target.value;
                  if (value === '' || /^\d+$/.test(value)) {
                    setFormData({...formData, investimento: value});
                    setErrors({...errors, investimento: ''});
                  }
                }} 
                placeholder="Ex: 001"
              />
              {errors.investimento && <p className="text-red-500 text-xs mt-1">{errors.investimento}</p>}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Responsável Atual *</label>
            <select 
              className={`input-field ${errors.responsavelAtual ? 'border-red-500' : ''}`}
              value={formData.responsavelAtual}
              onChange={(e) => {
                setFormData({...formData, responsavelAtual: e.target.value});
                setErrors({...errors, responsavelAtual: ''});
              }}
            >
              <option value="">Selecione um responsável...</option>
              {usuarios.map(user => (
                <option key={user.objectId} value={user.objectData.name}>
                  {user.objectData.name} - {user.objectData.department}
                </option>
              ))}
            </select>
            {errors.responsavelAtual && <p className="text-red-500 text-xs mt-1">{errors.responsavelAtual}</p>}
          </div>


          
          <div>
            <label className="block text-sm font-medium mb-2">Fornecedor *</label>
            <input 
              type="text" 
              className={`input-field ${errors.fornecedor ? 'border-red-500' : ''}`}
              value={formData.fornecedor}
              onChange={(e) => {
                setFormData({...formData, fornecedor: e.target.value});
                setErrors({...errors, fornecedor: ''});
              }} 
              placeholder="Ex: Tech Suppliers Lda"
            />
            {errors.fornecedor && <p className="text-red-500 text-xs mt-1">{errors.fornecedor}</p>}
          </div>



          <div>
            <label className="block text-sm font-medium mb-2">Observações</label>
            <textarea 
              className="input-field" 
              rows="3" 
              value={formData.observacoes}
              onChange={(e) => setFormData({...formData, observacoes: e.target.value})} 
              placeholder="Ex: Material doado pela UCM-REITORIA"
            />
          </div>
          
          <div className="flex justify-end space-x-3 mt-6 pt-4 border-t">
            <button type="button" onClick={onClose} className="btn bg-gray-200 text-gray-800 hover:bg-gray-300">
              Cancelar
            </button>
            <button type="submit" className="btn btn-primary">
              {editingBem ? 'Atualizar' : 'Cadastrar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<BensApp />);