function HistoricoUsuarioApp() {
  const [user, setUser] = React.useState(null);
  const [targetEmail, setTargetEmail] = React.useState('');
  const [targetName, setTargetName] = React.useState('');
  const [requisicoes, setRequisicoes] = React.useState([]);
  const [bensEmUso, setBensEmUso] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    setUser(currentUser);
    
    const urlParams = new URLSearchParams(window.location.search);
    const email = urlParams.get('email');
    if (email) {
      setTargetEmail(email);
      loadUserHistory(email);
    } else {
      window.history.back();
    }
  }, []);

  const loadUserHistory = async (email) => {
    try {
      // Carregar todas as requisições do usuário
      const reqResult = await dbListObjects('requisicao', 1000, true);
      const userReqs = reqResult.items.filter(r => r.objectData.emailSolicitante === email);
      setRequisicoes(userReqs);

      // Pegar nome do primeiro registro
      if (userReqs.length > 0) {
        setTargetName(userReqs[0].objectData.solicitante);
      }

      // Carregar bens em uso atualmente
      const bensResult = await dbListObjects('bem', 1000, true);
      const userBens = bensResult.items.filter(b => b.objectData.usuarioAtual === email);
      setBensEmUso(userBens);
    } catch (error) {
      console.error('Error loading user history:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Header user={user} />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-gray-600">Carregando...</div>
        </div>
      </div>
    );
  }

  const totalRequisicoes = requisicoes.length;
  const aprovadas = requisicoes.filter(r => r.objectData.status === 'aprovado').length;
  const pendentes = requisicoes.filter(r => r.objectData.status === 'pendente').length;
  const rejeitadas = requisicoes.filter(r => r.objectData.status === 'rejeitado').length;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      <main className="flex-grow p-6 max-w-7xl mx-auto w-full">
        <button
          onClick={() => window.history.back()}
          className="flex items-center gap-2 bg-white text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-100 transition text-sm mb-6 shadow-sm"
        >
          <div className="icon-arrow-left text-lg"></div>
          <span>Voltar</span>
        </button>

        <div className="card mb-6">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center">
              <div className="icon-user text-4xl text-indigo-600"></div>
            </div>
            <div>
              <h1 className="text-3xl font-bold mb-1">{targetName || targetEmail}</h1>
              <p className="text-gray-600">{targetEmail}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <StatCard icon="file-text" label="Total de Requisições" value={totalRequisicoes} color="blue" />
          <StatCard icon="circle-check" label="Aprovadas" value={aprovadas} color="green" />
          <StatCard icon="clock" label="Pendentes" value={pendentes} color="orange" />
          <StatCard icon="circle-x" label="Rejeitadas" value={rejeitadas} color="red" />
        </div>

        {bensEmUso.length > 0 && (
          <div className="card mb-6">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <div className="icon-package text-green-600"></div>
              Bens em Uso Atualmente
              <span className="ml-auto bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">
                {bensEmUso.length}
              </span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {bensEmUso.map(bem => (
                <BemCard key={bem.objectId} bem={bem.objectData} />
              ))}
            </div>
          </div>
        )}

        <div className="card">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <div className="icon-history text-purple-600"></div>
            Histórico Completo de Requisições
          </h2>
          {requisicoes.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Nenhuma requisição encontrada</p>
          ) : (
            <div className="space-y-4">
              {requisicoes.map(req => (
                <RequisicaoCard key={req.objectId} requisicao={req.objectData} />
              ))}
            </div>
          )}
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  const colors = {
    blue: 'bg-blue-50 border-blue-200 text-blue-600',
    green: 'bg-gray-50 border-gray-200 text-green-600',
    orange: 'bg-orange-50 border-orange-200 text-orange-600',
    red: 'bg-red-50 border-red-200 text-red-600'
  };

  return (
    <div className={`card ${colors[color]} border`}>
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
          <div className={`icon-${icon} text-xl ${colors[color].split(' ')[2]}`}></div>
        </div>
        <div>
          <p className="text-sm mb-1">{label}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
      </div>
    </div>
  );
}

function BemCard({ bem }) {
  const dataAtribuicao = bem.dataAtribuicao ? new Date(bem.dataAtribuicao).toLocaleString('pt-BR') : '-';
  
  return (
    <div className="border rounded-lg p-4 bg-gray-50">
      <div className="flex items-start justify-between mb-2">
        <h3 className="font-semibold text-gray-800">{bem.nome}</h3>
        <span className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs">Em Uso</span>
      </div>
      <p className="text-sm text-gray-600 mb-2">Código: {bem.codigo}</p>
      <p className="text-xs text-gray-500">Atribuído em: {dataAtribuicao}</p>
    </div>
  );
}

function RequisicaoCard({ requisicao }) {
  const statusColors = {
    pendente: 'bg-orange-100 text-orange-700',
    aprovado: 'bg-green-100 text-green-700',
    rejeitado: 'bg-red-100 text-red-700'
  };

  const statusLabels = {
    pendente: 'Pendente',
    aprovado: 'Aprovado',
    rejeitado: 'Rejeitado'
  };

  const dataRequisicao = new Date(requisicao.dataRequisicao).toLocaleString('pt-BR');

  return (
    <div className="border rounded-lg p-4 hover:shadow-md transition">
      <div className="flex items-start justify-between mb-3">
        <div>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusColors[requisicao.status]}`}>
            {statusLabels[requisicao.status]}
          </span>
          <p className="text-sm text-gray-600 mt-2">Data: {dataRequisicao}</p>
        </div>
      </div>
      <div className="mb-3">
        <p className="text-sm font-medium text-gray-700 mb-1">Departamento:</p>
        <p className="text-sm text-gray-600">{requisicao.departamento}</p>
      </div>
      {requisicao.itensDetalhados && requisicao.itensDetalhados.length > 0 && (
        <div>
          <p className="text-sm font-medium text-gray-700 mb-2">Itens Requisitados:</p>
          <ul className="space-y-1">
            {requisicao.itensDetalhados.map((item, idx) => (
              <li key={idx} className="text-sm text-gray-600 flex items-center gap-2">
                <div className="icon-package text-xs text-gray-400"></div>
                <span>{item.descricao} - Qtd: {item.quantidade}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {requisicao.observacao && (
        <div className="mt-3 pt-3 border-t">
          <p className="text-sm font-medium text-gray-700 mb-1">Observação:</p>
          <p className="text-sm text-gray-600">{requisicao.observacao}</p>
        </div>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<HistoricoUsuarioApp />);

