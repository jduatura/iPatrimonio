function ManutencaoApp() {
  const [user, setUser] = React.useState(null);
  const [manutencoes, setManutencoes] = React.useState([]);
  const [bens, setBens] = React.useState([]);
  const [tecnicos, setTecnicos] = React.useState([]);
  const [historico, setHistorico] = React.useState([]);
  const [activeTab, setActiveTab] = React.useState('ordens'); // 'ordens' | 'preventiva' | 'historico' | 'estatisticas'
  const [filterStatus, setFilterStatus] = React.useState('todos');
  const [filterTipo, setFilterTipo] = React.useState('todos');
  const [filterUrgencia, setFilterUrgencia] = React.useState('todos');
  const [searchTerm, setSearchTerm] = React.useState('');
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');
  const [isProcessing, setIsProcessing] = React.useState(false);

  // Modals state
  const [modalType, setModalType] = React.useState(null); // 'novo_pedido' | 'atribuir' | 'orcamento' | 'encaminhar_admin' | 'aprovar_admin' | 'concluir' | 'preventiva' | 'detalhes' | 'imprimir'
  const [selectedOrder, setSelectedOrder] = React.useState(null);

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    if (currentUser.role === 'admin') {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadAllData();

    // Check URL params
    const params = new URLSearchParams(window.location.search);
    if (params.get('action') === 'reportar' || params.get('code') || params.get('codigo')) {
      setModalType('novo_pedido');
    }
  }, []);

  const loadAllData = async () => {
    try {
      const [manutResult, bensResult, usersResult, histResult] = await Promise.all([
        dbListObjects('manutencao', 500, true),
        dbListObjects('bem', 500, true),
        dbListObjects('usuario', 100, true),
        dbListObjects('historico_manutencao', 500, true)
      ]);

      const bensItems = bensResult.items || [];

      // Enrich manutencoes: compute sugestaoAbate for records where it hasn't been set yet
      const enrichedManutencoes = (manutResult.items || []).map(m => {
        const d = m.objectData || {};
        if (d.sugestaoAbate === undefined || d.sugestaoAbate === null) {
          const custoEstimado = parseFloat(d.custoEstimado) || 0;
          if (custoEstimado > 0 && (d.bemId || d.bemCodigo)) {
            const bem = bensItems.find(b => 
              (d.bemId && (b.objectId === d.bemId || b.id === d.bemId)) ||
              (d.bemCodigo && (b.objectData?.numeroPatrimonio === d.bemCodigo || b.objectData?.codigo === d.bemCodigo))
            );
            if (bem) {
              const bd = bem.objectData || {};
              const valorAquisicao = parseFloat(bd.preco || bd.valorAquisicao || bd.valorAtual || bd.custoAquisicao || 0);
              if (valorAquisicao > 0 && custoEstimado > valorAquisicao) {
                return { ...m, objectData: { ...d, sugestaoAbate: true, valorAquisicao } };
              }
            }
          }
        }
        return m;
      });

      setManutencoes(enrichedManutencoes);
      setBens(bensItems);
      setHistorico(histResult.items || []);

      // Filtrar técnicos (apenas utilizadores vinculados ao departamento de Manutenção)
      const tecs = (usersResult.items || []).filter(u => 
        u.objectData.department === 'Manutenção'
      );
      setTecnicos(tecs);
    } catch (error) {
      console.error('Erro ao carregar dados de manutenção:', error);
    }
  };

  const showNotification = (msg, type = 'success') => {
    setAlertMessage(msg);
    setAlertType(type);
    setShowAlert(true);
  };

  // ==========================================================
  // AÇÕES DO FLUXO
  // ==========================================================

  // PASSO 1: Docente / Utilizador submete pedido de reparação
  const handleCriarPedidoCorrectivo = async (formData) => {
    setIsProcessing(true);
    try {
      const numeroOrdem = `MAN-${new Date().getFullYear()}-${String(manutencoes.length + 1).padStart(4, '0')}`;
      const now = new Date().toISOString();

      const novaManutencao = {
        numeroOrdem,
        tipo: 'correctiva',
        bemId: formData.bemId,
        bemCodigo: formData.bemCodigo,
        bemNome: formData.bemNome,
        departamento: formData.departamento,
        localizacao: formData.localizacao,
        solicitanteNome: user.name,
        solicitanteEmail: user.username,
        solicitanteDepartamento: user.department,
        urgencia: formData.urgencia,
        descricaoAvaria: formData.descricaoAvaria,
        dataAbertura: now,
        status: 'pendente',
        historicoFluxo: [
          {
            etapa: 'Abertura do Pedido',
            responsavel: user.name,
            cargo: user.department,
            data: now,
            detalhe: `Avaria reportada (${formData.urgencia.toUpperCase()}): ${formData.descricaoAvaria}`
          }
        ]
      };

      await dbCreateObject('manutencao', novaManutencao);

      // Notificar o Departamento de Patrimônio sobre novo pedido de reparação
      try {
        await dbCreateObject('notificacao', {
          destinatario: 'patrimonio',
          mensagem: `🚨 Novo Pedido de Manutenção: O bem "${formData.bemNome}" (${formData.bemCodigo}) teve uma avaria reportada por ${user.name}.`,
          tipo: 'nova_manutencao',
          lida: false,
          createdAt: now
        });
      } catch (nErr) {
        console.warn('Erro ao notificar Património:', nErr);
      }

      // Atualizar status do Bem para 'avariado'
      if (formData.bemId) {
        try {
          const bemObj = await dbGetObject('bem', formData.bemId);
          await dbUpdateObject('bem', formData.bemId, {
            ...bemObj.objectData,
            status: 'avariado',
            estadoConservacao: 'estragado',
            updatedAt: now
          });
        } catch (bemErr) {
          console.warn('Não foi possível atualizar status do bem:', bemErr);
        }
      }

      await logAuditAction(
        AUDIT_ACTIONS.SOLICITAR_MANUTENCAO,
        `Pedido de manutenção aberto ${numeroOrdem} para o bem ${formData.bemCodigo} (${formData.bemNome})`,
        user
      );

      showNotification(`Pedido ${numeroOrdem} submetido com sucesso! O Património foi notificado.`);
      setModalType(null);
      loadAllData();
    } catch (error) {
      console.error('Erro ao submeter pedido:', error);
      showNotification('Erro ao submeter pedido: ' + error.message, 'error');
    }
    setIsProcessing(false);
  };

  // PASSO 2: Património atribui Técnico
  const handleAtribuirTecnico = async (orderId, tecnicoData) => {
    setIsProcessing(true);
    try {
      const order = await dbGetObject('manutencao', orderId);
      const now = new Date().toISOString();

      const updatedHistory = [
        ...(order.objectData.historicoFluxo || []),
        {
          etapa: 'Atribuição Técnica',
          responsavel: user.name,
          cargo: 'Patrimônio',
          data: now,
          detalhe: `Atribuído ao técnico: ${tecnicoData.tecnicoNome} (${tecnicoData.tecnicoEmail})`
        }
      ];

      await dbUpdateObject('manutencao', orderId, {
        ...order.objectData,
        tecnicoId: tecnicoData.tecnicoId,
        tecnicoNome: tecnicoData.tecnicoNome,
        tecnicoEmail: tecnicoData.tecnicoEmail,
        dataAtribuicao: now,
        status: 'atribuido_tecnico',
        historicoFluxo: updatedHistory
      });

      // Notificação ao Técnico (atribuição de ordem)
      try {
        await dbCreateObject('notificacao', {
          destinatario: tecnicoData.tecnicoNome,
          mensagem: `🔧 Ordem de Manutenção Atribuída: Foi-lhe atribuída a reparação do bem "${order.objectData.bemNome}" (${order.objectData.bemCodigo}) — Urgência: ${(order.objectData.urgencia || 'media').toUpperCase()}. Aceda ao sistema para ver o diagnóstico.`,
          tipo: 'nova_manutencao',
          lida: false,
          createdAt: now
        });
        if (tecnicoData.tecnicoEmail && tecnicoData.tecnicoEmail !== tecnicoData.tecnicoNome) {
          await dbCreateObject('notificacao', {
            destinatario: tecnicoData.tecnicoEmail,
            mensagem: `🔧 Ordem de Manutenção Atribuída: Foi-lhe atribuída a reparação do bem "${order.objectData.bemNome}" (${order.objectData.bemCodigo}) — Urgência: ${(order.objectData.urgencia || 'media').toUpperCase()}.`,
            tipo: 'nova_manutencao',
            lida: false,
            createdAt: now
          });
        }
      } catch (nErr) {
        console.warn('Erro ao enviar notificação ao técnico:', nErr);
      }

      await logAuditAction(
        AUDIT_ACTIONS.ATRIBUIR_MANUTENCAO,
        `Ordem ${order.objectData.numeroOrdem} atribuída ao técnico ${tecnicoData.tecnicoNome}`,
        user
      );

      showNotification(`Ordem ${order.objectData.numeroOrdem} atribuída ao técnico ${tecnicoData.tecnicoNome}!`);
      setModalType(null);
      loadAllData();
    } catch (error) {
      console.error('Erro ao atribuir técnico:', error);
      showNotification('Erro ao atribuir técnico: ' + error.message, 'error');
    }
    setIsProcessing(false);
  };

  // PASSO 3: Técnico submete Diagnóstico e Orçamento
  const handleSubmeterOrcamento = async (orderId, orcamentoData) => {
    setIsProcessing(true);
    try {
      const order = await dbGetObject('manutencao', orderId);
      const now = new Date().toISOString();
      const custoEstimadoNum = parseFloat(orcamentoData.custoEstimado || 0);

      // Detecção autônoma do valor de aquisição do bem
      let valorAquisicaoBem = parseFloat(order.objectData.valorAquisicao || 0);
      let bemObj = null;
      if (order.objectData.bemId) {
        try {
          bemObj = await dbGetObject('bem', order.objectData.bemId);
          if (bemObj && bemObj.objectData) {
            valorAquisicaoBem = parseFloat(bemObj.objectData.preco || bemObj.objectData.valorAquisicao || bemObj.objectData.valorAtual || bemObj.objectData.custoAquisicao || 0);
          }
        } catch (bErr) {
          console.warn('Erro ao obter valor do bem para comparação de orçamento:', bErr);
        }
      }
      if ((!valorAquisicaoBem || valorAquisicaoBem === 0) && order.objectData.bemCodigo) {
        try {
          const todosBens = await dbListObjects('bem', 500, true);
          const bemPorCod = (todosBens.items || []).find(b => 
            b.objectData?.numeroPatrimonio === order.objectData.bemCodigo || b.objectData?.codigo === order.objectData.bemCodigo
          );
          if (bemPorCod && bemPorCod.objectData) {
            valorAquisicaoBem = parseFloat(bemPorCod.objectData.preco || bemPorCod.objectData.valorAquisicao || bemPorCod.objectData.valorAtual || bemPorCod.objectData.custoAquisicao || 0);
          }
        } catch (cErr) {
          console.warn('Erro ao obter bem por código:', cErr);
        }
      }

      // Verificação autônoma se o custo estimado supera o valor de aquisição
      const superaValorAquisicao = valorAquisicaoBem > 0 && custoEstimadoNum > valorAquisicaoBem;

      const updatedHistory = [
        ...(order.objectData.historicoFluxo || []),
        {
          etapa: 'Diagnóstico e Estimativa Orçamental',
          responsavel: user.name,
          cargo: 'Técnico de Manutenção',
          data: now,
          detalhe: `Diagnóstico: ${orcamentoData.diagnosticoTecnico} | Custo Estimado: ${Number(custoEstimadoNum).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MZN | Prazo: ${orcamentoData.tempoEstimadoHoras}h${superaValorAquisicao ? ' | ALERTA: Custo supera o valor de aquisição (' + Number(valorAquisicaoBem).toLocaleString('pt-MZ', { minimumFractionDigits: 2 }) + ' MZN) - Proposta de Abate sugerida automaticamente' : ''}`
        }
      ];

      await dbUpdateObject('manutencao', orderId, {
        ...order.objectData,
        diagnosticoTecnico: orcamentoData.diagnosticoTecnico,
        custoEstimado: custoEstimadoNum,
        pecasEstimadas: orcamentoData.pecasEstimadas || '',
        tempoEstimadoHoras: parseFloat(orcamentoData.tempoEstimadoHoras || 1),
        valorAquisicao: valorAquisicaoBem,
        sugestaoAbate: superaValorAquisicao,
        dataOrcamento: now,
        status: 'orcamento_submetido',
        historicoFluxo: updatedHistory
      });

      // Notificar o Patrimônio que o orçamento foi submetido pelo Técnico
      try {
        const notifMensagem = superaValorAquisicao
          ? `⚠️ ALERTA DE ABATE: O orçamento (${Number(custoEstimadoNum).toLocaleString('pt-MZ')} MZN) para a ordem ${order.objectData.numeroOrdem} do bem "${order.objectData.bemNome}" SUPERA o valor de aquisição (${Number(valorAquisicaoBem).toLocaleString('pt-MZ')} MZN). Sistema sugere abate definitivo.`
          : `📝 Diagnóstico & Orçamento Submetido: O técnico ${user.name} submeteu a estimativa (${Number(custoEstimadoNum).toLocaleString('pt-MZ')} MZN) para a ordem ${order.objectData.numeroOrdem} do bem "${order.objectData.bemNome}".`;

        await dbCreateObject('notificacao', {
          destinatario: 'patrimonio',
          mensagem: notifMensagem,
          tipo: superaValorAquisicao ? 'alerta_abate' : 'nova_manutencao',
          lida: false,
          createdAt: now
        });
      } catch (nErr) {
        console.warn('Erro ao notificar Património sobre orçamento:', nErr);
      }

      await logAuditAction(
        AUDIT_ACTIONS.SUBMETER_ORCAMENTO_MANUTENCAO,
        `Orçamento de ${custoEstimadoNum} MZN submetido para ordem ${order.objectData.numeroOrdem}${superaValorAquisicao ? ' (Sugestão automática de Abate)' : ''}`,
        user
      );

      if (superaValorAquisicao) {
        showNotification(`⚠️ ALERTA: O custo de reparo (${Number(custoEstimadoNum).toLocaleString('pt-MZ')} MZN) supera o valor de aquisição do bem (${Number(valorAquisicaoBem).toLocaleString('pt-MZ')} MZN). O sistema sugeriu o abate automaticamente para o Património!`, 'warning');
      } else {
        showNotification(`Diagnóstico e orçamento da ordem ${order.objectData.numeroOrdem} enviados ao Património!`);
      }

      setModalType(null);
      loadAllData();
    } catch (error) {
      console.error('Erro ao submeter orçamento:', error);
      showNotification('Erro ao submeter orçamento: ' + error.message, 'error');
    }
    setIsProcessing(false);
  };

  // PASSO 4: Património encaminha Orçamento para Administração
  const handleEncaminharAdmin = async (orderId, parecerData) => {
    setIsProcessing(true);
    try {
      const order = await dbGetObject('manutencao', orderId);
      const now = new Date().toISOString();

      const updatedHistory = [
        ...(order.objectData.historicoFluxo || []),
        {
          etapa: 'Encaminhamento para Aprovação',
          responsavel: user.name,
          cargo: 'Patrimônio',
          data: now,
          detalhe: `Parecer: ${parecerData.parecerPatrimonio}`
        }
      ];

      await dbUpdateObject('manutencao', orderId, {
        ...order.objectData,
        parecerPatrimonio: parecerData.parecerPatrimonio,
        proporAbate: parecerData.proporAbate,
        dataEncaminhamentoAdmin: now,
        status: 'aguardando_aprovacao_admin',
        historicoFluxo: updatedHistory
      });

      // Notificar a Administração para aprovação do orçamento
      try {
        await dbCreateObject('notificacao', {
          destinatario: 'Administração',
          mensagem: `📤 Orçamento de Manutenção para Aprovação: A ordem ${order.objectData.numeroOrdem} do bem "${order.objectData.bemNome}" foi encaminhada pelo Património para a sua avaliação.`,
          tipo: 'nova_manutencao',
          lida: false,
          createdAt: now
        });
      } catch (nErr) {
        console.warn('Erro ao notificar Administração:', nErr);
      }

      await logAuditAction(
        AUDIT_ACTIONS.ENCAMINHAR_MANUTENCAO_ADMIN,
        `Ordem ${order.objectData.numeroOrdem} encaminhada para aprovação da Administração`,
        user
      );

      showNotification(`Ordem ${order.objectData.numeroOrdem} encaminhada à Administração com sucesso!`);
      setModalType(null);
      loadAllData();
    } catch (error) {
      console.error('Erro ao encaminhar:', error);
      showNotification('Erro ao encaminhar: ' + error.message, 'error');
    }
    setIsProcessing(false);
  };

  // PASSO 5: Administradora Aprova ou Reprova
  const handleDecisaoAdmin = async (orderId, decisao, observacao) => {
    setIsProcessing(true);
    try {
      const order = await dbGetObject('manutencao', orderId);
      const now = new Date().toISOString();
      const isAbateAprovado = order.objectData.proporAbate && decisao === 'aprovado';
      const novoStatus = isAbateAprovado ? 'concluido' : (decisao === 'aprovado' ? 'aprovado_em_execucao' : 'rejeitado');

      if (isAbateAprovado && order.objectData.bemId) {
          try {
              const bemItem = await dbGetObject('bem', order.objectData.bemId);
              const abateNum = 'ABT-' + new Date().getFullYear() + '-' + Math.floor(1000 + Math.random() * 9000);
              
              await dbCreateObject('abate', {
                  numeroGuia: abateNum,
                  descricaoBem: bemItem.objectData.nome,
                  cor: bemItem.objectData.cor || '',
                  estadoBem: 'ABATIDO',
                  quantidade: 1,
                  dataAquisicao: bemItem.objectData.dataAquisicao || '',
                  valorAquisicao: parseFloat(bemItem.objectData.preco || 0),
                  localizacao: bemItem.objectData.localizacao || '',
                  valor: parseFloat(bemItem.objectData.valorAtual || bemItem.objectData.preco || 0),
                  motivoAbate: 'Avaria irreparável / Custo de manutenção elevado',
                  observacoes: 'Abate aprovado automaticamente via proposta de manutenção: ' + observacao,
                  dataAbate: now.split('T')[0],
                  responsavel: user.name || '',
                  createdBy: user.email,
                  createdAt: now,
                  manutencaoOrderId: orderId,
                  bemId: order.objectData.bemId
              });

              await dbUpdateObject('bem', order.objectData.bemId, {
                  ...bemItem.objectData,
                  estadoConservacao: 'ABATIDO',
                  status: 'ABATIDO',
                  dataSaida: now,
                  updatedAt: now
              });
          } catch(e) {
              console.error('Erro ao processar o abate:', e);
          }
      }

      const updatedHistory = [
        ...(order.objectData.historicoFluxo || []),
        {
          etapa: decisao === 'aprovado' ? 'Aprovação Orçamental' : 'Reprovação Orçamental',
          responsavel: user.name,
          cargo: 'Administração',
          data: now,
          detalhe: `${decisao === 'aprovado' ? 'APROVADO' : 'REPROVADO'}: ${observacao}`
        }
      ];

      await dbUpdateObject('manutencao', orderId, {
        ...order.objectData,
        aprovadorNome: user.name,
        aprovadorEmail: user.username,
        decisaoAdmin: decisao,
        observacaoAdmin: observacao,
        dataDecisaoAdmin: now,
        status: novoStatus,
        historicoFluxo: updatedHistory
      });

      // Enviar Notificações sobre a Decisão Orçamental
      try {
        let msgAprovacao = decisao === 'aprovado'
          ? `O seu orçamento para a manutenção do bem ${order.objectData.bemNome} (${order.objectData.bemCodigo}) foi APROVADO!`
          : `O seu orçamento para a manutenção do bem ${order.objectData.bemNome} (${order.objectData.bemCodigo}) foi REPROVADO.`;

        if (isAbateAprovado) {
            msgAprovacao = `O bem ${order.objectData.bemNome} (${order.objectData.bemCodigo}) foi aprovado para ABATE definitivo devido ao alto custo de manutenção.`;
        }

        // Notificar o Técnico responsável
        if (order.objectData.tecnicoNome) {
          await dbCreateObject('notificacao', {
            destinatario: order.objectData.tecnicoNome,
            mensagem: msgAprovacao,
            tipo: decisao === 'aprovado' ? 'manutencao_aprovada' : 'manutencao_rejeitada',
            lida: false,
            createdAt: now
          });
        }
        if (order.objectData.tecnicoEmail) {
          await dbCreateObject('notificacao', {
            destinatario: order.objectData.tecnicoEmail,
            mensagem: msgAprovacao,
            tipo: decisao === 'aprovado' ? 'manutencao_aprovada' : 'manutencao_rejeitada',
            lida: false,
            createdAt: now
          });
        }

        // Notificar também o Património
        await dbCreateObject('notificacao', {
          destinatario: 'Patrimônio',
          mensagem: msgAprovacao,
          tipo: decisao === 'aprovado' ? 'manutencao_aprovada' : 'manutencao_rejeitada',
          lida: false,
          createdAt: now
        });
      } catch (notifErr) {
        console.error('Erro ao notificar decisões:', notifErr);
      }

      setModalType(null);
      setSelectedOrder(null);
      loadAllData();
    } catch (error) {
      console.error('Erro na decisão administrativa:', error);
      alert('Ocorreu um erro ao registar a decisão.');
    } finally {
      setIsProcessing(false);
    }
  };
  // PASSO 6: Técnico Conclui Reparação e Submete Relatório Final
  const handleConcluirReparacao = async (orderId, conclusaoData) => {
    setIsProcessing(true);
    try {
      const order = await dbGetObject('manutencao', orderId);
      const now = new Date().toISOString();

      const updatedHistory = [
        ...(order.objectData.historicoFluxo || []),
        {
          etapa: 'Conclusão dos Trabalhos',
          responsavel: user.name,
          cargo: 'Técnico de Manutenção',
          data: now,
          detalhe: `Intervenção: ${conclusaoData.tipoIntervencao} | Custo Real: ${Number(conclusaoData.custoFinal).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MZN | Tempo: ${conclusaoData.tempoGastoHoras}h | ${conclusaoData.relatorioFinal}`
        }
      ];

      // 1. Atualizar Ordem de Manutenção
      await dbUpdateObject('manutencao', orderId, {
        ...order.objectData,
        tipoIntervencao: conclusaoData.tipoIntervencao,
        custoFinal: parseFloat(conclusaoData.custoFinal || 0),
        tempoGastoHoras: parseFloat(conclusaoData.tempoGastoHoras || 1),
        pecasUtilizadas: conclusaoData.pecasUtilizadas || '',
        relatorioFinal: conclusaoData.relatorioFinal,
        dataConclusao: now,
        status: 'concluido',
        historicoFluxo: updatedHistory
      });

      // 2. Restaurar status do Bem para 'disponivel' / funcional
      if (order.objectData.bemId) {
        try {
          const bemObj = await dbGetObject('bem', order.objectData.bemId);
          await dbUpdateObject('bem', order.objectData.bemId, {
            ...bemObj.objectData,
            status: 'disponivel',
            estadoConservacao: 'bom',
            updatedAt: now
          });
        } catch (bemErr) {
          console.warn('Não foi possível restaurar status do bem:', bemErr);
        }
      }

      // 3. Inserir registo permanente no Histórico de Manutenções
      await dbCreateObject('historico_manutencao', {
        manutencaoId: orderId,
        numeroOrdem: order.objectData.numeroOrdem,
        tipo: order.objectData.tipo || 'correctiva',
        bemId: order.objectData.bemId,
        bemCodigo: order.objectData.bemCodigo,
        bemNome: order.objectData.bemNome,
        departamento: order.objectData.departamento,
        solicitante: order.objectData.solicitanteNome,
        tecnico: user.name,
        tipoIntervencao: conclusaoData.tipoIntervencao,
        custoTotal: parseFloat(conclusaoData.custoFinal || 0),
        tempoGastoHoras: parseFloat(conclusaoData.tempoGastoHoras || 1),
        pecasSubstituidas: conclusaoData.pecasUtilizadas || 'Nenhuma',
        relatorio: conclusaoData.relatorioFinal,
        dataInicio: order.objectData.dataAbertura || order.objectData.dataAtribuicao,
        dataFim: now
      });

      // 4. Notificar o Patrimônio e a Administração que a manutenção foi concluída pelo Técnico
      try {
        const msgConclusao = `✅ Manutenção Concluída: O bem "${order.objectData.bemNome}" (${order.objectData.bemCodigo}) foi reparado pelo técnico ${user.name} e está novamente funcional. Custo final: ${Number(conclusaoData.custoFinal).toLocaleString('pt-MZ')} MZN.`;

        // Notificar o Patrimônio
        await dbCreateObject('notificacao', {
          destinatario: 'patrimonio',
          mensagem: msgConclusao,
          tipo: 'nova_manutencao',
          lida: false,
          createdAt: now
        });

        // Notificar a Administração
        await dbCreateObject('notificacao', {
          destinatario: 'Administração',
          mensagem: msgConclusao,
          tipo: 'nova_manutencao',
          lida: false,
          createdAt: now
        });

        // Notificar o Solicitante inicial se existir email
        if (order.objectData.solicitanteEmail) {
          await dbCreateObject('notificacao', {
            destinatario: order.objectData.solicitanteEmail,
            mensagem: `✅ O seu pedido de reparação para o bem "${order.objectData.bemNome}" foi concluído pelo técnico.`,
            tipo: 'nova_manutencao',
            lida: false,
            createdAt: now
          });
        }
      } catch (nErr) {
        console.warn('Erro ao notificar conclusão ao Património e Administração:', nErr);
      }

      await logAuditAction(
        AUDIT_ACTIONS.CONCLUIR_MANUTENCAO,
        `Manutenção ${order.objectData.numeroOrdem} concluída com sucesso no bem ${order.objectData.bemCodigo}. Custo final: ${conclusaoData.custoFinal} MZN`,
        user
      );

      showNotification(`Manutenção ${order.objectData.numeroOrdem} concluída com sucesso! Bem restaurado para Funcional.`);
      setModalType(null);
      loadAllData();
    } catch (error) {
      console.error('Erro ao concluir manutenção:', error);
      showNotification('Erro ao concluir: ' + error.message, 'error');
    }
    setIsProcessing(false);
  };

  // FLUXO PREVENTIVO: Agendamento de Manutenção Preventiva
  const handleAgendarPreventiva = async (formData) => {
    setIsProcessing(true);
    try {
      const numeroOrdem = `PREV-${new Date().getFullYear()}-${String(manutencoes.length + 1).padStart(4, '0')}`;
      const now = new Date().toISOString();

      const novaPreventiva = {
        numeroOrdem,
        tipo: 'preventiva',
        bemId: formData.bemId || '',
        bemCodigo: formData.bemCodigo || 'LOTE/LOCAL',
        bemNome: formData.bemNome || formData.titulo,
        departamento: formData.departamento,
        localizacao: formData.localizacao,
        solicitanteNome: user.name,
        solicitanteEmail: user.username,
        urgencia: 'media',
        descricaoRotina: formData.descricaoRotina,
        dataAgendada: formData.dataAgendada,
        tecnicoId: formData.tecnicoId,
        tecnicoNome: formData.tecnicoNome,
        tecnicoEmail: formData.tecnicoEmail,
        status: 'preventiva_agendada',
        dataAbertura: now,
        historicoFluxo: [
          {
            etapa: 'Agendamento Preventivo',
            responsavel: user.name,
            cargo: user.department,
            data: now,
            detalhe: `Agendada para ${formData.dataAgendada}: ${formData.descricaoRotina}`
          }
        ]
      };

      await dbCreateObject('manutencao', novaPreventiva);

      await logAuditAction(
        AUDIT_ACTIONS.AGENDAR_MANUTENCAO_PREVENTIVA,
        `Manutenção preventiva ${numeroOrdem} agendada para ${formData.dataAgendada} (${formData.descricaoRotina})`,
        user
      );

      showNotification(`Manutenção preventiva ${numeroOrdem} agendada com sucesso!`);
      setModalType(null);
      loadAllData();
    } catch (error) {
      console.error('Erro ao agendar preventiva:', error);
      showNotification('Erro ao agendar: ' + error.message, 'error');
    }
    setIsProcessing(false);
  };

  // ==========================================================
  // FILTRAGEM
  // ==========================================================
  const filteredManutencoes = manutencoes.filter(m => {
    const data = m.objectData || {};
    
    // Filtro por Usuário Comum e Técnico
    const isPatrimonio = user?.role === 'patrimonio' || user?.department === 'Departamento de Patrimônio';
    const isAdmin = user?.role === 'admin' || user?.department === 'Administração';
    const isTecnico = user?.role === 'tecnico' || user?.department === 'Manutenção';

    if (!isAdmin && !isPatrimonio) {
      if (isTecnico) {
        // Técnico apenas vê o que lhe foi atribuído OU o que ele próprio solicitou
        const isAssigned = data.tecnicoEmail === user?.username || data.tecnicoNome === user?.name;
        const isRequested = data.solicitanteEmail === user?.username;
        if (!isAssigned && !isRequested) {
          return false;
        }
      } else {
        // Utilizador comum apenas vê as suas próprias solicitações
        if (data.solicitanteEmail !== user?.username) {
          return false;
        }
      }
    }

    // Se for técnico, na aba de ordens destaca as dele ou todas abertas
    if (filterStatus !== 'todos' && data.status !== filterStatus) return false;
    if (filterTipo !== 'todos' && data.tipo !== filterTipo) return false;
    if (filterUrgencia !== 'todos' && data.urgencia !== filterUrgencia) return false;

    if (searchTerm.trim() !== '') {
      const term = searchTerm.toLowerCase();
      const codeMatch = (data.bemCodigo || '').toLowerCase().includes(term);
      const nameMatch = (data.bemNome || '').toLowerCase().includes(term);
      const numMatch = (data.numeroOrdem || '').toLowerCase().includes(term);
      const descMatch = (data.descricaoAvaria || data.descricaoRotina || '').toLowerCase().includes(term);
      const techMatch = (data.tecnicoNome || '').toLowerCase().includes(term);
      const deptMatch = (data.departamento || '').toLowerCase().includes(term);
      if (!codeMatch && !nameMatch && !numMatch && !descMatch && !techMatch && !deptMatch) {
        return false;
      }
    }

    return true;
  });

  // Estatísticas Rápidas
  const stats = {
    total: manutencoes.length,
    pendentes: manutencoes.filter(m => m.objectData?.status === 'pendente').length,
    emAndamento: manutencoes.filter(m => ['atribuido_tecnico', 'orcamento_submetido', 'aprovado_em_execucao', 'preventiva_agendada'].includes(m.objectData?.status)).length,
    aguardandoAdmin: manutencoes.filter(m => m.objectData?.status === 'aguardando_aprovacao_admin').length,
    concluidas: manutencoes.filter(m => m.objectData?.status === 'concluido').length,
    custoTotal: historico.reduce((acc, h) => acc + (parseFloat(h.objectData?.custoTotal) || 0), 0)
  };

  const isPatrimonio = user?.role === 'patrimonio' || user?.department === 'Departamento de Patrimônio';
  const isAdmin = user?.role === 'admin' || user?.department === 'Administração';
  const isTecnico = user?.role === 'tecnico' || user?.department === 'Manutenção';

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}

      <main className="flex-grow p-4 md:p-6 max-w-7xl mx-auto w-full">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => window.location.href = 'dashboard.html'}
              className="p-2 bg-white rounded-lg border hover:bg-gray-100 text-gray-700 transition"
              title="Voltar ao Dashboard"
            >
              <div className="icon-arrow-left text-xl"></div>
            </button>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-800 flex items-center gap-2">
                <span>Gestão de Manutenção</span>
              </h1>
              <p className="text-xs md:text-sm text-gray-500">
                Registo de reparações, ordens de trabalho e histórico técnico de bens
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 w-full sm:w-auto">
            <button
              onClick={() => setModalType('novo_pedido')}
              className="btn btn-primary flex items-center gap-2 text-sm shadow-sm"
            >
              <div className="icon-plus text-base"></div>
              <span>Reportar Avaria</span>
            </button>
            {(isAdmin || isPatrimonio) && (
              <button
                onClick={() => setModalType('preventiva')}
                className="btn btn-secondary flex items-center gap-2 text-sm shadow-sm"
              >
                <div className="icon-calendar text-base"></div>
                <span>Agendar Preventiva</span>
              </button>
            )}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 md:gap-4 mb-6">
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <p className="text-xs text-gray-500 font-medium">Total Pedidos</p>
            <p className="text-2xl font-bold text-gray-800 mt-1">{stats.total}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <p className="text-xs text-gray-500 font-medium">Triagem Pendente</p>
            <p className="text-2xl font-bold text-[var(--primary-color)] mt-1">{stats.pendentes}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <p className="text-xs text-gray-500 font-medium">Em Andamento</p>
            <p className="text-2xl font-bold text-[var(--secondary-color)] mt-1">{stats.emAndamento}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <p className="text-xs text-gray-500 font-medium">Aguardando Admin</p>
            <p className="text-2xl font-bold font-semibold text-gray-700 mt-1">{stats.aguardandoAdmin}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <p className="text-xs text-gray-500 font-medium">Concluídas</p>
            <p className="text-2xl font-bold text-gray-600 mt-1">{stats.concluidas}</p>
          </div>
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <p className="text-xs text-gray-500 font-medium">Custo Total (MZN)</p>
            <p className="text-lg md:text-xl font-bold text-gray-800 mt-1">
              {stats.custoTotal.toLocaleString('pt-MZ', { minimumFractionDigits: 0 })}
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 mb-6 bg-white rounded-t-xl px-4 pt-2 shadow-sm overflow-x-auto">
          <button
            onClick={() => setActiveTab('ordens')}
            className={`px-4 py-3 font-medium text-sm border-b-2 transition whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'ordens'
                ? 'border-[var(--primary-color)] text-[var(--primary-color)] font-semibold'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <span>Ordens de Manutenção ({manutencoes.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('historico')}
            className={`px-4 py-3 font-medium text-sm border-b-2 transition whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'historico'
                ? 'border-[var(--primary-color)] text-[var(--primary-color)] font-semibold'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <span>Histórico de Manutenções ({historico.length})</span>
          </button>
        </div>

        {/* TAB 1: ORDENS DE MANUTENÇÃO */}
        {activeTab === 'ordens' && (
          <div className="space-y-4">
            {/* Filters Bar */}
            <div className="bg-white p-4 rounded-xl border shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
              <div className="w-full md:w-80">
                <input
                  type="text"
                  placeholder="Pesquisar código, bem, ordem..."
                  className="input-field text-sm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div className="flex flex-wrap gap-2 w-full md:w-auto">
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="input-field text-xs md:text-sm py-2"
                >
                  <option value="todos">Todos os Estados</option>
                  <option value="pendente">Pendente (Triagem)</option>
                  <option value="atribuido_tecnico">Atribuído ao Técnico</option>
                  <option value="orcamento_submetido">Orçamento Submetido</option>
                  <option value="aguardando_aprovacao_admin">Aguardando Admin</option>
                  <option value="aprovado_em_execucao">Aprovado (Em Reparação)</option>
                  <option value="rejeitado">Reprovado</option>
                  <option value="concluido">Concluído</option>
                  <option value="preventiva_agendada">Preventiva Agendada</option>
                </select>

                <select
                  value={filterTipo}
                  onChange={(e) => setFilterTipo(e.target.value)}
                  className="input-field text-xs md:text-sm py-2"
                >
                  <option value="todos">Todos os Tipos</option>
                  <option value="correctiva">Correctiva (Avaria)</option>
                  <option value="preventiva">Preventiva (Rotina)</option>
                </select>

                <select
                  value={filterUrgencia}
                  onChange={(e) => setFilterUrgencia(e.target.value)}
                  className="input-field text-xs md:text-sm py-2"
                >
                  <option value="todos">Todas Urgências</option>
                  <option value="critica">Crítica</option>
                  <option value="alta">Alta</option>
                  <option value="media">Média</option>
                  <option value="baixa">Baixa</option>
                </select>
              </div>
            </div>

            {/* List */}
            {filteredManutencoes.length === 0 ? (
              <div className="bg-white rounded-xl border p-12 text-center text-gray-500">
                <div className="icon-tool text-4xl mb-3 mx-auto text-gray-400"></div>
                <p className="text-lg font-semibold text-gray-700">Nenhum pedido de manutenção encontrado</p>
                <p className="text-sm text-gray-500 mt-1">Clique em "Reportar Avaria" para abrir um novo chamado.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {filteredManutencoes.map(m => (
                  <ManutencaoCard
                    key={m.objectId}
                    order={m}
                    currentUser={user}
                    isAdmin={isAdmin}
                    isPatrimonio={isPatrimonio}
                    isTecnico={isTecnico}
                    onOpenModal={(type, order) => {
                      setSelectedOrder(order);
                      setModalType(type);
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: HISTÓRICO POR BEM */}
        {activeTab === 'historico' && (
          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <h2 className="text-lg font-bold text-gray-800 mb-4">
              Histórico Permanente de Intervenções e Auditoria
            </h2>
            <p className="text-sm text-gray-500 mb-6">
              Registo auditado de todas as manutenções correctivas e preventivas concluídas por equipamento.
            </p>

            {historico.length === 0 ? (
              <div className="text-center py-10 text-gray-500 border rounded-lg">
                <p>Nenhuma manutenção foi concluída ainda.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm border-collapse">
                  <thead>
                    <tr className="bg-gray-100 border-b text-gray-700 font-semibold">
                      <th className="p-3">Ordem</th>
                      <th className="p-3">Código Bem</th>
                      <th className="p-3">Equipamento</th>
                      <th className="p-3">Tipo</th>
                      <th className="p-3">Intervenção / Reparação</th>
                      <th className="p-3">Técnico</th>
                      <th className="p-3">Custo (MZN)</th>
                      <th className="p-3">Data Conclusão</th>
                    </tr>
                  </thead>
                  <tbody>
                    {historico.map(h => {
                      const d = h.objectData || {};
                      return (
                        <tr key={h.objectId} className="border-b hover:bg-gray-50 transition">
                          <td className="p-3 font-mono font-bold text-[var(--primary-color)]">{d.numeroOrdem}</td>
                          <td className="p-3 font-mono text-gray-800">{d.bemCodigo}</td>
                          <td className="p-3 font-medium text-gray-900">{d.bemNome}</td>
                          <td className="p-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                              d.tipo === 'preventiva' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                            }`}>
                              {d.tipo === 'preventiva' ? 'Preventiva' : 'Correctiva'}
                            </span>
                          </td>
                          <td className="p-3 text-gray-700">{d.tipoIntervencao || d.relatorio}</td>
                          <td className="p-3 text-gray-600">{d.tecnico}</td>
                          <td className="p-3 font-bold text-gray-800">
                            {(parseFloat(d.custoTotal) || 0).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT
                          </td>
                          <td className="p-3 text-gray-500 text-xs">
                            {d.dataFim ? new Date(d.dataFim).toLocaleString('pt-BR') : 'N/A'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </main>

      {/* ==========================================================
          MODAIS DO FLUXO DE MANUTENÇÃO
      ========================================================== */}

      {/* Modal 1: Reportar Avaria (Docente / Usuário) */}
      {modalType === 'novo_pedido' && (
        <ModalNovoPedido
          bens={bens}
          user={user}
          onClose={() => setModalType(null)}
          onSubmit={handleCriarPedidoCorrectivo}
          isProcessing={isProcessing}
        />
      )}

      {/* Modal 2: Património Atribui Técnico */}
      {modalType === 'atribuir' && selectedOrder && (
        <ModalAtribuirTecnico
          order={selectedOrder}
          tecnicos={tecnicos}
          onClose={() => setModalType(null)}
          onSubmit={(tecData) => handleAtribuirTecnico(selectedOrder.objectId, tecData)}
          isProcessing={isProcessing}
        />
      )}

      {/* Modal 3: Técnico Submete Diagnóstico & Orçamento */}
      {modalType === 'orcamento' && selectedOrder && (
        <ModalSubmeterOrcamento
          order={selectedOrder}
          onClose={() => setModalType(null)}
          onSubmit={(orcData) => handleSubmeterOrcamento(selectedOrder.objectId, orcData)}
          isProcessing={isProcessing}
        />
      )}

      {/* Modal 4: Património Encaminha Orçamento para Administração */}
      {modalType === 'encaminhar_admin' && selectedOrder && (
        <ModalEncaminharAdmin
          order={selectedOrder}
          onClose={() => setModalType(null)}
          onSubmit={(parecer) => handleEncaminharAdmin(selectedOrder.objectId, parecer)}
          isProcessing={isProcessing}
        />
      )}

      {/* Modal 5: Administradora Aprova/Reprova */}
      {modalType === 'aprovar_admin' && selectedOrder && (
        <ModalAprovarAdmin
          order={selectedOrder}
          onClose={() => setModalType(null)}
          onSubmit={(decisao, obs) => handleDecisaoAdmin(selectedOrder.objectId, decisao, obs)}
          isProcessing={isProcessing}
        />
      )}

      {/* Modal 6: Técnico Conclui Reparação */}
      {modalType === 'concluir' && selectedOrder && (
        <ModalConcluirReparacao
          order={selectedOrder}
          onClose={() => setModalType(null)}
          onSubmit={(concData) => handleConcluirReparacao(selectedOrder.objectId, concData)}
          isProcessing={isProcessing}
        />
      )}

      {/* Modal 7: Agendar Manutenção Preventiva */}
      {modalType === 'preventiva' && (
        <ModalAgendarPreventiva
          bens={bens}
          tecnicos={tecnicos}
          onClose={() => setModalType(null)}
          onSubmit={handleAgendarPreventiva}
          isProcessing={isProcessing}
        />
      )}

      {/* Modal 8: Visualizar Detalhes & Timeline do Fluxo */}
      {modalType === 'detalhes' && selectedOrder && (
        <ModalDetalhesManutencao
          order={selectedOrder}
          onClose={() => setModalType(null)}
          onPrint={() => setModalType('imprimir')}
        />
      )}

      {/* Modal 9: Impressão de Ficha de Manutenção */}
      {modalType === 'imprimir' && selectedOrder && (
        <ModalImprimirFicha
          order={selectedOrder}
          onClose={() => setModalType(null)}
        />
      )}

      <footer className="bg-white py-3 text-center text-gray-500 text-xs md:text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

// ==========================================================
// CARD DE ORDEM DE MANUTENÇÃO
// ==========================================================
function ManutencaoCard({ order, currentUser, isAdmin, isPatrimonio, isTecnico, onOpenModal }) {
  const d = order.objectData || {};

  const statusConfig = {
    pendente: { label: 'Pendente (Aguardando Triagem)', color: 'bg-red-50 text-red-700 border-red-200' },
    atribuido_tecnico: { label: 'Atribuído ao Técnico (Diagnóstico)', color: 'bg-orange-50 text-orange-700 border-orange-200' },
    orcamento_submetido: { label: 'Orçamento Submetido (Validação Património)', color: 'bg-orange-50 text-orange-700 border-orange-200' },
    aguardando_aprovacao_admin: { label: 'Aguardando Aprovação da Administração', color: 'bg-orange-50 text-orange-700 border-orange-200' },
    aprovado_em_execucao: { label: 'Aprovado (Em Reparação)', color: 'bg-green-50 text-green-700 border-green-200' },
    rejeitado: { label: 'Orçamento Reprovado', color: 'bg-gray-100 text-gray-700 border-gray-300' },
    concluido: { label: 'Concluído (Bem Funcional)', color: 'bg-green-50 text-green-700 border-green-200' },
    preventiva_agendada: { label: 'Preventiva Agendada', color: 'bg-blue-50 text-blue-700 border-blue-200' }
  };

  const urgenciaConfig = {
    critica: 'bg-red-100 text-red-800 border-red-200',
    alta: 'bg-red-50 text-red-700 border-red-200',
    media: 'bg-orange-50 text-orange-700 border-orange-200',
    baixa: 'bg-gray-50 text-gray-700 border-gray-200'
  };

  const currentStatus = statusConfig[d.status] ? { ...statusConfig[d.status] } : { label: d.status, color: 'bg-gray-100 text-gray-800' };
  if (d.status === 'concluido' && d.proporAbate && d.decisaoAdmin === 'aprovado') {
      currentStatus.label = 'Concluído (Bem Abatido)';
      currentStatus.color = 'bg-red-50 text-red-700 border-red-200 font-bold';
  }

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 md:p-5 hover:border-[var(--primary-color)] transition">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 border-b pb-3 mb-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono font-bold text-base md:text-lg text-[var(--primary-color)]">{d.numeroOrdem}</span>
          <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${currentStatus.color}`}>
            {currentStatus.label}
          </span>
          <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${urgenciaConfig[d.urgencia] || 'bg-gray-50 text-gray-700 border-gray-200'}`}>
            Urgência: {(d.urgencia || 'normal').toUpperCase()}
          </span>
          <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${d.tipo === 'preventiva' ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-red-50 text-red-700 border-red-200'}`}>
            {d.tipo === 'preventiva' ? 'Preventiva' : 'Correctiva'}
          </span>
        </div>

        <div className="text-xs text-gray-500">
          Aberto em: {d.dataAbertura ? new Date(d.dataAbertura).toLocaleString('pt-BR') : 'N/A'}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mb-4">
        {/* Coluna 1: Bem */}
        <div className="space-y-1">
          <p className="text-xs font-semibold text-gray-500 uppercase">Equipamento / Bem</p>
          <p className="font-bold text-gray-800">{d.bemNome}</p>
          <p className="font-mono text-xs text-gray-600">Código: {d.bemCodigo}</p>
          <p className="text-xs text-gray-600">Local: {d.localizacao || d.departamento || 'Instalações UCM-FADIR'}</p>
        </div>

        {/* Coluna 2: Descrição / Diagnóstico */}
        <div className="space-y-1">
          <p className="text-xs font-semibold text-gray-500 uppercase">Avaria / Descrição</p>
          <p className="text-gray-700 line-clamp-2">{d.descricaoAvaria || d.descricaoRotina}</p>
          {d.diagnosticoTecnico && (
            <p className="text-xs text-gray-700 font-medium">
              <strong>Diagnóstico:</strong> {d.diagnosticoTecnico}
            </p>
          )}
          {(isAdmin || isPatrimonio || isTecnico) && d.custoEstimado > 0 && (
            <p className="text-xs text-gray-800 font-bold">
              Custo Estimado: {Number(d.custoEstimado).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT
            </p>
          )}
          {d.sugestaoAbate && (
            <div className="mt-1 p-1.5 bg-red-50 border border-red-200 rounded text-[11px] text-red-700 font-semibold leading-tight">
              ⚠️ Custo supera o valor do bem {d.valorAquisicao > 0 ? `(${Number(d.valorAquisicao).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MT)` : ''} — Abate Sugerido
            </div>
          )}
        </div>

        {/* Coluna 3: Responsáveis */}
        <div className="space-y-1">
          <p className="text-xs font-semibold text-gray-500 uppercase">Intervenientes</p>
          
          {(isAdmin || isPatrimonio || isTecnico) && (
            <p className="text-xs text-gray-700"><strong>Solicitante:</strong> {d.solicitanteNome} ({d.solicitanteDepartamento})</p>
          )}
          
          {(isAdmin || isPatrimonio || (!isTecnico)) && (
            <p className="text-xs text-gray-700">
              <strong>Técnico:</strong> {d.tecnicoNome ? `${d.tecnicoNome}` : <span className="text-gray-400 italic">Não atribuído</span>}
            </p>
          )}
          
          {(isAdmin || isPatrimonio) && d.aprovadorNome && (
            <p className="text-xs text-gray-700">
              <strong>Admin:</strong> {d.aprovadorNome} ({d.decisaoAdmin === 'aprovado' ? 'Aprovado' : 'Reprovado'})
            </p>
          )}
        </div>
      </div>

      {/* Ações contextuais de acordo com o estágio do fluxo e o perfil do utilizador */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t bg-gray-50 -mx-4 md:-mx-5 -mb-4 md:-mb-5 p-3 rounded-b-xl">
        <div className="flex gap-2">
          {(isAdmin || isPatrimonio || isTecnico) && (
            <button
              onClick={() => onOpenModal('detalhes', order)}
              className="btn btn-secondary text-xs py-1.5"
            >
              Ver Timeline
            </button>
          )}
          {(isAdmin || isPatrimonio) && (
            <button
              onClick={() => onOpenModal('imprimir', order)}
              className="btn btn-secondary text-xs py-1.5"
            >
              Imprimir Ficha
            </button>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {/* PASSO 2: Património atribui técnico */}
          {(isPatrimonio || isAdmin) && d.status === 'pendente' && (
            <button
              onClick={() => onOpenModal('atribuir', order)}
              className="btn btn-primary text-xs py-1.5"
            >
              Atribuir Técnico
            </button>
          )}

          {/* PASSO 3: Técnico submete orçamento */}
          {(isTecnico || isAdmin) && (d.status === 'atribuido_tecnico' || (d.status === 'preventiva_agendada' && isTecnico)) && (
            <button
              onClick={() => onOpenModal('orcamento', order)}
              className="btn btn-primary text-xs py-1.5"
            >
              Submeter Diagnóstico & Orçamento
            </button>
          )}

          {/* PASSO 4: Património encaminha para Administração */}
          {(isPatrimonio || isAdmin) && d.status === 'orcamento_submetido' && (
            <button
              onClick={() => onOpenModal('encaminhar_admin', order)}
              className={`btn text-xs py-1.5 ${d.sugestaoAbate ? 'bg-red-600 hover:bg-red-700 text-white font-bold' : 'btn-primary'}`}
            >
              {d.sugestaoAbate ? 'Encaminhar como Proposta de Abate' : 'Encaminhar à Administração'}
            </button>
          )}

          {/* PASSO 5: Administradora Aprova / Reprova */}
          {isAdmin && d.status === 'aguardando_aprovacao_admin' && (
            <button
              onClick={() => onOpenModal('aprovar_admin', order)}
              className="btn btn-primary text-xs py-1.5"
            >
              Avaliar Orçamento (Admin)
            </button>
          )}

          {/* PASSO 6: Apenas o Técnico Conclui Reparação e Emite Relatório */}
          {isTecnico && (d.status === 'aprovado_em_execucao' || d.status === 'preventiva_agendada') && (
            <button
              onClick={() => onOpenModal('concluir', order)}
              className="btn btn-success text-xs py-1.5 font-bold"
            >
              Concluir e Emitir Relatório
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ==========================================================
// MODAL 1: REPORTAR AVARIA (DOCENTE / UTILIZADOR)
// ==========================================================
function ModalNovoPedido({ bens, user, onClose, onSubmit, isProcessing }) {
  const params = new URLSearchParams(window.location.search);
  const codeFromUrl = params.get('code') || params.get('codigo');
  
  const initialBem = codeFromUrl ? bens.find(b => b.objectData?.codigo === codeFromUrl) : null;

  const [selectedBemId, setSelectedBemId] = React.useState(initialBem ? initialBem.objectId : '');
  const [urgencia, setUrgencia] = React.useState('media');
  const [descricaoAvaria, setDescricaoAvaria] = React.useState('');
  const [localizacao, setLocalizacao] = React.useState(initialBem ? (initialBem.objectData.localizacao || initialBem.objectData.departamento || '') : '');
  const [searchTerm, setSearchTerm] = React.useState(codeFromUrl || '');
  const [isScannerOpen, setIsScannerOpen] = React.useState(false);

  const selectedBem = bens.find(b => b.objectId === selectedBemId);

  const handleScanSuccess = (scannedData) => {
    setIsScannerOpen(false);
    if (scannedData) {
      let scannedCode = scannedData;
      try {
        const url = new URL(scannedData);
        scannedCode = url.searchParams.get('codigo') || url.searchParams.get('code') || scannedData;
      } catch (e) {
        // Ignorar se não for URL
      }
      
      setSearchTerm(scannedCode);
      const b = bens.find(item => item.objectData.codigo === scannedCode);
      if (b) {
        setSelectedBemId(b.objectId);
        setLocalizacao(b.objectData.localizacao || b.objectData.departamento || '');
      } else {
        alert('Bem com o código ' + scannedCode + ' não encontrado no sistema.');
        setSelectedBemId('');
      }
    }
  };

  const filteredBens = bens.filter(b => {
    const d = b.objectData || {};
    const term = searchTerm.toLowerCase();
    return (
      (d.codigo || '').toLowerCase().includes(term) ||
      (d.nome || '').toLowerCase().includes(term) ||
      (d.departamento || '').toLowerCase().includes(term)
    );
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedBem) {
      alert('Por favor selecione um bem patrimonial.');
      return;
    }
    onSubmit({
      bemId: selectedBem.objectId,
      bemCodigo: selectedBem.objectData.codigo,
      bemNome: selectedBem.objectData.nome,
      departamento: selectedBem.objectData.departamento,
      localizacao: localizacao || selectedBem.objectData.localizacao || selectedBem.objectData.departamento,
      urgencia,
      descricaoAvaria
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6">
        <div className="flex justify-between items-center border-b pb-3 mb-4">
          <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <span>Reportar Avaria de Equipamento</span>
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl font-bold">&times;</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Seleção do Bem */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Código Patrimonial do Equipamento *
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                placeholder="Ex: 7021727000001"
                className="input-field text-sm flex-1"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  // Auto-selecionar se o código coincidir exatamente
                  const b = bens.find(item => item.objectData.codigo === e.target.value.trim());
                  if (b) {
                    setSelectedBemId(b.objectId);
                    setLocalizacao(b.objectData.localizacao || b.objectData.departamento || '');
                  } else {
                    setSelectedBemId('');
                  }
                }}
              />
              <button 
                type="button"
                className="btn bg-gray-200 hover:bg-gray-300 text-gray-800"
                onClick={() => {
                  const b = bens.find(item => item.objectData.codigo === searchTerm.trim());
                  if (b) {
                    setSelectedBemId(b.objectId);
                    setLocalizacao(b.objectData.localizacao || b.objectData.departamento || '');
                  } else {
                    alert('Nenhum equipamento encontrado com este código.');
                    setSelectedBemId('');
                  }
                }}
              >
                Procurar
              </button>
              <button 
                type="button"
                className="btn bg-[var(--primary-color)] hover:bg-[var(--secondary-color)] text-white flex items-center gap-1.5"
                onClick={() => setIsScannerOpen(true)}
                title="Escanear QR Code"
              >
                <div className="icon-qr-code text-base"></div>
                <span>Escanear</span>
              </button>
            </div>
          </div>

          {selectedBem && (
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs space-y-1">
              <p><strong>Equipamento Selecionado:</strong> {selectedBem.objectData.nome}</p>
              <p><strong>Código Patrimonial:</strong> {selectedBem.objectData.codigo}</p>
              <p><strong>Departamento:</strong> {selectedBem.objectData.departamento}</p>
              <p><strong>Marca / Modelo:</strong> {selectedBem.objectData.marca || 'N/A'} {selectedBem.objectData.modelo || ''}</p>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nível de Urgência *</label>
              <select
                value={urgencia}
                onChange={(e) => setUrgencia(e.target.value)}
                className="input-field text-sm"
                required
              >
                <option value="baixa">Baixa (Pode aguardar rotina)</option>
                <option value="media">Média (Impacto parcial)</option>
                <option value="alta">Alta (Prejudica atividades)</option>
                <option value="critica">Crítica (Interrupção total / Sala de aula)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Local Exato / Sala *</label>
              <input
                type="text"
                className="input-field text-sm"
                placeholder="Ex: Sala 102, Bloco B"
                value={localizacao}
                onChange={(e) => setLocalizacao(e.target.value)}
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Descrição Detalhada da Avaria *</label>
            <textarea
              rows="3"
              className="input-field text-sm"
              placeholder="Descreva o que está acontecendo (ex: lâmpada não acende, faz barulho, não liga, vazamento)..."
              value={descricaoAvaria}
              onChange={(e) => setDescricaoAvaria(e.target.value)}
              required
            ></textarea>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t">
            <button type="button" onClick={onClose} className="btn btn-secondary">Cancelar</button>
            <button type="submit" disabled={isProcessing} className="btn btn-primary">
              {isProcessing ? 'Enviando...' : 'Submeter Pedido de Manutenção'}
            </button>
          </div>
        </form>
      </div>

      <QRScannerModal 
        isOpen={isScannerOpen} 
        onClose={() => setIsScannerOpen(false)} 
        onScanSuccess={handleScanSuccess} 
      />
    </div>
  );
}

// ==========================================================
// MODAL 2: PATRIMÓNIO ATRIBUI TÉCNICO
// ==========================================================
function ModalAtribuirTecnico({ order, tecnicos, onClose, onSubmit, isProcessing }) {
  const [selectedTecId, setSelectedTecId] = React.useState('');
  const d = order.objectData || {};

  const handleSubmit = (e) => {
    e.preventDefault();
    const tec = tecnicos.find(t => t.objectId === selectedTecId);
    if (!tec) {
      alert('Selecione um técnico.');
      return;
    }
    onSubmit({
      tecnicoId: tec.objectId,
      tecnicoNome: tec.objectData.name,
      tecnicoEmail: tec.objectData.username
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
        <div className="flex justify-between items-center border-b pb-3 mb-4">
          <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
            <span>👨‍🔧</span> Atribuir Técnico de Manutenção
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl font-bold">&times;</button>
        </div>

        <div className="mb-4 text-xs bg-gray-50 p-3 rounded-lg space-y-1">
          <p><strong>Ordem:</strong> {d.numeroOrdem}</p>
          <p><strong>Bem:</strong> [{d.bemCodigo}] {d.bemNome}</p>
          <p><strong>Avaria:</strong> {d.descricaoAvaria}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Selecione o Técnico Responsável *</label>
            <select
              value={selectedTecId}
              onChange={(e) => setSelectedTecId(e.target.value)}
              className="input-field text-sm"
              required
            >
              <option value="">Selecione um técnico...</option>
              {tecnicos.map(t => (
                <option key={t.objectId} value={t.objectId}>
                  {t.objectData.name} ({t.objectData.department || 'Manutenção'}) - {t.objectData.username}
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t">
            <button type="button" onClick={onClose} className="btn btn-secondary">Cancelar</button>
            <button type="submit" disabled={isProcessing} className="btn btn-primary">
              {isProcessing ? 'Gravando...' : 'Confirmar Atribuição'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ==========================================================
// MODAL 3: TÉCNICO SUBMETE DIAGNÓSTICO E ORÇAMENTO
// ==========================================================
function ModalSubmeterOrcamento({ order, onClose, onSubmit, isProcessing }) {
  const d = order.objectData || {};
  const [diagnosticoTecnico, setDiagnosticoTecnico] = React.useState(d.diagnosticoTecnico || '');
  const [custoEstimado, setCustoEstimado] = React.useState(d.custoEstimado || '');
  const [pecasEstimadas, setPecasEstimadas] = React.useState(d.pecasEstimadas || '');
  const [tempoEstimadoHoras, setTempoEstimadoHoras] = React.useState(d.tempoEstimadoHoras || '2');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      diagnosticoTecnico,
      custoEstimado: parseFloat(custoEstimado || 0),
      pecasEstimadas,
      tempoEstimadoHoras: parseFloat(tempoEstimadoHoras || 1)
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex justify-between items-center border-b pb-3 mb-4">
          <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
            <span>📝</span> Diagnóstico & Orçamento Técnico
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl font-bold">&times;</button>
        </div>

        <div className="mb-4 text-xs bg-gray-50 p-3 rounded-lg space-y-1">
          <p><strong>Ordem:</strong> {d.numeroOrdem}</p>
          <p><strong>Equipamento:</strong> [{d.bemCodigo}] {d.bemNome}</p>
          <p><strong>Avaria Relatada:</strong> {d.descricaoAvaria}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Diagnóstico Técnico da Avaria *</label>
            <textarea
              rows="3"
              className="input-field text-sm"
              placeholder="Descreva as causas identificadas e o que precisará ser feito..."
              value={diagnosticoTecnico}
              onChange={(e) => setDiagnosticoTecnico(e.target.value)}
              required
            ></textarea>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Custo Estimado (MZN) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="input-field text-sm"
                placeholder="Ex: 3500.00"
                value={custoEstimado}
                onChange={(e) => setCustoEstimado(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Prazo Estimado (Horas) *</label>
              <input
                type="number"
                step="0.5"
                min="0.5"
                className="input-field text-sm"
                placeholder="Ex: 2.5"
                value={tempoEstimadoHoras}
                onChange={(e) => setTempoEstimadoHoras(e.target.value)}
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Peças / Materiais Necessários</label>
            <input
              type="text"
              className="input-field text-sm"
              placeholder="Ex: 1x Lâmpada Projetor, 1x Cabo de Força"
              value={pecasEstimadas}
              onChange={(e) => setPecasEstimadas(e.target.value)}
            />
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t">
            <button type="button" onClick={onClose} className="btn btn-secondary">Cancelar</button>
            <button type="submit" disabled={isProcessing} className="btn btn-primary">
              {isProcessing ? 'Enviando...' : 'Enviar Orçamento ao Património'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ==========================================================
// MODAL 4: PATRIMÓNIO ENCAMINHA À ADMINISTRAÇÃO
// ==========================================================
function ModalEncaminharAdmin({ order, onClose, onSubmit, isProcessing }) {
  const d = order.objectData || {};
  const parecerPadrao = d.sugestaoAbate
    ? 'ALERTA: O custo de manutenção estimado é superior ao valor de aquisição do bem. O orçamento NÃO é compatível com os padrões de mercado. O Patrimônio propõe o abate definitivo do bem.'
    : 'Orçamento verificado e compatível com os padrões de mercado. Encaminhado para autorização financeira.';
  const [parecer, setParecer] = React.useState(parecerPadrao);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ parecerPatrimonio: parecer, proporAbate: d.sugestaoAbate || false });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-2 z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-lg mx-auto p-4 sm:p-6 max-h-screen overflow-y-auto">
        <div className="flex justify-between items-center border-b pb-3 mb-4">
          <h2 className="text-base sm:text-lg font-bold text-gray-800 pr-2">
            {d.sugestaoAbate ? 'Encaminhar como Proposta de Abate' : 'Encaminhar à Administração'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl font-bold flex-shrink-0">×</button>
        </div>

        <div className="mb-4 text-xs bg-blue-50 border border-blue-200 p-3 rounded-lg space-y-1">
          <p><strong>Ordem:</strong> {d.numeroOrdem}</p>
          <p><strong>Equipamento:</strong> [{d.bemCodigo}] {d.bemNome}</p>
          <p><strong>Técnico:</strong> {d.tecnicoNome}</p>
          <p><strong>Diagnóstico:</strong> {d.diagnosticoTecnico}</p>
          {d.valorAquisicao > 0 && (
            <p className="text-gray-700">
              <strong>Valor de Aquisição:</strong> {Number(d.valorAquisicao).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MZN
            </p>
          )}
          <p className="text-sm font-bold text-[var(--primary-color)] mt-1">
            Custo Estimado de Reparo: {Number(d.custoEstimado).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MZN
          </p>
        </div>

        {d.sugestaoAbate && (
          <div className="mb-3 p-2 bg-red-50 text-red-700 border border-red-200 rounded text-xs font-bold flex items-center gap-1.5">
            <span>🚨</span>
            <span>O custo estimado supera o valor de aquisição do bem. O sistema configurou automaticamente a proposta de Abate.</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Parecer do Gestor de Patrimônio *</label>
            <textarea
              rows="3"
              className="input-field text-sm"
              value={parecer}
              onChange={(e) => setParecer(e.target.value)} required></textarea>
          </div>
          <div className="flex flex-col sm:flex-row justify-end gap-2 pt-3 border-t">
            <button type="button" onClick={onClose} className="btn btn-secondary w-full sm:w-auto">Cancelar</button>
            <button type="submit" disabled={isProcessing} className={`btn w-full sm:w-auto ${d.sugestaoAbate ? 'bg-red-600 hover:bg-red-700 text-white font-bold' : 'btn-primary'}`}>
              {isProcessing ? 'Encaminhando...' : (d.sugestaoAbate ? 'Encaminhar como Proposta de Abate' : 'Confirmar Envio à Administração')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ==========================================================
// MODAL 5: ADMINISTRAÇÃO APROVA / REPROVA
// ==========================================================
function ModalAprovarAdmin({ order, onClose, onSubmit, isProcessing }) {
  const d = order.objectData || {};
  const isAbate = d.proporAbate === true;
  const [decisao, setDecisao] = React.useState('aprovado');
  const [observacao, setObservacao] = React.useState(isAbate ? 'Abate aprovado pela Administração Geral.' : 'Aprovado pela Administração Geral.');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(decisao, observacao);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-2 z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-lg mx-auto p-4 sm:p-6 max-h-screen overflow-y-auto">
        <div className="flex justify-between items-center border-b pb-3 mb-4">
          <h2 className="text-base sm:text-lg font-bold text-gray-800 pr-2">
            {isAbate ? 'Decisão: Proposta de Abate' : 'Decisão Administrativa de Manutenção'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl font-bold flex-shrink-0">×</button>
        </div>

        <div className="mb-4 text-xs bg-gray-50 border p-3 rounded-lg space-y-1">
          <p><strong>Ordem:</strong> {d.numeroOrdem}</p>
          <p><strong>Equipamento:</strong> [{d.bemCodigo}] {d.bemNome}</p>
          <p><strong>Técnico Responsável:</strong> {d.tecnicoNome}</p>
          <p><strong>Diagnóstico:</strong> {d.diagnosticoTecnico}</p>
          <p><strong>Parecer Patrimônio:</strong> {d.parecerPatrimonio}</p>
          <div className="p-2 bg-blue-50 border border-blue-200 rounded text-[var(--primary-color)] font-bold text-sm mt-2">
            Valor a Autorizar: {Number(d.custoEstimado).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MZN
          </div>
          {isAbate && (
            <div className="mt-2 p-3 bg-red-50 text-red-800 border border-red-300 rounded text-sm">
              <strong className="block mb-1 text-center uppercase">⚠️ Proposta de Abate Automático</strong>
              <p>O custo de manutenção estimado <strong>({(Number(d.custoEstimado) || 0).toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MZN)</strong> é superior ao valor de aquisição do bem.</p>
              <p className="mt-1">O Patrimônio recomenda o abate definitivo. Ao aprovar, o bem será marcado como <strong className="text-red-700">ABATIDO</strong> e removido do inventário ativo.</p>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Decisão *</label>
            <div className="flex flex-wrap gap-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="decisao"
                  value="aprovado"
                  checked={decisao === 'aprovado'}
                  onChange={() => {
                    setDecisao('aprovado');
                    setObservacao(isAbate ? 'Abate aprovado pela Administração Geral.' : 'Aprovado pela Administração Geral.');
                  }}
                />
                <span className="text-[var(--primary-color)] font-bold text-sm">{isAbate ? 'Aprovar Abate' : 'Aprovar Orçamento'}</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="decisao"
                  value="reprovado"
                  checked={decisao === 'reprovado'}
                  onChange={() => {
                    setDecisao('reprovado');
                    setObservacao(isAbate ? 'Abate não aprovado.' : 'Reprovado devido a restrições orçamentais.');
                  }}
                />
                <span className="text-gray-700 font-bold text-sm">{isAbate ? 'Rejeitar Abate' : 'Reprovar Orçamento'}</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Despacho / Observações *</label>
            <textarea
              rows="3"
              className="input-field text-sm"
              value={observacao}
              onChange={(e) => setObservacao(e.target.value)}
              required
            ></textarea>
          </div>

          <div className="flex flex-col sm:flex-row justify-end gap-2 pt-3 border-t">
            <button type="button" onClick={onClose} className="btn btn-secondary w-full sm:w-auto">Cancelar</button>
            <button
              type="submit"
              disabled={isProcessing}
              className="btn btn-primary w-full sm:w-auto"
            >
              {isProcessing ? 'Registando...' : `Confirmar ${decisao === 'aprovado' ? (isAbate ? 'Abate' : 'Aprovação') : 'Reprovação'}`}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ==========================================================
// MODAL 6: TÉCNICO CONCLUI REPARAÇÃO E RELATÓRIO FINAL
// ==========================================================
function ModalConcluirReparacao({ order, onClose, onSubmit, isProcessing }) {
  const d = order.objectData || {};
  const [tipoIntervencao, setTipoIntervencao] = React.useState('Substituição de Componentes e Testes Operacionais');
  const [custoFinal, setCustoFinal] = React.useState(d.custoEstimado || '0');
  const [tempoGastoHoras, setTempoGastoHoras] = React.useState(d.tempoEstimadoHoras || '2');
  const [pecasUtilizadas, setPecasUtilizadas] = React.useState(d.pecasEstimadas || '');
  const [relatorioFinal, setRelatorioFinal] = React.useState('Equipamento reparado com sucesso e submetido a testes operacionais. Bem pronto para retorno às atividades.');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      tipoIntervencao,
      custoFinal: parseFloat(custoFinal || 0),
      tempoGastoHoras: parseFloat(tempoGastoHoras || 1),
      pecasUtilizadas,
      relatorioFinal
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6">
        <div className="flex justify-between items-center border-b pb-3 mb-4">
          <h2 className="text-lg font-bold text-gray-800">
            Conclusão de Reparação &amp; Relatório Técnico
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl font-bold">&times;</button>
        </div>

        <div className="mb-4 text-xs bg-blue-50 border border-blue-200 p-3 rounded-lg space-y-1">
          <p><strong>Ordem:</strong> {d.numeroOrdem}</p>
          <p><strong>Equipamento:</strong> [{d.bemCodigo}] {d.bemNome}</p>
          <p><strong>Aprovação Admin:</strong> {d.aprovadorNome || 'Aprovado'}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Intervenção Realizada *</label>
            <input
              type="text"
              className="input-field text-sm"
              value={tipoIntervencao}
              onChange={(e) => setTipoIntervencao(e.target.value)}
              placeholder="Ex: Troca de lâmpada e limpeza de ventoinha"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Custo Final Real (MZN) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="input-field text-sm"
                value={custoFinal}
                onChange={(e) => setCustoFinal(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tempo Gasto (Horas) *</label>
              <input
                type="number"
                step="0.5"
                min="0.5"
                className="input-field text-sm"
                value={tempoGastoHoras}
                onChange={(e) => setTempoGastoHoras(e.target.value)}
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Peças e Materiais Utilizados</label>
            <input
              type="text"
              className="input-field text-sm"
              value={pecasUtilizadas}
              onChange={(e) => setPecasUtilizadas(e.target.value)}
              placeholder="Ex: 1x Lâmpada ELPLP96 original"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Relatório Técnico de Conclusão *</label>
            <textarea
              rows="3"
              className="input-field text-sm"
              value={relatorioFinal}
              onChange={(e) => setRelatorioFinal(e.target.value)}
              required
            ></textarea>
          </div>

          <div className="p-3 bg-blue-50 border border-blue-100 text-[var(--primary-color)] rounded-lg text-xs">
            Ao concluir, o bem <strong>[{d.bemCodigo}]</strong> voltará automaticamente ao estado <strong>Funcional / Disponível</strong> no patrimônio e o registo será gravado no Histórico de Auditoria.
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t">
            <button type="button" onClick={onClose} className="btn btn-secondary">Cancelar</button>
            <button type="submit" disabled={isProcessing} className="btn btn-primary">
              {isProcessing ? 'Finalizando...' : 'Concluir Manutenção'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ==========================================================
// MODAL 7: AGENDAR MANUTENÇÃO PREVENTIVA
// ==========================================================
function ModalAgendarPreventiva({ bens, tecnicos, onClose, onSubmit, isProcessing }) {
  const [selectedBemId, setSelectedBemId] = React.useState('');
  const [dataAgendada, setDataAgendada] = React.useState(new Date().toISOString().split('T')[0]);
  const [descricaoRotina, setDescricaoRotina] = React.useState('Limpeza preventiva, inspeção de componentes e testes de calibração.');
  const [selectedTecId, setSelectedTecId] = React.useState(tecnicos[0]?.objectId || '');

  const selectedBem = bens.find(b => b.objectId === selectedBemId);

  const handleSubmit = (e) => {
    e.preventDefault();
    const tec = tecnicos.find(t => t.objectId === selectedTecId);
    onSubmit({
      bemId: selectedBem ? selectedBem.objectId : '',
      bemCodigo: selectedBem ? selectedBem.objectData.codigo : 'ROTINA-GERAL',
      bemNome: selectedBem ? selectedBem.objectData.nome : 'Manutenção Preventiva de Rotina',
      departamento: selectedBem ? selectedBem.objectData.departamento : 'Geral',
      localizacao: selectedBem ? selectedBem.objectData.localizacao : 'Campus UCM-FADIR',
      dataAgendada,
      descricaoRotina,
      tecnicoId: tec ? tec.objectId : '',
      tecnicoNome: tec ? tec.objectData.name : 'Técnico Responsável',
      tecnicoEmail: tec ? tec.objectData.username : ''
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex justify-between items-center border-b pb-3 mb-4">
          <h2 className="text-lg font-bold text-gray-800">
            Agendamento de Manutenção Preventiva
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl font-bold">&times;</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Equipamento Alvo *</label>
            <select
              value={selectedBemId}
              onChange={(e) => setSelectedBemId(e.target.value)}
              className="input-field text-sm"
              required
            >
              <option value="">Selecione um bem patrimonial...</option>
              {bens.map(b => (
                <option key={b.objectId} value={b.objectId}>
                  [{b.objectData.codigo}] {b.objectData.nome} ({b.objectData.departamento})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Data Agendada *</label>
              <input
                type="date"
                className="input-field text-sm"
                value={dataAgendada}
                onChange={(e) => setDataAgendada(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Técnico Designado *</label>
              <select
                value={selectedTecId}
                onChange={(e) => setSelectedTecId(e.target.value)}
                className="input-field text-sm"
                required
              >
                <option value="">Selecione o técnico...</option>
                {tecnicos.map(t => (
                  <option key={t.objectId} value={t.objectId}>
                    {t.objectData.name} ({t.objectData.department || 'Manutenção'})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Rotina de Inspeção / Tarefas Planeadas *</label>
            <textarea
              rows="3"
              className="input-field text-sm"
              value={descricaoRotina}
              onChange={(e) => setDescricaoRotina(e.target.value)}
              required
            ></textarea>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t">
            <button type="button" onClick={onClose} className="btn btn-secondary">Cancelar</button>
            <button type="submit" disabled={isProcessing} className="btn btn-primary">
              {isProcessing ? 'Agendando...' : 'Agendar Manutenção'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ==========================================================
// MODAL 8: VISUALIZAR DETALHES & TIMELINE DO FLUXO
// ==========================================================
function ModalDetalhesManutencao({ order, onClose, onPrint }) {
  const d = order.objectData || {};
  const fluxo = d.historicoFluxo || [];

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-3 sm:p-4 z-50 overflow-y-auto"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] flex flex-col p-4 sm:p-6 my-auto">
        <div className="flex justify-between items-center border-b pb-3 mb-4 shrink-0">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-gray-800 flex items-center gap-2">
              <span>📋</span> Ordem de Manutenção {d.numeroOrdem}
            </h2>
            <p className="text-xs text-gray-500">Fluxo completo de auditoria e ciclo de vida da reparação</p>
          </div>
          <button 
            type="button"
            onClick={onClose} 
            className="text-gray-400 hover:text-gray-600 text-2xl font-bold p-1 leading-none"
            title="Fechar Modal"
          >&times;</button>
        </div>

        <div className="overflow-y-auto pr-1 space-y-4 flex-1">
          {/* Resumo do Bem */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-gray-50 p-3 sm:p-4 rounded-xl text-xs">
            <div>
              <p className="text-gray-500">Equipamento:</p>
              <p className="font-bold text-gray-800 text-sm">{d.bemNome}</p>
              <p className="font-mono text-gray-600">Código: {d.bemCodigo}</p>
              <p className="text-gray-600">Local: {d.localizacao || d.departamento || 'Instalações UCM-FADIR'}</p>
            </div>
            <div>
              <p className="text-gray-500">Solicitante:</p>
              <p className="font-semibold text-gray-800">{d.solicitanteNome} ({d.solicitanteDepartamento})</p>
              <p className="text-gray-500 mt-1">Técnico:</p>
              <p className="font-semibold text-gray-800">{d.tecnicoNome || 'Ainda não atribuído'}</p>
            </div>
          </div>

          {/* Timeline */}
          <h3 className="font-bold text-sm text-gray-800 mb-2 flex items-center gap-2">
            <span>⏱️</span> Linha do Tempo do Processo
          </h3>

          <div className="relative border-l-2 border-blue-500 ml-3 sm:ml-4 space-y-4 mb-4">
            {fluxo.map((step, idx) => (
              <div key={idx} className="relative pl-5 sm:pl-6">
                <div className="absolute -left-2 top-1 w-4 h-4 bg-blue-600 rounded-full border-2 border-white shadow"></div>
                <div className="bg-gray-50 p-3 rounded-lg border text-xs">
                  <div className="flex flex-wrap justify-between items-center font-bold text-gray-800 mb-1 gap-1">
                    <span>{step.etapa}</span>
                    <span className="text-gray-500 font-normal text-[11px]">{new Date(step.data).toLocaleString('pt-BR')}</span>
                  </div>
                  <p className="text-gray-600"><strong>Responsável:</strong> {step.responsavel} ({step.cargo})</p>
                  <p className="text-gray-700 mt-1">{step.detalhe}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-between items-center pt-3 border-t mt-4 shrink-0">
          <button onClick={onPrint} className="btn btn-secondary text-xs sm:text-sm flex items-center gap-2">
            <span>🖨️</span> Imprimir Ficha
          </button>
          <button onClick={onClose} className="btn btn-primary text-xs sm:text-sm">Fechar</button>
        </div>
      </div>
    </div>
  );
}

// ==========================================================
// MODAL 9: FICHA TÉCNICA DE IMPRESSÃO
// ==========================================================
function ModalImprimirFicha({ order, onClose }) {
  const d = order.objectData || {};

  const handlePrint = () => {
    window.print();
  };

  const displayLocal = d.localizacao || d.departamento || 'Instalações UCM-FADIR';

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-2 sm:p-4 z-50 overflow-y-auto"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-white rounded-xl shadow-xl max-w-3xl w-full p-4 sm:p-6 my-auto max-h-[95vh] flex flex-col">
        <div className="flex justify-between items-center border-b pb-3 mb-4 no-print shrink-0">
          <h2 className="text-base sm:text-lg font-bold text-gray-800">Visualização de Impressão</h2>
          <div className="flex items-center gap-2">
            <button onClick={handlePrint} className="btn btn-primary text-xs sm:text-sm flex items-center gap-1.5">
              <span>🖨️</span> Imprimir Documento
            </button>
            <button onClick={onClose} className="btn btn-secondary text-xs sm:text-sm">Fechar</button>
            <button 
              type="button" 
              onClick={onClose} 
              className="text-gray-400 hover:text-gray-600 text-2xl font-bold ml-1 p-1 leading-none"
              title="Fechar Modal"
            >&times;</button>
          </div>
        </div>

        {/* Folha Oficial de Impressão (Scrollable preview on screen, clear on print) */}
        <div className="overflow-y-auto pr-1 flex-1">
          <div className="printable-area bg-white p-4 sm:p-8 border-2 border-gray-800 rounded font-serif text-xs sm:text-sm">
            {/* Header Oficial */}
            <div className="flex flex-row items-center justify-between border-b-2 border-gray-800 pb-4 mb-4 sm:mb-6 gap-2">
              <img
                src="assets/logo.png"
                alt="UCM Logo"
                className="h-12 sm:h-16 w-auto object-contain"
              />
              <div className="text-right">
                <h1 className="text-xs sm:text-base font-bold">UNIVERSIDADE CATÓLICA DE MOÇAMBIQUE</h1>
                <h2 className="text-[11px] sm:text-sm font-semibold">Faculdade de Direito - FADIR</h2>
                <p className="text-[10px] sm:text-xs text-gray-600">Departamento de Patrimônio & Manutenção</p>
              </div>
            </div>

            <div className="text-center mb-4 sm:mb-6">
              <h2 className="text-sm sm:text-lg font-bold uppercase tracking-wider underline">
                ORDEM DE TRABALHO DE MANUTENÇÃO ({d.tipo ? d.tipo.toUpperCase() : 'CORRECTIVA'})
              </h2>
              <p className="text-[11px] sm:text-xs font-mono mt-1">N.º {d.numeroOrdem} | Data: {d.dataAbertura ? new Date(d.dataAbertura).toLocaleDateString('pt-BR') : ''}</p>
            </div>

            {/* Secção 1: Identificação do Bem */}
            <div className="border border-gray-400 p-2.5 sm:p-3 rounded mb-3 sm:mb-4">
              <h3 className="font-bold border-b border-gray-300 pb-1 mb-2 text-[11px] sm:text-xs uppercase bg-gray-100 p-1">
                1. Identificação do Equipamento / Bem
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <p><strong>Equipamento:</strong> {d.bemNome}</p>
                <p><strong>Código Patrimonial:</strong> {d.bemCodigo}</p>
                <p><strong>Departamento:</strong> {d.departamento || 'N/A'}</p>
                <p><strong>Local:</strong> {displayLocal}</p>
                <p><strong>Urgência:</strong> {(d.urgencia || 'Normal').toUpperCase()}</p>
              </div>
            </div>

            {/* Secção 2: Avaria Reportada */}
            <div className="border border-gray-400 p-2.5 sm:p-3 rounded mb-3 sm:mb-4">
              <h3 className="font-bold border-b border-gray-300 pb-1 mb-2 text-[11px] sm:text-xs uppercase bg-gray-100 p-1">
                2. Relato Inicial da Avaria
              </h3>
              <p className="text-xs"><strong>Solicitante:</strong> {d.solicitanteNome} ({d.solicitanteDepartamento})</p>
              <p className="text-xs mt-1"><strong>Descrição / Avaria:</strong> {d.descricaoAvaria || d.descricaoRotina}</p>
            </div>

            {/* Secção 3: Diagnóstico e Orçamento */}
            <div className="border border-gray-400 p-2.5 sm:p-3 rounded mb-3 sm:mb-4">
              <h3 className="font-bold border-b border-gray-300 pb-1 mb-2 text-[11px] sm:text-xs uppercase bg-gray-100 p-1">
                3. Diagnóstico Técnico & Orçamento
              </h3>
              <div className="text-xs space-y-1">
                <p><strong>Técnico Responsável:</strong> {d.tecnicoNome || 'Não atribuído'}</p>
                <p><strong>Diagnóstico:</strong> {d.diagnosticoTecnico || 'N/A'}</p>
                <p><strong>Peças / Materiais:</strong> {d.pecasEstimadas || 'N/A'}</p>
                <p><strong>Custo Estimado:</strong> {d.custoEstimado ? Number(d.custoEstimado).toLocaleString('pt-MZ', { minimumFractionDigits: 2 }) + ' MZN' : 'N/A'}</p>
                <p><strong>Parecer do Património:</strong> {d.parecerPatrimonio || 'N/A'}</p>
              </div>
            </div>

            {/* Secção 4: Decisão da Administração */}
            <div className="border border-gray-400 p-2.5 sm:p-3 rounded mb-3 sm:mb-4">
              <h3 className="font-bold border-b border-gray-300 pb-1 mb-2 text-[11px] sm:text-xs uppercase bg-gray-100 p-1">
                4. Despacho da Administração
              </h3>
              <div className="text-xs space-y-1">
                <p><strong>Autorizador:</strong> {d.aprovadorNome || 'Pendente'}</p>
                <p><strong>Decisão:</strong> {(d.decisaoAdmin || d.status).toUpperCase()}</p>
                <p><strong>Despacho:</strong> {d.observacaoAdmin || 'N/A'}</p>
              </div>
            </div>

            {/* Secção 5: Conclusão */}
            <div className="border border-gray-400 p-2.5 sm:p-3 rounded mb-4 sm:mb-6">
              <h3 className="font-bold border-b border-gray-300 pb-1 mb-2 text-[11px] sm:text-xs uppercase bg-gray-100 p-1">
                5. Relatório Técnico de Execução
              </h3>
              <div className="text-xs space-y-1">
                <p><strong>Intervenção Realizada:</strong> {d.tipoIntervencao || 'N/A'}</p>
                <p><strong>Custo Real Final:</strong> {d.custoFinal ? Number(d.custoFinal).toLocaleString('pt-MZ', { minimumFractionDigits: 2 }) + ' MZN' : 'N/A'}</p>
                <p><strong>Tempo Gasto:</strong> {d.tempoGastoHoras ? `${d.tempoGastoHoras} horas` : 'N/A'}</p>
                <p><strong>Relatório Técnico:</strong> {d.relatorioFinal || 'Pendente de execução'}</p>
              </div>
            </div>

            {/* Assinaturas */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 text-center text-xs mt-8 sm:mt-12 pt-4">
              <div>
                <div className="border-t border-gray-800 pt-1 font-semibold">{d.solicitanteNome || 'Solicitante'}</div>
                <p className="text-gray-500">Docente / Utilizador</p>
              </div>
              <div>
                <div className="border-t border-gray-800 pt-1 font-semibold">{d.tecnicoNome || 'Técnico de Manutenção'}</div>
                <p className="text-gray-500">Equipa Técnica</p>
              </div>
              <div>
                <div className="border-t border-gray-800 pt-1 font-semibold">{d.aprovadorNome || 'Administradora / Diretor'}</div>
                <p className="text-gray-500">Administração Geral</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ManutencaoApp />);
