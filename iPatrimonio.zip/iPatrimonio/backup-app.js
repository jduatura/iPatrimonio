function BackupApp() {
  const [user, setUser] = React.useState(null);
  const [backups, setBackups] = React.useState([]);
  const [autoBackupStatus, setAutoBackupStatus] = React.useState(null);
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [configId, setConfigId] = React.useState(null);
  const [confirmModal, setConfirmModal] = React.useState({ isOpen: false, type: null, data: null });

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser || currentUser.role !== 'admin') {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadBackups();
    loadAutoBackupStatus();
  }, []);

  const loadBackups = async () => {
    try {
      const result = await dbListObjects('backup', 100);
      setBackups(result.items);
    } catch (error) {
      console.error('Error loading backups:', error);
      setBackups([]);
    }
  };

  const loadAutoBackupStatus = async () => {
    try {
      const result = await dbListObjects('backup_config', 1);
      if (result.items.length > 0) {
        setConfigId(result.items[0].objectId);
        setAutoBackupStatus(result.items[0].objectData);
      } else {
        const defaultConfig = {
          enabled: false,
          frequency: 'daily',
          lastBackup: null
        };
        const created = await dbCreateObject('backup_config', defaultConfig);
        setConfigId(created.objectId);
        setAutoBackupStatus(defaultConfig);
      }
    } catch (error) {
      console.error('Error loading backup config:', error);
    }
  };

  const handleCreateBackup = async () => {
    setIsProcessing(true);
    try {
      const bensList = await dbListObjects('bem', 1000);
      const usuariosList = await dbListObjects('usuario', 1000);
      const requisicoesList = await dbListObjects('requisicao', 1000);
      const movimentacoesList = await dbListObjects('movimentacao', 1000);
      const departamentosList = await dbListObjects('departamento', 1000);
      const abatesList = await dbListObjects('abate', 1000);
      const termosList = await dbListObjects('termo_entrega', 1000);
      const mapasList = await dbListObjects('mapa_controle_saida', 1000);
      const manutencoesList = await dbListObjects('manutencao', 1000);
      const historicoManutencaoList = await dbListObjects('historico_manutencao', 1000);
      
      const backupData = {
        bens: bensList.items || [],
        usuarios: usuariosList.items || [],
        requisicoes: requisicoesList.items || [],
        movimentacoes: movimentacoesList.items || [],
        departamentos: departamentosList.items || [],
        abates: abatesList.items || [],
        termos: termosList.items || [],
        mapas: mapasList.items || [],
        manutencoes: manutencoesList.items || [],
        historicoManutencao: historicoManutencaoList.items || [],
        timestamp: new Date().toISOString(),
        createdBy: user.name || user.email
      };

      await dbCreateObject('backup', backupData);
      await logAuditAction(AUDIT_ACTIONS.CRIAR_BACKUP, 'Backup manual criado', user);
      
      setAlertMessage('Backup criado com sucesso!');
      setAlertType('success');
      setShowAlert(true);
      loadBackups();
    } catch (error) {
      console.error('Erro ao criar backup:', error);
      setAlertMessage('Erro ao criar backup: ' + error.message);
      setAlertType('error');
      setShowAlert(true);
    }
    setIsProcessing(false);
  };

  const handleDownloadBackup = async (backupId) => {
    try {
      const backup = await dbGetObject('backup', backupId);
      const dataStr = JSON.stringify(backup.objectData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `backup_ipatrimonio_${new Date(backup.objectData.timestamp).toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Erro ao baixar backup:', error);
      setAlertMessage('Erro ao baixar backup: ' + error.message);
      setAlertType('error');
      setShowAlert(true);
    }
  };

  const handleUploadBackup = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.name.endsWith('.json')) {
      setAlertMessage('Por favor, selecione um arquivo JSON válido.');
      setAlertType('error');
      setShowAlert(true);
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const content = e.target.result;
        if (!content || content.trim() === '') {
          throw new Error('Arquivo vazio');
        }
        
        const backupData = JSON.parse(content);
        
        if (!backupData.bens && !backupData.requisicoes && !backupData.movimentacoes) {
          throw new Error('Arquivo de backup inválido - dados não encontrados');
        }
        
        setConfirmModal({
          isOpen: true,
          type: 'upload',
          data: backupData
        });
        event.target.value = '';
      } catch (error) {
        console.error('Erro ao ler arquivo:', error);
        let errorMsg = 'Erro ao ler arquivo de backup: ';
        if (error instanceof SyntaxError) {
          errorMsg += 'Arquivo JSON inválido ou corrompido';
        } else {
          errorMsg += error.message;
        }
        setAlertMessage(errorMsg);
        setAlertType('error');
        setShowAlert(true);
        event.target.value = '';
      }
    };
    reader.onerror = () => {
      setAlertMessage('Erro ao ler o arquivo. Por favor, tente novamente.');
      setAlertType('error');
      setShowAlert(true);
      event.target.value = '';
    };
    reader.readAsText(file);
  };

  const restoreBackupData = async (data) => {
    setIsProcessing(true);
    try {
      setAlertMessage('Restauração em andamento, aguarde...');
      setAlertType('info');
      setShowAlert(true);

      await new Promise(resolve => setTimeout(resolve, 500));

      const deletePromises = [];
      try {
        const bensList = await dbListObjects('bem', 1000);
        if (bensList.items?.length > 0) {
          deletePromises.push(Promise.all(bensList.items.map(i => dbDeleteObject('bem', i.objectId).catch(() => {}))));
        }
      } catch (e) {}
      
      try {
        const reqList = await dbListObjects('requisicao', 1000);
        if (reqList.items?.length > 0) {
          deletePromises.push(Promise.all(reqList.items.map(i => dbDeleteObject('requisicao', i.objectId).catch(() => {}))));
        }
      } catch (e) {}
      
      try {
        const movList = await dbListObjects('movimentacao', 1000);
        if (movList.items?.length > 0) {
          deletePromises.push(Promise.all(movList.items.map(i => dbDeleteObject('movimentacao', i.objectId).catch(() => {}))));
        }
      } catch (e) {}

      if (deletePromises.length > 0) {
        await Promise.all(deletePromises);
      }

      await new Promise(resolve => setTimeout(resolve, 500));

      const restorePromises = [];
      if (data.bens?.length > 0) {
        for (const b of data.bens) {
          restorePromises.push(dbCreateObject('bem', b.objectData).catch((err) => {
            console.error('Erro ao criar bem:', err);
          }));
        }
      }
      if (data.requisicoes?.length > 0) {
        for (const r of data.requisicoes) {
          restorePromises.push(dbCreateObject('requisicao', r.objectData).catch((err) => {
            console.error('Erro ao criar requisição:', err);
          }));
        }
      }
      if (data.movimentacoes?.length > 0) {
        for (const m of data.movimentacoes) {
          restorePromises.push(dbCreateObject('movimentacao', m.objectData).catch((err) => {
            console.error('Erro ao criar movimentação:', err);
          }));
        }
      }
      if (data.abates?.length > 0) {
        for (const a of data.abates) {
          restorePromises.push(dbCreateObject('abate', a.objectData).catch((err) => {
            console.error('Erro ao criar abate:', err);
          }));
        }
      }
      if (data.termos?.length > 0) {
        for (const t of data.termos) {
          restorePromises.push(dbCreateObject('termo_entrega', t.objectData).catch((err) => {
            console.error('Erro ao criar termo:', err);
          }));
        }
      }
      if (data.mapas?.length > 0) {
        for (const m of data.mapas) {
          restorePromises.push(dbCreateObject('mapa_controle_saida', m.objectData).catch((err) => {
            console.error('Erro ao criar mapa:', err);
          }));
        }
      }
      if (data.manutencoes?.length > 0) {
        for (const m of data.manutencoes) {
          restorePromises.push(dbCreateObject('manutencao', m.objectData).catch((err) => {
            console.error('Erro ao criar manutenção:', err);
          }));
        }
      }
      if (data.historicoManutencao?.length > 0) {
        for (const h of data.historicoManutencao) {
          restorePromises.push(dbCreateObject('historico_manutencao', h.objectData).catch((err) => {
            console.error('Erro ao criar histórico de manutenção:', err);
          }));
        }
      }
      
      await Promise.all(restorePromises);
      
      try {
        await logAuditAction(AUDIT_ACTIONS.RESTAURAR_BACKUP, 'Backup restaurado de arquivo', user);
      } catch (e) {}
      
      setAlertMessage('Backup restaurado com sucesso! Recarregando...');
      setAlertType('success');
      setShowAlert(true);
      
      setTimeout(() => window.location.reload(), 1500);
    } catch (error) {
      console.error('Erro ao restaurar backup:', error);
      let errorMsg = 'Erro ao restaurar backup: ';
      try {
        const errStr = String(error.message || error);
        if (errStr.includes('Rate limit') || errStr.includes('rate limit') || errStr.includes('too many requests')) {
          errorMsg = 'Limite de requisições atingido. Por favor, aguarde alguns minutos e tente novamente.';
        } else if (errStr.includes('not valid JSON') || errStr.includes('SyntaxError')) {
          errorMsg = 'Erro de comunicação com o servidor. Por favor, aguarde alguns momentos e tente novamente.';
        } else {
          errorMsg += errStr;
        }
      } catch (parseError) {
        errorMsg = 'Erro inesperado. Por favor, tente novamente em alguns momentos.';
      }
      setAlertMessage(errorMsg);
      setAlertType('error');
      setShowAlert(true);
      setIsProcessing(false);
    }
  };

  const handleRestoreBackup = (backupId) => {
    setConfirmModal({
      isOpen: true,
      type: 'restore',
      data: backupId
    });
  };

  const confirmRestore = async () => {
    const backupId = confirmModal.data;
    setConfirmModal({ isOpen: false, type: null, data: null });
    setIsProcessing(true);
    try {
      const backup = await dbGetObject('backup', backupId);
      const data = backup.objectData;

      setAlertMessage('Restauração em andamento...');
      setAlertType('info');
      setShowAlert(true);

      // Parallel deletion of current data
      const deletePromises = [
        dbListObjects('bem', 1000).then(r => Promise.all(r.items.map(i => dbDeleteObject('bem', i.objectId)))),
        dbListObjects('requisicao', 1000).then(r => Promise.all(r.items.map(i => dbDeleteObject('requisicao', i.objectId)))),
        dbListObjects('movimentacao', 1000).then(r => Promise.all(r.items.map(i => dbDeleteObject('movimentacao', i.objectId))))
      ];
      await Promise.all(deletePromises);

      // Parallel restoration of backed up data
      const restorePromises = [];
      if (data.bens) restorePromises.push(Promise.all(data.bens.map(b => dbCreateObject('bem', b.objectData))));
      if (data.requisicoes) restorePromises.push(Promise.all(data.requisicoes.map(r => dbCreateObject('requisicao', r.objectData))));
      if (data.movimentacoes) restorePromises.push(Promise.all(data.movimentacoes.map(m => dbCreateObject('movimentacao', m.objectData))));
      if (data.abates) restorePromises.push(Promise.all(data.abates.map(a => dbCreateObject('abate', a.objectData))));
      if (data.termos) restorePromises.push(Promise.all(data.termos.map(t => dbCreateObject('termo_entrega', t.objectData))));
      if (data.mapas) restorePromises.push(Promise.all(data.mapas.map(m => dbCreateObject('mapa_controle_saida', m.objectData))));
      
      await Promise.all(restorePromises);
      await logAuditAction(AUDIT_ACTIONS.RESTAURAR_BACKUP, `Backup restaurado de ${new Date(data.timestamp).toLocaleString('pt-BR')}`, user);
      
      setAlertMessage('Backup restaurado! Recarregando...');
      setAlertType('success');
      setShowAlert(true);
      
      setTimeout(() => window.location.reload(), 1000);
    } catch (error) {
      console.error('Erro ao restaurar backup:', error);
      setAlertMessage('Erro ao restaurar backup: ' + error.message);
      setAlertType('error');
      setShowAlert(true);
    }
    setIsProcessing(false);
  };

  const handleConfirmAction = async () => {
    if (confirmModal.type === 'restore') {
      await confirmRestore();
    } else if (confirmModal.type === 'upload') {
      const fileInput = document.querySelector('input[type="file"]');
      setConfirmModal({ isOpen: false, type: null, data: null });
      await restoreBackupData(confirmModal.data);
      if (fileInput) fileInput.value = '';
    }
  };

  const handleCancelAction = () => {
    if (confirmModal.type === 'upload') {
      const fileInput = document.querySelector('input[type="file"]');
      if (fileInput) fileInput.value = '';
    }
    setConfirmModal({ isOpen: false, type: null, data: null });
  };

  const handleToggleAutoBackup = async () => {
    if (!configId || !autoBackupStatus) return;
    
    try {
      const newStatus = !autoBackupStatus.enabled;
      const updatedConfig = {
        ...autoBackupStatus,
        enabled: newStatus,
        lastUpdate: new Date().toISOString()
      };
      
      await dbUpdateObject('backup_config', configId, updatedConfig);

      await logAuditAction(
        newStatus ? AUDIT_ACTIONS.ATIVAR_BACKUP_AUTO : AUDIT_ACTIONS.DESATIVAR_BACKUP_AUTO,
        `Backup automático ${newStatus ? 'ativado' : 'desativado'} (${autoBackupStatus.frequency})`,
        user
      );

      setAutoBackupStatus(updatedConfig);
      setAlertMessage(`Backup automático ${newStatus ? 'ativado' : 'desativado'} com sucesso!`);
      setAlertType('success');
      setShowAlert(true);
    } catch (error) {
      console.error('Erro ao alterar configuração:', error);
      setAlertMessage('Erro ao alterar configuração: ' + error.message);
      setAlertType('error');
      setShowAlert(true);
    }
  };

  const handleChangeFrequency = async (frequency) => {
    if (!configId || !autoBackupStatus) return;
    
    try {
      const updatedConfig = {
        ...autoBackupStatus,
        frequency,
        lastUpdate: new Date().toISOString()
      };
      
      await dbUpdateObject('backup_config', configId, updatedConfig);
      await logAuditAction(AUDIT_ACTIONS.CONFIGURAR_SISTEMA, `Frequência de backup alterada para ${frequency}`, user);

      setAutoBackupStatus(updatedConfig);
      setAlertMessage('Frequência de backup atualizada!');
      setAlertType('success');
      setShowAlert(true);
    } catch (error) {
      console.error('Erro ao alterar frequência:', error);
      setAlertMessage('Erro ao alterar frequência: ' + error.message);
      setAlertType('error');
      setShowAlert(true);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={handleCancelAction}
        onConfirm={handleConfirmAction}
        title="Confirmar Restauração"
        message="Tem certeza que deseja restaurar este backup? Esta ação irá substituir todos os dados atuais do sistema."
        confirmText="Sim, Restaurar"
        cancelText="Cancelar"
        isProcessing={isProcessing}
      />
      <main className="flex-grow p-4 md:p-6">
        <button onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4">
          <div className="icon-arrow-left text-base md:text-lg"></div>
          <span>Voltar</span>
        </button>

        <h1 className="text-2xl md:text-3xl font-bold mb-4 md:mb-6">Gerenciamento de Backup</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 mb-4 md:mb-6">
          <div className="card">
            <h3 className="font-bold text-base md:text-lg mb-3 md:mb-4 flex items-center">
              <div className="icon-settings text-lg md:text-xl text-blue-600 mr-2"></div>
              Configurações de Backup Automático
            </h3>
            <div className="space-y-3 md:space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-3 md:p-4 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <p className="font-medium text-sm md:text-base">Backup Automático</p>
                  <p className="text-xs md:text-sm text-gray-600">
                    {autoBackupStatus?.enabled 
                      ? `Ativo - ${autoBackupStatus.frequency === 'daily' ? 'Diário' : autoBackupStatus.frequency === 'weekly' ? 'Semanal' : 'Mensal'}`
                      : 'Desativado'}
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoBackupStatus?.enabled || false}
                    onChange={handleToggleAutoBackup}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                </label>
              </div>
              
              {autoBackupStatus?.enabled && (
                <div className="p-3 md:p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <label className="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                    Frequência
                  </label>
                  <select
                    value={autoBackupStatus.frequency || 'daily'}
                    onChange={(e) => handleChangeFrequency(e.target.value)}
                    className="input-field text-sm"
                  >
                    <option value="daily">Diário (todos os dias às 00:00)</option>
                    <option value="weekly">Semanal (todas as segundas-feiras)</option>
                    <option value="monthly">Mensal (primeiro dia do mês)</option>
                  </select>
                </div>
              )}
              
              {autoBackupStatus?.lastBackup && (
                <div className="p-3 md:p-4 bg-gray-50 rounded-lg">
                  <p className="text-xs md:text-sm text-gray-600">Último backup automático:</p>
                  <p className="font-medium text-sm md:text-base">{new Date(autoBackupStatus.lastBackup).toLocaleString('pt-BR')}</p>
                </div>
              )}
            </div>
          </div>

          <div className="card">
            <h3 className="font-bold text-base md:text-lg mb-3 md:mb-4 flex items-center">
              <div className="icon-upload text-lg md:text-xl text-green-600 mr-2"></div>
              Backup Manual
            </h3>
            <p className="text-sm md:text-base text-gray-600 mb-3 md:mb-4">Crie um backup manual dos dados do sistema</p>
            <button
              onClick={handleCreateBackup}
              disabled={isProcessing}
              className="btn btn-primary w-full flex items-center justify-center gap-2 mb-3"
            >
              <div className="icon-save text-base md:text-lg"></div>
              <span className="text-sm md:text-base">{isProcessing ? 'Processando...' : 'Criar Backup Agora'}</span>
            </button>
            <div className="border-t pt-3">
              <p className="text-xs md:text-sm text-gray-600 mb-2">Restaurar backup de arquivo:</p>
              <label className="flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all">
                <div className="icon-upload text-lg text-gray-500"></div>
                <span className="text-xs md:text-sm text-gray-600">Escolher arquivo .json</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleUploadBackup}
                  disabled={isProcessing}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>

        <div className="card">
          <h3 className="font-bold text-base md:text-lg mb-3 md:mb-4 flex items-center">
            <div className="icon-database text-lg md:text-xl text-purple-600 mr-2"></div>
            Backups Disponíveis ({backups.length})
          </h3>
          <div className="space-y-2 md:space-y-3">
            {backups.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <div className="icon-inbox text-3xl md:text-4xl mb-2 mx-auto w-fit"></div>
                <p className="text-sm md:text-base">Nenhum backup disponível</p>
              </div>
            ) : (
              backups.map(backup => (
                <BackupCard
                  key={backup.objectId}
                  backup={backup}
                  onRestore={handleRestoreBackup}
                  onDownload={handleDownloadBackup}
                  isProcessing={isProcessing}
                />
              ))
            )}
          </div>
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

function BackupCard({ backup, onRestore, onDownload, isProcessing }) {
  const data = backup.objectData;
  const date = new Date(data.timestamp);

  return (
    <div className="border rounded-lg p-2 sm:p-3 md:p-4 hover:shadow-sm transition">
      <div className="flex flex-col gap-2 sm:gap-3">
        <div className="flex-1">
          <div className="flex items-center gap-1 sm:gap-2 mb-1 sm:mb-2">
            <div className="icon-calendar text-sm sm:text-base md:text-lg text-blue-600"></div>
            <p className="font-medium text-xs sm:text-sm md:text-base">{date.toLocaleDateString('pt-BR')} {date.toLocaleTimeString('pt-BR', {hour: '2-digit', minute: '2-digit'})}</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-1 sm:gap-2 text-xs text-gray-600">
            <p>Bens: {data.bens?.length || 0}</p>
            <p>Usuários: {data.usuarios?.length || 0}</p>
            <p>Requisições: {data.requisicoes?.length || 0}</p>
            <p>Movimentações: {data.movimentacoes?.length || 0}</p>
            <p>Departamentos: {data.departamentos?.length || 0}</p>
            <p>Abates: {data.abates?.length || 0}</p>
            <p>Termos: {data.termos?.length || 0}</p>
            <p>Mapas: {data.mapas?.length || 0}</p>
          </div>
          <p className="text-xs text-gray-500 mt-1 sm:mt-2">Por: {data.createdBy}</p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => onDownload(backup.objectId)}
            disabled={isProcessing}
            className="btn bg-green-600 text-white hover:bg-green-700 disabled:opacity-50 flex items-center justify-center gap-1 sm:gap-2"
          >
            <div className="icon-download text-sm sm:text-base"></div>
            <span className="text-xs sm:text-sm">Baixar</span>
          </button>
          <button
            onClick={() => onRestore(backup.objectId)}
            disabled={isProcessing}
            className="btn bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-1 sm:gap-2"
          >
            <div className="icon-refresh-cw text-sm sm:text-base"></div>
            <span className="text-xs sm:text-sm">Restaurar</span>
          </button>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<BackupApp />);

