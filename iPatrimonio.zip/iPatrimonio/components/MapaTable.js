function MapaTable({ registros, filters, setFilters }) {
  return (
      <div className="card">
        <div className="no-print mb-3 md:mb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3 md:gap-4">
        <div>
          <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">Data Início</label>
          <input type="date" className="input-field text-sm md:text-base" value={filters.dataInicio}
            onChange={(e) => setFilters({...filters, dataInicio: e.target.value})} />
        </div>
        <div>
          <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">Data Fim</label>
          <input type="date" className="input-field text-sm md:text-base" value={filters.dataFim}
            onChange={(e) => setFilters({...filters, dataFim: e.target.value})} />
        </div>
        <div>
          <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">Departamento</label>
          <select className="input-field text-sm md:text-base" value={filters.departamento}
            onChange={(e) => setFilters({...filters, departamento: e.target.value})}>
            <option value="">Todos</option>
            <option value="Limpeza">Limpeza</option>
            <option value="Biblioteca">Biblioteca</option>
            <option value="Secretaria">Secretaria</option>
            <option value="Administração">Administração</option>
          </select>
        </div>
      </div>

      <div className="text-center mb-2 md:mb-4">
        <h2 className="text-xs sm:text-sm md:text-lg font-bold">MAPA DE CONTROLE DE SAIDA DE MATERIAL</h2>
      </div>

        <div className="overflow-x-auto -mx-2 sm:-mx-3 md:-mx-6 px-2 sm:px-3 md:px-6 lg:mx-0 lg:px-0">
          <table className="w-full border-collapse border-2 border-black" style={{ minWidth: '700px' }}>
            <thead>
              <tr>
                <th className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm font-bold whitespace-nowrap">Nº GUIA</th>
                <th className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm font-bold whitespace-nowrap">DATA</th>
                <th className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm font-bold whitespace-nowrap">DESCRIÇÃO</th>
                <th className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm font-bold whitespace-nowrap">QUANT</th>
                <th className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm font-bold whitespace-nowrap">SAÍDA</th>
                <th className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm font-bold whitespace-nowrap">ENTRADA</th>
                <th className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm font-bold whitespace-nowrap">SALDO</th>
                <th className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm font-bold whitespace-nowrap">REQUISITANTE</th>
                <th className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm font-bold whitespace-nowrap">OBSERVAÇÕES</th>
              </tr>
            </thead>
          <tbody>
            {registros.map(reg => {
              const data = reg.objectData;
              return (
                <tr key={reg.objectId}>
                  <td className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm whitespace-nowrap">{data.numeroDocumento || '-'}</td>
                  <td className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm whitespace-nowrap">
                    {new Date(data.dataSaida).toLocaleDateString('pt-BR')}
                  </td>
                  <td className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm">{data.descricaoMaterial || '-'}</td>
                  <td className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm text-center">{data.quantidade}</td>
                  <td className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm text-center">{data.quantidade || '-'}</td>
                  <td className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm text-center">-</td>
                  <td className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm text-center">{data.quantidade || '-'}</td>
                  <td className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm">{data.responsavelRequisicao || data.requisitante || '-'}</td>
                  <td className="border-2 border-black px-1 sm:px-2 py-1 sm:py-2 text-[10px] sm:text-xs md:text-sm">{data.observacoes || ''}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}