function BemDetailCard({ bem, onClose }) {
  const calcularTempo = (dataAtribuicao) => {
    if (!dataAtribuicao) return '';
    const agora = new Date();
    const atribuicao = new Date(dataAtribuicao);
    const dias = Math.floor((agora - atribuicao) / (1000 * 60 * 60 * 24));
    if (dias === 0) return 'hoje';
    return `há ${dias} dia${dias !== 1 ? 's' : ''}`;
  };

  const statusColors = {
    disponivel: 'bg-green-100 text-green-800',
    em_uso: 'bg-yellow-100 text-yellow-800',
    manutencao: 'bg-red-100 text-red-800',
    ABATIDO: 'bg-red-100 text-red-800 font-bold'
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-start mb-4">
          <h2 className="text-2xl font-bold">{bem.nome}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <div className="icon-x text-xl"></div>
          </button>
        </div>

        {bem.foto && (
          <div className="mb-4">
            <img src={bem.foto} alt={bem.nome} className="w-full h-64 object-cover rounded-lg" />
          </div>
        )}

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-sm text-gray-500">Código</p>
            <p className="font-semibold">{bem.codigo}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Status</p>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[bem.status]}`}>
              {bem.status === 'ABATIDO' ? 'Abatido' : bem.status === 'disponivel' ? 'Disponível' : bem.status === 'em_uso' ? 'Em Uso' : 'Manutenção'}
            </span>
          </div>
          <div>
            <p className="text-sm text-gray-500">Categoria</p>
            <p className="font-semibold">{bem.categoria}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Departamento</p>
            <p className="font-semibold">{bem.departamento}</p>
          </div>
        </div>

        {bem.status === 'em_uso' && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
            <p className="text-sm font-medium text-yellow-900 mb-2">Em uso por:</p>
            <div className="flex items-center gap-2 mb-2">
              <div className="icon-user text-lg text-yellow-700"></div>
              <span className="font-bold text-yellow-900">{bem.responsavelAtual}</span>
            </div>
            {bem.usuarioAtual && (
              <p className="text-sm text-yellow-700 mb-1">{bem.usuarioAtual}</p>
            )}
            {bem.dataAtribuicao && (
              <p className="text-xs text-yellow-600">Atribuído {calcularTempo(bem.dataAtribuicao)}</p>
            )}
          </div>
        )}

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
          <p className="text-sm font-medium text-blue-900 mb-2">Localização</p>
          <div className="space-y-1 text-sm">
            {bem.edificio && <p><span className="text-blue-700">Edifício:</span> {bem.edificio}</p>}
            {bem.piso && <p><span className="text-blue-700">Piso:</span> {bem.piso}</p>}
            {bem.sala && <p><span className="text-blue-700">Sala:</span> {bem.sala}</p>}
            {bem.localizacao && <p><span className="text-blue-700">Detalhes:</span> {bem.localizacao}</p>}
          </div>
        </div>

        {bem.descricao && (
          <div className="mb-4">
            <p className="text-sm text-gray-500 mb-1">Descrição</p>
            <p className="text-sm">{bem.descricao}</p>
          </div>
        )}

        {/* QR Code visual e link direto para reportar avaria */}
        <div className="bg-gray-50 p-4 rounded-lg border flex flex-col sm:flex-row items-center justify-between gap-4 mb-4">
          <div className="text-center sm:text-left">
            <h4 className="font-bold text-sm text-gray-800 mb-1">Etiqueta Digital (QR Code)</h4>
            <p className="text-xs text-gray-500 mb-2">Escaneie para consultar rapidamente ou reportar avaria</p>
            <a 
              href={`manutencao.html?code=${bem.codigo}`} 
              className="inline-flex items-center gap-1 bg-red-600 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-red-700 transition"
            >
              <div className="icon-wrench text-sm"></div>
              <span>Reportar Avaria deste Bem</span>
            </a>
          </div>
          <div className="bg-white p-2 border rounded shadow-sm flex items-center justify-center">
            <img 
              src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(bem.codigo)}`} 
              alt={`QR Code ${bem.codigo}`}
              className="w-20 h-20"
            />
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <button onClick={onClose} className="btn btn-primary">Fechar</button>
        </div>
      </div>
    </div>
  );
}