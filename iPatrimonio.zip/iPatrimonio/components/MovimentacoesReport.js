function MovimentacoesReport({ filterPeriod }) {
  const [movimentacoes, setMovimentacoes] = React.useState([]);

  React.useEffect(() => {
    loadMovimentacoes();
  }, [filterPeriod]);

  const loadMovimentacoes = async () => {
    try {
      const result = await dbListObjects('movimentacao', 100);
      const now = new Date();
      const filtered = result.items.filter(m => {
        const movDate = new Date(m.objectData.dataMovimentacao);
        let isInPeriod = true;

        if (filterPeriod === 'dia') {
          isInPeriod = movDate.toDateString() === now.toDateString();
        } else if (filterPeriod === 'semana') {
          const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          isInPeriod = movDate >= weekAgo;
        } else if (filterPeriod === 'mes') {
          isInPeriod = movDate.getMonth() === now.getMonth() && movDate.getFullYear() === now.getFullYear();
        } else if (filterPeriod === 'semestre') {
          const semester = Math.floor(now.getMonth() / 6);
          const movSemester = Math.floor(movDate.getMonth() / 6);
          isInPeriod = movSemester === semester && movDate.getFullYear() === now.getFullYear();
        } else if (filterPeriod === 'ano') {
          isInPeriod = movDate.getFullYear() === now.getFullYear();
        }

        return isInPeriod;
      });
      setMovimentacoes(filtered);
    } catch (error) {
      console.error('Error loading movements:', error);
      setMovimentacoes([]);
    }
  };

  if (movimentacoes.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <div className="icon-inbox text-4xl mb-2 mx-auto w-fit"></div>
        <p>Nenhuma movimentação registrada no período</p>
      </div>
    );
  }

  return (
    <div className="space-y-3 max-h-96 overflow-y-auto">
      {movimentacoes.map(mov => {
        const data = mov.objectData;
        return (
          <div key={mov.objectId} className="border rounded-lg p-4 hover:shadow-sm transition">
            <div className="flex items-start justify-between mb-2">
              <div>
                <p className="text-xs text-gray-500">Ref. N°</p>
                <p className="font-medium text-sm">{data.numeroReferencia}</p>
              </div>
              <span className="text-xs text-gray-500">
                {new Date(data.dataMovimentacao).toLocaleDateString('pt-BR')}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm mb-3">
              <div className="p-2 bg-red-50 rounded">
                <p className="text-red-600 font-medium mb-1">De:</p>
                <p className="text-gray-700">{data.departamentoOrigem}</p>
                {data.localizacaoOrigem && <p className="text-xs text-gray-600">{data.localizacaoOrigem}</p>}
              </div>
              <div className="p-2 bg-green-50 rounded">
                <p className="text-green-600 font-medium mb-1">Para:</p>
                <p className="text-gray-700">{data.departamentoDestino}</p>
                {data.localizacaoDestino && <p className="text-xs text-gray-600">{data.localizacaoDestino}</p>}
              </div>
            </div>
            {data.bensMovimentados && (
              <div className="mb-2">
                <p className="text-xs font-medium text-gray-600 mb-1">Bens:</p>
                <ul className="list-disc list-inside text-xs text-gray-700">
                  {data.bensMovimentados.map((bem, idx) => (
                    <li key={idx}>{bem.quantidade} {bem.bemNome}</li>
                  ))}
                </ul>
              </div>
            )}
            <div className="mt-2 text-xs text-gray-600 border-t pt-2">
              <p>Registrado por: {data.responsavel}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}