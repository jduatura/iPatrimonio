﻿function FilterPanel({ filters, onFilterChange, onClearFilters, onOpenScanner }) {
  return (
    <div className="card mb-6">
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="relative lg:col-span-2 flex gap-2">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <div className="icon-search text-lg text-gray-400"></div>
            </div>
            <input
              type="text"
              className="input-field pl-10"
              placeholder="Buscar por nome, código ou pessoa..."
              value={filters.searchTerm}
              onChange={(e) => onFilterChange('searchTerm', e.target.value)}
            />
          </div>
          {onOpenScanner && (
            <button
              type="button"
              onClick={onOpenScanner}
              className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition flex items-center gap-1 flex-shrink-0 text-sm font-medium"
              title="Escanear QR Code com a câmera"
            >
              <div className="icon-qr-code text-lg"></div>
              <span className="hidden sm:inline">Escanear QR</span>
            </button>
          )}
        </div>

        <select 
          className="input-field" 
          value={filters.categoria}
          onChange={(e) => onFilterChange('categoria', e.target.value)}
        >
          <option value="">Todas Categorias</option>
          <option value="Material">Material</option>
          <option value="Consumível">Consumível</option>
        </select>

        <select 
          className="input-field"
          value={filters.status}
          onChange={(e) => onFilterChange('status', e.target.value)}
        >
          <option value="">Todos Status</option>
          <option value="disponivel">Disponível</option>
          <option value="em_uso">Em Uso</option>
          <option value="manutencao">Manutenção</option>
        </select>

        <input
          type="text"
          className="input-field"
          placeholder="Filtrar por departamento..."
          value={filters.departamento}
          onChange={(e) => onFilterChange('departamento', e.target.value)}
        />

        <button
          onClick={onClearFilters}
          className="btn bg-gray-200 text-gray-800 hover:bg-gray-300"
        >
          Limpar Filtros
        </button>
      </div>
    </div>
  );
}