function BensList({ bens, onViewDetails }) {
  const calcularTempo = (dataAtribuicao) => {
    if (!dataAtribuicao) return '';
    const agora = new Date();
    const atribuicao = new Date(dataAtribuicao);
    const dias = Math.floor((agora - atribuicao) / (1000 * 60 * 60 * 24));
    return `há ${dias} dia${dias !== 1 ? 's' : ''}`;
  };

  const statusColors = {
    disponivel: 'bg-green-100 text-green-800',
    em_uso: 'bg-yellow-100 text-yellow-800',
    manutencao: 'bg-red-100 text-red-800',
    ABATIDO: 'bg-red-100 text-red-800 font-bold'
  };

  if (bens.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <div className="icon-search text-5xl text-gray-300 mb-4 mx-auto w-fit"></div>
        <p>Nenhum bem encontrado</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {bens.map(bem => (
        <div key={bem.objectId} className="card hover:shadow-lg transition cursor-pointer"
          onClick={() => onViewDetails && onViewDetails(bem.objectData)}>
          <div className="flex gap-3 mb-3">
            <div className="w-16 h-16 rounded-lg flex items-center justify-center overflow-hidden border-2 bg-gray-100 flex-shrink-0"
              style={{ borderColor: bem.objectData.foto ? '#e5e7eb' : '#3b82f6' }}>
              {bem.objectData.foto ? (
                <img src={bem.objectData.foto} alt={bem.objectData.nome} className="w-full h-full object-cover" />
              ) : (
                <div className="icon-package text-xl text-blue-600"></div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold mb-1 break-words">{bem.objectData.nome}</h3>
              <p className="text-xs text-gray-500 mb-2">Cód: {bem.objectData.codigo}</p>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[bem.objectData.status]}`}>
                {bem.objectData.status === 'ABATIDO' ? 'Abatido' : bem.objectData.status === 'disponivel' ? 'Disponível' : bem.objectData.status === 'em_uso' ? 'Em Uso' : 'Manutenção'}
              </span>
            </div>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2 text-gray-600">
              <div className="icon-building text-base"></div>
              <span>{bem.objectData.departamento}</span>
            </div>
            
            {bem.objectData.sala && (
              <div className="flex items-center gap-2 text-gray-600">
                <div className="icon-map-pin text-base"></div>
                <span>{bem.objectData.sala}</span>
              </div>
            )}

            {bem.objectData.status === 'em_uso' && bem.objectData.responsavelAtual && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-2 mt-2">
                <div className="flex items-center gap-2 mb-1">
                  <div className="icon-user text-sm text-yellow-700"></div>
                  <span className="font-medium text-yellow-900 text-xs">{bem.objectData.responsavelAtual}</span>
                </div>
                {bem.objectData.dataAtribuicao && (
                  <p className="text-xs text-yellow-700">{calcularTempo(bem.objectData.dataAtribuicao)}</p>
                )}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}