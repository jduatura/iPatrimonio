// ============================================================
// NotificationCenter — Centro de Notificações e Alertas
// Sistema iPatrimônio — UCM
// ============================================================

function NotificationCenter({ user }) {
  const [notifications, setNotifications] = React.useState([]);
  const [showPanel, setShowPanel] = React.useState(false);
  const [unreadCount, setUnreadCount] = React.useState(0);
  const [checking, setChecking] = React.useState(false);

  React.useEffect(() => {
    if (!user) return;
    loadNotifications();
    // Polling a cada 30 segundos (não 5s para evitar sobrecarga)
    const interval = setInterval(loadNotifications, 30000);
    return () => clearInterval(interval);
  }, [user]);

  // Fechar painel ao clicar fora
  React.useEffect(() => {
    if (!showPanel) return;
    const handleOutside = (e) => {
      if (!e.target.closest('#notification-panel-wrapper')) {
        setShowPanel(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, [showPanel]);

  // ----------------------------------------------------------------
  // Carrega notificações do utilizador atual
  // ----------------------------------------------------------------
  const loadNotifications = async () => {
    if (!user) return;
    try {
      // Apenas utilizadores com papel operacional recebem notificações
      // (admin do sistema não recebe — apenas a Administração / dept)
      if (user.role === 'admin') {
        setNotifications([]);
        setUnreadCount(0);
        return;
      }

      // Executar verificações automáticas de alertas do sistema
      if (!checking) {
        setChecking(true);
        await checkSystemAlerts().finally(() => setChecking(false));
      }

      // Buscar todas as notificações (limite alto)
      const result = await dbListObjects('notificacao', 500);
      const allNotifs = result.items || [];

      // Filtrar por destinatário do utilizador atual
      const userNotifications = allNotifs.filter(n => {
        const data = n.objectData;
        if (!data) return false;

        const dest = data.destinatario || '';

        // Departamento Administração: vê notificações dirigidas à Administração
        if (user.department === 'Administração') {
          return dest === 'Administração' || dest === user.name || dest === user.username;
        }

        // Patrimônio: vê notificações dirigidas a 'patrimonio' e as suas pessoais
        if (user.role === 'patrimonio') {
          return dest === 'patrimonio' || dest === user.name || dest === user.username;
        }

        // Técnico / Departamento de Manutenção: vê notificações por nome/email
        if (user.role === 'tecnico' || user.department === 'Manutenção') {
          return dest === user.name || dest === user.username;
        }

        // Utilizador comum: apenas as suas pessoais
        return dest === user.name || dest === user.username;
      });

      // Ordenar: não lidas primeiro, depois mais recentes
      userNotifications.sort((a, b) => {
        const aUnread = !a.objectData.lida ? 1 : 0;
        const bUnread = !b.objectData.lida ? 1 : 0;
        if (aUnread !== bUnread) return bUnread - aUnread;
        return new Date(b.createdAt) - new Date(a.createdAt);
      });

      setNotifications(userNotifications);
      setUnreadCount(userNotifications.filter(n => !n.objectData.lida).length);
    } catch (error) {
      console.error('[NotificationCenter] Erro ao carregar notificações:', error);
      setNotifications([]);
      setUnreadCount(0);
    }
  };

  // ----------------------------------------------------------------
  // Verificações Automáticas de Alertas do Sistema
  // ----------------------------------------------------------------
  const checkSystemAlerts = async () => {
    try {
      const now = new Date();
      const nowISO = now.toISOString();
      const todayStr = nowISO.split('T')[0]; // YYYY-MM-DD

      // Buscar notificações existentes para deduplicação (limite maior)
      const existingResult = await dbListObjects('notificacao', 500);
      const existingNotifs = existingResult.items || [];

      const alreadyExists = (key) =>
        existingNotifs.some(n => n.objectData?.alertKey === key);

      // ----------------------------------------------------------
      // 1. ALERTA: STOCK BAIXO DE MATERIAIS CONSUMÍVEIS
      //    Apenas gera para patrimônio e Administração
      // ----------------------------------------------------------
      if (user.role === 'patrimonio' || user.department === 'Administração') {
        try {
          const bensList = await dbListObjects('bem', 1000);
          const consumiveisBaixos = (bensList.items || []).filter(b => {
            const d = b.objectData || {};
            if (d.categoria !== 'Consumível') return false;
            const qty = parseInt(d.quantidade) || 0;
            const minimo = parseInt(d.estoqueMinimo) || 5; // padrão 5 unidades
            return qty <= minimo;
          });

          for (const item of consumiveisBaixos) {
            const d = item.objectData;
            const qty = parseInt(d.quantidade) || 0;
            const minimo = parseInt(d.estoqueMinimo) || 5;

            // Alerta diário por item (reseta cada dia)
            const alertKey = `stock_baixo_${d.codigo}_${todayStr}`;
            if (!alreadyExists(alertKey)) {
              await dbCreateObject('notificacao', {
                destinatario: 'patrimonio',
                mensagem: `⚠️ Stock Crítico: O material "${d.nome}" (${d.codigo}) tem apenas ${qty} unidade(s) em stock (mínimo: ${minimo}). Solicite reposição urgente.`,
                tipo: 'stock_baixo',
                alertKey,
                lida: false,
                createdAt: nowISO
              });
            }
          }
        } catch (e) {
          console.warn('[Alertas] Erro ao verificar stock:', e);
        }
      }

      // ----------------------------------------------------------
      // 2. ALERTA: MANUTENÇÕES PREVENTIVAS AGENDADAS PRÓXIMAS (≤ 7 dias)
      //    Gera notificação para o técnico atribuído e para patrimônio
      // ----------------------------------------------------------
      if (
        user.role === 'patrimonio' ||
        user.role === 'tecnico' ||
        user.department === 'Manutenção' ||
        user.department === 'Administração'
      ) {
        try {
          const manutResult = await dbListObjects('manutencao', 500);
          const preventivas = (manutResult.items || []).filter(m => {
            const d = m.objectData || {};
            return (
              d.tipo === 'preventiva' &&
              d.status === 'preventiva_agendada' &&
              d.dataAgendada
            );
          });

          for (const m of preventivas) {
            const d = m.objectData;
            const dataAgendada = new Date(d.dataAgendada);
            const diffDias = Math.ceil((dataAgendada - now) / (1000 * 60 * 60 * 24));

            // Só alerta se dentro de 7 dias e ainda não passou
            if (diffDias < 0 || diffDias > 7) continue;

            const urgText = diffDias === 0
              ? 'HOJE'
              : diffDias === 1
                ? 'AMANHÃ'
                : `em ${diffDias} dias`;

            // Alerta diário por ordem preventiva
            const alertKeyTecnico = `preventiva_tecnico_${m.objectId}_${todayStr}`;
            const alertKeyPatrimonio = `preventiva_patrimonio_${m.objectId}_${todayStr}`;

            // Notificação ao técnico atribuído
            if (d.tecnicoNome && !alreadyExists(alertKeyTecnico)) {
              await dbCreateObject('notificacao', {
                destinatario: d.tecnicoNome,
                mensagem: `📅 Manutenção Preventiva ${urgText}: O bem "${d.bemNome}" (${d.bemCodigo}) — "${d.descricaoRotina || d.bemNome}" — está agendado para ${new Date(d.dataAgendada).toLocaleDateString('pt-BR')}.`,
                tipo: 'preventiva_agendada',
                alertKey: alertKeyTecnico,
                lida: false,
                createdAt: nowISO
              });
              // Também por email/username
              if (d.tecnicoEmail && d.tecnicoEmail !== d.tecnicoNome) {
                await dbCreateObject('notificacao', {
                  destinatario: d.tecnicoEmail,
                  mensagem: `📅 Manutenção Preventiva ${urgText}: O bem "${d.bemNome}" (${d.bemCodigo}) está agendado para ${new Date(d.dataAgendada).toLocaleDateString('pt-BR')}.`,
                  tipo: 'preventiva_agendada',
                  alertKey: `${alertKeyTecnico}_email`,
                  lida: false,
                  createdAt: nowISO
                });
              }
            }

            // Notificação ao patrimônio
            if (!alreadyExists(alertKeyPatrimonio)) {
              await dbCreateObject('notificacao', {
                destinatario: 'patrimonio',
                mensagem: `📅 Preventiva ${urgText}: "${d.bemNome}" (${d.bemCodigo}) — técnico: ${d.tecnicoNome || 'Não atribuído'} — prevista para ${new Date(d.dataAgendada).toLocaleDateString('pt-BR')}.`,
                tipo: 'preventiva_agendada',
                alertKey: alertKeyPatrimonio,
                lida: false,
                createdAt: nowISO
              });
            }
          }
        } catch (e) {
          console.warn('[Alertas] Erro ao verificar manutenções preventivas:', e);
        }
      }

      // ----------------------------------------------------------
      // 3. ALERTA: REQUISIÇÕES PENDENTES SEM VALIDAÇÃO
      //    Gera um único resumo diário para patrimônio
      // ----------------------------------------------------------
      if (user.role === 'patrimonio' || user.department === 'Administração') {
        try {
          const reqs = await dbListObjects('requisicao', 500);
          const pendentes = (reqs.items || []).filter(r => r.objectData?.status === 'pendente');

          if (pendentes.length > 0) {
            const alertKey = `reqs_pendentes_patrimonio_${todayStr}`;
            if (!alreadyExists(alertKey)) {
              await dbCreateObject('notificacao', {
                destinatario: 'patrimonio',
                mensagem: `📋 ${pendentes.length} requisição(ões) pendente(s) aguardam validação pelo Património. Verifique a lista de requisições.`,
                tipo: 'requisicao_pendente_alerta',
                alertKey,
                lida: false,
                createdAt: nowISO
              });
            }
          }

          // Requisições encaminhadas aguardando aprovação da Administração
          const aguardandoAdmin = (reqs.items || []).filter(r => r.objectData?.status === 'encaminhada');
          if (aguardandoAdmin.length > 0 && user.department === 'Administração') {
            const alertKey = `reqs_encaminhadas_admin_${todayStr}`;
            if (!alreadyExists(alertKey)) {
              await dbCreateObject('notificacao', {
                destinatario: 'Administração',
                mensagem: `📋 ${aguardandoAdmin.length} requisição(ões) encaminhada(s) aguardam a sua aprovação. Verifique a lista de requisições.`,
                tipo: 'requisicao_pendente_alerta',
                alertKey,
                lida: false,
                createdAt: nowISO
              });
            }
          }
        } catch (e) {
          console.warn('[Alertas] Erro ao verificar requisições pendentes:', e);
        }
      }

      // ----------------------------------------------------------
      // 4. ALERTA: ORDENS DE MANUTENÇÃO PENDENTES (sem técnico > 24h)
      //    Gera notificação para patrimônio
      // ----------------------------------------------------------
      if (user.role === 'patrimonio') {
        try {
          const manutResult = await dbListObjects('manutencao', 500);
          const semAtribuicao = (manutResult.items || []).filter(m => {
            const d = m.objectData || {};
            if (d.status !== 'pendente') return false;
            // Verificar se já tem mais de 24h sem atribuição
            const abertura = new Date(d.dataAbertura);
            const diffHoras = (now - abertura) / (1000 * 60 * 60);
            return diffHoras >= 24;
          });

          for (const m of semAtribuicao) {
            const d = m.objectData;
            const abertura = new Date(d.dataAbertura);
            const diffHoras = Math.floor((now - abertura) / (1000 * 60 * 60));
            const alertKey = `manutencao_sem_tecnico_${m.objectId}_${todayStr}`;
            if (!alreadyExists(alertKey)) {
              await dbCreateObject('notificacao', {
                destinatario: 'patrimonio',
                mensagem: `🔔 Ordem sem técnico há ${diffHoras}h: "${d.bemNome}" (${d.bemCodigo}) — ${d.numeroOrdem}. Atribua um técnico.`,
                tipo: 'manutencao_pendente_alerta',
                alertKey,
                lida: false,
                createdAt: nowISO
              });
            }
          }
        } catch (e) {
          console.warn('[Alertas] Erro ao verificar ordens sem técnico:', e);
        }
      }

    } catch (err) {
      console.warn('[NotificationCenter] Erro geral nas verificações automáticas:', err);
    }
  };

  // ----------------------------------------------------------------
  // Marcar como lida
  // ----------------------------------------------------------------
  const markAsRead = async (notificationId) => {
    try {
      const notif = await dbGetObject('notificacao', notificationId);
      await dbUpdateObject('notificacao', notificationId, {
        ...notif.objectData,
        lida: true
      });
    } catch (error) {
      // Fallback local
    }
    setNotifications(prev =>
      prev.map(n =>
        n.objectId === notificationId ? { ...n, objectData: { ...n.objectData, lida: true } } : n
      )
    );
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  // ----------------------------------------------------------------
  // Marcar todas como lidas
  // ----------------------------------------------------------------
  const markAllAsRead = async () => {
    const unread = notifications.filter(n => !n.objectData.lida);
    for (const notif of unread) {
      try {
        await dbUpdateObject('notificacao', notif.objectId, {
          ...notif.objectData,
          lida: true
        });
      } catch (_) {}
    }
    setNotifications(prev =>
      prev.map(n => ({ ...n, objectData: { ...n.objectData, lida: true } }))
    );
    setUnreadCount(0);
  };

  // ----------------------------------------------------------------
  // Não renderizar para admin do sistema
  // ----------------------------------------------------------------
  if (!user || user.role === 'admin') return null;

  return (
    <div className="relative" id="notification-panel-wrapper">
      {/* Botão Sino */}
      <button
        onClick={() => setShowPanel(prev => !prev)}
        className="relative p-2 hover:bg-blue-50 rounded-lg transition-colors"
        title="Notificações"
        aria-label={`Notificações${unreadCount > 0 ? ` — ${unreadCount} não lida(s)` : ''}`}
      >
        <div className="icon-bell text-xl" style={{ color: 'var(--primary-color)' }}></div>
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold leading-none">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Painel de Notificações */}
      {showPanel && (
        <div
          className="absolute right-0 mt-2 bg-white rounded-xl shadow-2xl z-50 flex flex-col border border-gray-100"
          style={{ width: '380px', maxWidth: 'calc(100vw - 16px)', maxHeight: '520px' }}
        >
          {/* Cabeçalho */}
          <div className="flex justify-between items-center px-4 py-3 border-b border-gray-200 bg-gray-50 rounded-t-xl">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wide">Notificações</h3>
              {unreadCount > 0 && (
                <span className="bg-[var(--primary-color)] text-white text-xs font-bold px-2 py-0.5 rounded-full ml-1 shadow-sm">
                  {unreadCount} nova{unreadCount > 1 ? 's' : ''}
                </span>
              )}
            </div>
            <div className="flex items-center gap-3">
              {unreadCount > 0 && (
                <button
                  onClick={markAllAsRead}
                  className="text-xs text-gray-500 hover:text-[var(--primary-color)] font-medium transition"
                >
                  Marcar todas lidas
                </button>
              )}
              <button
                onClick={() => setShowPanel(false)}
                className="text-gray-400 hover:text-gray-700 transition p-1"
                aria-label="Fechar"
              >
                <div className="icon-x text-base"></div>
              </button>
            </div>
          </div>

          {/* Lista */}
          <div className="overflow-y-auto flex-1">
            {notifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-gray-400 gap-3">
                <div className="icon-bell-off text-4xl"></div>
                <p className="text-sm font-medium">Sem notificações</p>
                <p className="text-xs text-gray-300">Ficará a saber quando houver novidades</p>
              </div>
            ) : (
              notifications.map(notif => (
                <NotificationItem
                  key={notif.objectId}
                  notification={notif}
                  onMarkAsRead={markAsRead}
                />
              ))
            )}
          </div>

          {/* Rodapé */}
          {notifications.length > 0 && (
            <div className="px-4 py-2 border-t text-center">
              <p className="text-xs text-gray-400">
                {notifications.length} notificação{notifications.length !== 1 ? 'ões' : ''}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ================================================================
// NotificationItem — Item individual de notificação
// ================================================================
function NotificationItem({ notification, onMarkAsRead }) {
  const { objectId, objectData, createdAt } = notification;
  const isUnread = !objectData.lida;

  const getConfig = () => {
    switch (objectData.tipo) {
      case 'nova_requisicao': return 'Nova Requisição';
      case 'requisicao_encaminhada': return 'Req. Encaminhada';
      case 'requisicao_aprovada': return 'Req. Aprovada';
      case 'requisicao_rejeitada': return 'Req. Reprovada';
      case 'requisicao_pendente_alerta': return 'Requisições Pendentes';
      case 'nova_manutencao': return 'Manutenção';
      case 'manutencao_aprovada': return 'Manutenção Aprovada';
      case 'manutencao_rejeitada': return 'Manutenção Reprovada';
      case 'manutencao_pendente_alerta': return 'Ordem sem Técnico';
      case 'stock_baixo': return 'Stock Crítico';
      case 'preventiva_agendada': return 'Manutenção Preventiva';
      default: return 'Notificação';
    }
  };

  const label = getConfig();

  const handleClick = () => {
    onMarkAsRead(objectId);

    const currentUser = getCurrentUser();
    if (!currentUser) return;

    // Navegar para a página relevante
    switch (objectData.tipo) {
      case 'nova_requisicao':
        window.location.href = currentUser.role === 'patrimonio'
          ? 'requisicoes-patrimonio.html'
          : 'minhas-requisicoes.html';
        break;
      case 'requisicao_encaminhada':
        window.location.href = currentUser.department === 'Administração'
          ? 'requisicoes.html'
          : 'requisicoes-patrimonio.html';
        break;
      case 'requisicao_aprovada':
      case 'requisicao_rejeitada':
        window.location.href = currentUser.role === 'patrimonio'
          ? 'requisicoes-patrimonio.html'
          : 'minhas-requisicoes.html';
        break;
      case 'requisicao_pendente_alerta':
        window.location.href = currentUser.role === 'patrimonio'
          ? 'requisicoes-patrimonio.html'
          : 'requisicoes.html';
        break;
      case 'nova_manutencao':
      case 'manutencao_aprovada':
      case 'manutencao_rejeitada':
      case 'manutencao_pendente_alerta':
      case 'preventiva_agendada':
        window.location.href = 'manutencao.html';
        break;
      case 'stock_baixo':
        window.location.href = 'bens-consumiveis.html';
        break;
      default:
        break;
    }
  };

  // Formatar data relativa
  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    try {
      const date = new Date(dateStr);
      const now = new Date();
      const diffMs = now - date;
      const diffMin = Math.floor(diffMs / 60000);
      const diffH = Math.floor(diffMs / 3600000);
      const diffD = Math.floor(diffMs / 86400000);

      if (diffMin < 1) return 'Agora mesmo';
      if (diffMin < 60) return `Há ${diffMin} min`;
      if (diffH < 24) return `Há ${diffH}h`;
      if (diffD < 7) return `Há ${diffD} dia${diffD > 1 ? 's' : ''}`;
      return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
    } catch (_) {
      return '';
    }
  };

  return (
    <div
      className={`px-4 py-3 border-b cursor-pointer transition-colors hover:bg-gray-50 ${isUnread ? 'bg-blue-50/30' : ''}`}
      onClick={handleClick}
    >
      <div className="flex items-start gap-3">
        {/* Conteúdo */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-1 mb-0.5">
            <span className="text-xs font-semibold uppercase tracking-wide text-[var(--primary-color)]">
              {label}
            </span>
            {isUnread && (
              <span className="w-2 h-2 rounded-full flex-shrink-0 bg-[var(--primary-color)]"></span>
            )}
          </div>
          <p className={`text-sm text-gray-700 leading-snug ${isUnread ? 'font-medium text-gray-900' : ''}`}>
            {objectData.mensagem}
          </p>
          <p className="text-xs text-gray-400 mt-1">
            {formatDate(createdAt || objectData.createdAt)}
          </p>
        </div>
      </div>
    </div>
  );
}