function DepartmentInventory({ departamento, bens }) {
  const [expanded, setExpanded] = React.useState(false);

  const estadoColors = {
    bom: 'bg-green-100 text-green-800',
    razoavel: 'bg-yellow-100 text-yellow-800',
    estragado: 'bg-red-100 text-red-800'
  };

  return (
    <div className="border rounded-lg overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full px-4 py-3 bg-gray-50 hover:bg-gray-100 transition flex justify-between items-center"
      >
        <div className="flex items-center gap-3">
          <div className="icon-building text-xl text-blue-600"></div>
          <div className="text-left">
            <h4 className="font-bold text-gray-800">{departamento}</h4>
            <p className="text-sm text-gray-600">{bens.length} {bens.length === 1 ? 'bem' : 'bens'}</p>
          </div>
        </div>
        <div className={`icon-chevron-down text-lg text-gray-600 transition-transform ${expanded ? 'rotate-180' : ''}`}></div>
      </button>

      {expanded && (
        <div className="p-4 bg-white">
          <div className="space-y-3">
            {bens.map(bem => {
              const data = bem.objectData;
              return (
                <div key={bem.objectId} className="border rounded-lg p-4 hover:shadow-sm transition">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h5 className="font-bold text-gray-800">{data.nome}</h5>
                      <p className="text-xs text-gray-500">Código: {data.codigo}</p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${estadoColors[data.estadoConservacao || 'bom']}`}>
                      {data.estadoConservacao === 'bom' ? 'Bom Estado' : 
                       data.estadoConservacao === 'razoavel' ? 'Estado Razoável' : 'Avariado'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-sm mb-2">
                    <div>
                      <span className="text-gray-500">Marca:</span>
                      <span className="ml-2 font-medium">{data.marca || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Modelo:</span>
                      <span className="ml-2 font-medium">{data.modelo || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Cor:</span>
                      <span className="ml-2 font-medium">{data.cor || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Localização:</span>
                      <span className="ml-2 font-medium">{data.localizacao || data.departamento || 'Instalações UCM-FADIR'}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Responsável:</span>
                      <span className="ml-2 font-medium">{data.responsavelAtual || 'Sem responsável'}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Valor:</span>
                      <span className="ml-2 font-medium">{data.preco ? `${parseFloat(data.preco).toFixed(2)} MZN` : 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Aquisição:</span>
                      <span className="ml-2 font-medium">
                        {data.dataAquisicao ? new Date(data.dataAquisicao).toLocaleDateString('pt-BR') : 'N/A'}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-500">Ano:</span>
                      <span className="ml-2 font-medium">
                        {data.dataAquisicao ? new Date(data.dataAquisicao).getFullYear() : 'N/A'}
                      </span>
                    </div>
                  </div>

                  {data.descricao && (
                    <div className="mt-2 p-2 bg-gray-50 rounded text-sm">
                      <span className="text-gray-500">Descrição:</span>
                      <p className="text-gray-700 mt-1">{data.descricao}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}