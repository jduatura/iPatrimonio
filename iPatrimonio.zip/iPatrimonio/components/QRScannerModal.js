function QRScannerModal({ isOpen, onClose, onScanSuccess }) {
  const videoRef = React.useRef(null);
  const canvasRef = React.useRef(null);
  const [errorMsg, setErrorMsg] = React.useState('');
  const [scanning, setScanning] = React.useState(false);
  const streamRef = React.useRef(null);
  const animationFrameRef = React.useRef(null);

  React.useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    setErrorMsg('');
    setScanning(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', true);
        videoRef.current.play();
        requestAnimationFrame(tick);
      }
    } catch (err) {
      console.error("Erro ao acessar câmera:", err);
      setErrorMsg('Não foi possível acessar a câmera. Verifique as permissões do navegador.');
      setScanning(false);
    }
  };

  const stopCamera = () => {
    setScanning(false);
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  const tick = () => {
    if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
      const canvas = canvasRef.current || document.createElement('canvas');
      canvasRef.current = canvas;
      const ctx = canvas.getContext('2d');
      canvas.height = videoRef.current.videoHeight;
      canvas.width = videoRef.current.videoWidth;
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

      if (window.jsQR) {
        const code = window.jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert'
        });
        if (code && code.data) {
          stopCamera();
          onScanSuccess(code.data);
          return;
        }
      }
    }
    animationFrameRef.current = requestAnimationFrame(tick);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg p-5 w-full max-w-md text-center relative">
        <button 
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-800 text-xl font-bold p-1"
        >
          ✕
        </button>
        
        <h3 className="text-xl font-bold mb-1 text-gray-800">Leitor de QR Code / Código de Barras</h3>
        <p className="text-xs text-gray-500 mb-4">Aponte a câmera do smartphone ou computador para o código do bem</p>

        {errorMsg ? (
          <div className="bg-red-50 text-red-600 p-4 rounded-lg text-sm mb-4">
            {errorMsg}
          </div>
        ) : (
          <div className="relative w-full aspect-square bg-black rounded-lg overflow-hidden flex items-center justify-center mb-4 border-2 border-blue-500">
            <video ref={videoRef} className="w-full h-full object-cover" />
            <div className="absolute inset-0 border-2 border-dashed border-yellow-400 m-12 pointer-events-none rounded-lg animate-pulse flex items-center justify-center">
              <span className="bg-black/60 text-white text-xs px-2 py-1 rounded">Alinhe o código aqui</span>
            </div>
          </div>
        )}

        <div className="flex justify-end gap-2">
          <button 
            onClick={onClose}
            className="btn bg-gray-200 text-gray-800 hover:bg-gray-300 w-full"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
}
