function AbateForm({ user, onClose, setAlert }) {
  const [formData, setFormData] = React.useState({
    numeroGuia: '',
    descricaoBem: '',
    cor: '',
    estadoBem: '',
    quantidade: '',
    dataAquisicao: '',
    valorAquisicao: '',
    localizacao: '',
    valor: '',
    motivoAbate: '',
    observacoes: '',
    dataAbate: new Date().toISOString().split('T')[0],
    responsavel: user.name || ''
  });

  function handleChange(e) {
    const { name, value } = e.target;
    if (name === 'numeroGuia') {
      // Allow only numbers
      if (value === '' || /^\d+$/.test(value)) {
        setFormData({ ...formData, [name]: value });
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    
    if (!formData.estadoBem || formData.estadoBem.trim() === '') {
      setAlert({ type: 'error', message: 'Estado do bem é obrigatório' });
      return;
    }

    if (parseFloat(formData.quantidade) <= 0) {
      setAlert({ type: 'error', message: 'Quantidade deve ser maior que zero' });
      return;
    }

    if (parseFloat(formData.valorAquisicao) <= 0) {
      setAlert({ type: 'error', message: 'Valor de aquisição deve ser maior que zero' });
      return;
    }

    if (parseFloat(formData.valor) <= 0) {
      setAlert({ type: 'error', message: 'Valor atual deve ser maior que zero' });
      return;
    }

    if (!formData.dataAquisicao) {
      setAlert({ type: 'error', message: 'Data de aquisição é obrigatória' });
      return;
    }

    if (!formData.localizacao || formData.localizacao.trim() === '') {
      setAlert({ type: 'error', message: 'Localização é obrigatória' });
      return;
    }

    try {
      const abateData = {
        ...formData,
        quantidade: parseFloat(formData.quantidade),
        valorAquisicao: parseFloat(formData.valorAquisicao),
        valor: parseFloat(formData.valor),
        createdBy: user.email,
        createdAt: new Date().toISOString()
      };
      await dbCreateObject('abate', abateData);
      await logAuditAction(AUDIT_ACTIONS.CRIAR_BEM, `Abate registrado: ${formData.descricaoBem}`, user);
      setAlert({ type: 'success', message: 'Abate registrado com sucesso!' });
      setTimeout(() => onClose(), 1500);
    } catch (error) {
      console.error('Error creating abate:', error);
      setAlert({ type: 'error', message: 'Erro ao registrar abate: ' + (error.message || 'Erro desconhecido') });
    }
  }

  return (
    <div className="card mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Formulário de Abate</h2>
        <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
          <div className="icon-x text-xl"></div>
        </button>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Nº Guia*</label>
          <input type="text" name="numeroGuia" value={formData.numeroGuia} onChange={handleChange} className="input-field" placeholder="Somente números" required />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Descrição do Bem*</label>
          <input type="text" name="descricaoBem" value={formData.descricaoBem} onChange={handleChange} className="input-field" required />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Cor</label>
            <input type="text" name="cor" value={formData.cor} onChange={handleChange} className="input-field" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Estado do Bem*</label>
            <select name="estadoBem" value={formData.estadoBem} onChange={handleChange} className="input-field" required>
              <option value="">Selecione...</option>
              <option value="Bom">Bom</option>
              <option value="Regular">Regular</option>
              <option value="Ruim">Ruim</option>
              <option value="Danificado">Danificado</option>
              <option value="Obsoleto">Obsoleto</option>
            </select>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Quantidade*</label>
            <input type="number" name="quantidade" value={formData.quantidade} onChange={handleChange} className="input-field" min="1" step="1" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Data Aquisição*</label>
            <input type="date" name="dataAquisicao" value={formData.dataAquisicao} onChange={handleChange} className="input-field" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Valor Aquisição (MT)*</label>
            <input type="number" name="valorAquisicao" value={formData.valorAquisicao} onChange={handleChange} className="input-field" min="0.01" step="0.01" required />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Localização*</label>
            <input type="text" name="localizacao" value={formData.localizacao} onChange={handleChange} className="input-field" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Valor Atual (MT)*</label>
            <input type="number" name="valor" value={formData.valor} onChange={handleChange} className="input-field" min="0.01" step="0.01" required />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Motivo do Abate*</label>
          <textarea name="motivoAbate" value={formData.motivoAbate} onChange={handleChange} className="input-field" rows="2" required />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
          <textarea name="observacoes" value={formData.observacoes} onChange={handleChange} className="input-field" rows="2" placeholder="Observações adicionais (opcional)" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Data do Abate*</label>
            <input type="date" name="dataAbate" value={formData.dataAbate} onChange={handleChange} className="input-field" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Responsável*</label>
            <input type="text" name="responsavel" value={formData.responsavel} onChange={handleChange} className="input-field" required />
          </div>
        </div>
        <div className="flex justify-end space-x-3">
          <button type="button" onClick={onClose} className="btn bg-gray-200 text-gray-800 hover:bg-gray-300">Cancelar</button>
          <button type="submit" className="btn btn-primary">Registrar Abate</button>
        </div>
      </form>
    </div>
  );
}