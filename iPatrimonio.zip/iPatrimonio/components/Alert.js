function Alert({ message, type = 'success', onClose }) {
  React.useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 5000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed top-4 right-4 z-50 animate-slide-in" data-name="alert" data-file="components/Alert.js">
      <div className="bg-white border-l-4 border-[var(--primary-color)] rounded-r-lg p-4 shadow-lg max-w-md flex items-start space-x-3">
        <div className="flex-1">
          <p className="text-gray-800 font-medium">{message}</p>
        </div>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
          <div className="icon-x text-lg"></div>
        </button>
      </div>
    </div>
  );
}