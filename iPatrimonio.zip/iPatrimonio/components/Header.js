function Header({ user }) {
  const [showMenu, setShowMenu] = React.useState(false);

  const handleLogout = () => {
    logout();
  };

  return (
    <header className="bg-white shadow-md" data-name="header" data-file="components/Header.js">
      <div className="px-4 md:px-6 py-3 md:py-4 flex items-center justify-between">
        <div className="flex items-center space-x-2 md:space-x-4">
          <div>
            <img src="assets/logo.png" alt="UCM Logo" className="h-8 md:h-10 w-auto" />
          </div>
          <div>
            <h2 className="text-base md:text-lg font-semibold text-[var(--primary-color)]">iPatrimônio</h2>
            <p className="text-xs text-gray-600 hidden sm:block">UCM-FADIR</p>
          </div>
        </div>
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="flex items-center space-x-2 md:space-x-3 hover:bg-gray-100 rounded-lg px-2 md:px-3 py-1.5 md:py-2 transition"
          >
            <div className="w-8 h-8 md:w-10 md:h-10 bg-blue-100 rounded-full flex items-center justify-center">
              <div className="icon-user text-lg md:text-xl text-blue-600"></div>
            </div>
            <div className="text-left hidden sm:block">
              <p className="font-medium text-xs md:text-sm text-gray-800">{user?.name}</p>
              <p className="text-xs text-gray-600">{user?.department}</p>
            </div>
          </button>
          {showMenu && (
            <div className="absolute right-0 mt-2 w-40 md:w-48 bg-white rounded-lg shadow-lg py-2 z-50">
              <a href="dashboard.html" className="block px-3 md:px-4 py-2 hover:bg-gray-100 text-sm">Dashboard</a>
              <a href="profile.html" className="block px-3 md:px-4 py-2 hover:bg-gray-100 text-sm">Perfil</a>
              <button onClick={handleLogout} className="block w-full text-left px-3 md:px-4 py-2 hover:bg-gray-100 text-red-600 text-sm">
                Sair
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}