function EditModal({ requisicao, onSave, onClose }) {
  const [itens, setItens] = React.useState([]);
  const [motivoEdicao, setMotivoEdicao] = React.useState('');

  React.useEffect(() => {
    if (requisicao && requisicao.objectData.itensDetalhados) {
      setItens(requisicao.objectData.itensDetalhados.map(item => ({...item})));
    }
  }, [requisicao]);

  const handleQuantityChange = (index, newQty) => {
    const updated = [...itens];
    updated[index].quantidade = parseInt(newQty) || 0;
    setItens(updated);
  };

  const handleSave = () => {
    onSave(itens, motivoEdicao);
  };

  if (!requisicao) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-xl font-bold">Editar Requisição</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <div className="icon-x text-2xl"></div>
            </button>
          </div>

          <div className="mb-4">
            <p className="text-sm text-gray-600">
              <strong>Solicitante:</strong> {requisicao.objectData.solicitante}
            </p>
            <p className="text-sm text-gray-600">
              <strong>Departamento:</strong> {requisicao.objectData.departamento}
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-sm">Itens da Requisição:</h3>
            {itens.map((item, index) => (
              <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded">
                <div className="flex-1">
                  <p className="font-medium text-sm">{item.descricao}</p>
                </div>
                <div className="w-24">
                  <input
                    type="number"
                    min="0"
                    value={item.quantidade}
                    onChange={(e) => handleQuantityChange(index, e.target.value)}
                    className="input-field text-center"
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4">
            <label className="block text-sm font-semibold mb-2">
              Motivo da Edição (Opcional):
            </label>
            <textarea
              value={motivoEdicao}
              onChange={(e) => setMotivoEdicao(e.target.value)}
              className="input-field"
              rows="3"
              placeholder="Descreva o motivo da alteração das quantidades..."
            />
          </div>

          <div className="flex gap-3 mt-6">
            <button onClick={onClose} className="btn bg-gray-200 text-gray-800 hover:bg-gray-300 flex-1">
              Cancelar
            </button>
            <button onClick={handleSave} className="btn btn-primary flex-1">
              Salvar Alterações
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}