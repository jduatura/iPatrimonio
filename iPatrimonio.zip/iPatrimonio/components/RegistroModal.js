function RegistroModal({ onClose, onSave }) {
  const [formData, setFormData] = React.useState({
    numeroGuiaSaida: '',
    dataSaida: new Date().toISOString().split('T')[0],
    descricaoMaterial: '',
    quantidade: '',
    responsavelRequisicao: '',
    observacoes: ''
  });
  const [errors, setErrors] = React.useState({});

  const validateField = (name, value) => {
    switch(name) {
      case 'numeroGuiaSaida':
        if (!value.trim()) return 'Número da guia é obrigatório';
        return '';
      case 'descricaoMaterial':
        if (!value.trim()) return 'Descrição é obrigatória';
        return '';
      case 'quantidade':
        if (!value) return 'Quantidade é obrigatória';
        if (!/^\d+$/.test(value)) return 'Apenas números são permitidos';
        if (parseInt(value) <= 0) return 'Quantidade deve ser maior que zero';
        return '';

      case 'responsavelRequisicao':
        if (!value.trim()) return 'Requisitante é obrigatório';
        if (!/^[a-zA-ZÀ-ÿ\s]+$/.test(value)) return 'Apenas letras são permitidas';
        return '';
      default:
        return '';
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({...formData, [name]: value});
    const error = validateField(name, value);
    setErrors({...errors, [name]: error});
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = {};
    let hasError = false;
    
    ['numeroGuiaSaida', 'descricaoMaterial', 'quantidade', 'responsavelRequisicao'].forEach(field => {
      const error = validateField(field, formData[field]);
      if (error) {
        newErrors[field] = error;
        hasError = true;
      }
    });

    if (hasError) {
      setErrors(newErrors);
      return;
    }
    
    const dataToSave = {
      ...formData,
      numeroDocumento: formData.numeroGuiaSaida
    };
    onSave(dataToSave);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-2 sm:p-4">
      <div className="bg-white rounded-lg p-3 sm:p-4 md:p-6 w-full max-w-2xl max-h-[95vh] sm:max-h-[90vh] overflow-y-auto">
        <h2 className="text-lg sm:text-xl md:text-2xl font-bold mb-2 sm:mb-3 md:mb-4">Novo Registro de Saída</h2>
        <form onSubmit={handleSubmit} className="space-y-3 md:space-y-4">
          <div>
            <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">Número da Guia de Saída *</label>
            <input type="text" name="numeroGuiaSaida" className={`input-field text-sm md:text-base ${errors.numeroGuiaSaida ? 'border-red-500' : ''}`}
              value={formData.numeroGuiaSaida} onChange={handleChange}
              placeholder="Ex: GS-2025-001" />
            {errors.numeroGuiaSaida && <p className="text-red-500 text-xs mt-1">{errors.numeroGuiaSaida}</p>}
          </div>
          <div>
            <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">Data *</label>
            <input type="date" name="dataSaida" className="input-field text-sm md:text-base" value={formData.dataSaida}
              onChange={handleChange} required />
          </div>
          <div>
            <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">Descrição do Material *</label>
            <input type="text" name="descricaoMaterial" className={`input-field text-sm md:text-base ${errors.descricaoMaterial ? 'border-red-500' : ''}`}
              value={formData.descricaoMaterial} onChange={handleChange}
              placeholder="Descrição do material" />
            {errors.descricaoMaterial && <p className="text-red-500 text-xs mt-1">{errors.descricaoMaterial}</p>}
          </div>
          <div>
            <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">Quantidade *</label>
            <input type="text" name="quantidade" className={`input-field text-sm md:text-base ${errors.quantidade ? 'border-red-500' : ''}`}
              value={formData.quantidade} onChange={handleChange} />
            {errors.quantidade && <p className="text-red-500 text-xs mt-1">{errors.quantidade}</p>}
          </div>
          <div>
            <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">Requisitante *</label>
            <input type="text" name="responsavelRequisicao" className={`input-field text-sm md:text-base ${errors.responsavelRequisicao ? 'border-red-500' : ''}`}
              value={formData.responsavelRequisicao} onChange={handleChange}
              placeholder="Nome do requisitante" />
            {errors.responsavelRequisicao && <p className="text-red-500 text-xs mt-1">{errors.responsavelRequisicao}</p>}
          </div>
          <div>
            <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">Observações</label>
            <textarea name="observacoes" className="input-field text-sm md:text-base" rows="3" value={formData.observacoes}
              onChange={handleChange} placeholder="Observações adicionais"></textarea>
          </div>
          <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-3 pt-3 md:pt-4 border-t">
            <button type="button" onClick={onClose} 
              className="btn bg-gray-200 text-gray-800 hover:bg-gray-300 w-full sm:w-auto">
              Cancelar
            </button>
            <button type="submit" className="btn btn-primary w-full sm:w-auto">Registrar</button>
          </div>
        </form>
      </div>
    </div>
  );
}