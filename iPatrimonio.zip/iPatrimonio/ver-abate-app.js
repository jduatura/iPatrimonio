function VerAbateApp() {
  const [user, setUser] = React.useState(null);
  const [abates, setAbates] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [searchTerm, setSearchTerm] = React.useState('');

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    if (currentUser.role !== 'default' || currentUser.department !== 'Administração') {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadAbates();
  }, []);

  const loadAbates = async () => {
    try {
      const result = await dbListObjects('abate', 100, true);
      setAbates(result.items);
    } catch (error) {
      console.error('Error loading abates:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredAbates = abates.filter(abate => {
    const search = searchTerm.toLowerCase();
    return abate.objectData.numeroPatrimonio?.toLowerCase().includes(search) ||
           abate.objectData.descricaoBem?.toLowerCase().includes(search) ||
           abate.objectData.motivoAbate?.toLowerCase().includes(search);
  });

  if (!user) return null;

  return (
    <div className="bg-gray-100 min-h-screen flex flex-col">
      <Header user={user} />
      
      <main className="flex-grow p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-800">Ver Abates de Bens</h1>
            <button onClick={() => window.location.href = 'dashboard.html'} className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300">
              Voltar
            </button>
          </div>

          <div className="card mb-6">
            <input
              type="text"
              placeholder="Pesquisar por patrimônio, descrição ou motivo..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-field"
            />
          </div>

          {loading ? (
            <div className="text-center py-8">Carregando...</div>
          ) : (
            <div className="card">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Patrimônio</th>
                      <th className="text-left py-3 px-4">Descrição</th>
                      <th className="text-left py-3 px-4">Motivo</th>
                      <th className="text-left py-3 px-4">Data</th>
                      <th className="text-left py-3 px-4">Responsável</th>
                      <th className="text-left py-3 px-4">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAbates.length === 0 ? (
                      <tr><td colSpan="6" className="text-center py-8 text-gray-500">Nenhum abate encontrado</td></tr>
                    ) : (
                      filteredAbates.map(abate => (
                        <tr key={abate.objectId} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4">{abate.objectData.numeroPatrimonio}</td>
                          <td className="py-3 px-4">{abate.objectData.descricaoBem}</td>
                          <td className="py-3 px-4">{abate.objectData.motivoAbate}</td>
                          <td className="py-3 px-4">{new Date(abate.objectData.dataAbate).toLocaleDateString('pt-BR')}</td>
                          <td className="py-3 px-4">{abate.objectData.responsavel}</td>
                          <td className="py-3 px-4">
                            <button
                              onClick={() => window.open(`imprimir-abate.html?id=${abate.objectId}`, '_blank')}
                              className="text-blue-600 hover:text-blue-800"
                            >
                              Ver Detalhes
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<VerAbateApp />);


