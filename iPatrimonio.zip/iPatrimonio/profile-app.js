function ProfileApp() {
  const [user, setUser] = React.useState(null);
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');
  const [passwordData, setPasswordData] = React.useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [passwordError, setPasswordError] = React.useState('');

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    setUser(currentUser);
  }, []);

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    
    if (passwordData.newPassword.length < 8) {
      setPasswordError('A nova senha deve ter no mínimo 8 caracteres');
      return;
    }
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setPasswordError('As senhas não correspondem');
      return;
    }
    
    try {
      const userData = await dbGetObject('usuario', user.id);
      if (userData.objectData.password !== passwordData.currentPassword) {
        setAlertMessage('Senha atual incorreta');
        setAlertType('error');
        setShowAlert(true);
        return;
      }
      await dbUpdateObject('usuario', user.id, {
        ...userData.objectData,
        password: passwordData.newPassword
      });
      await logAuditAction(AUDIT_ACTIONS.ALTERAR_SENHA, `Senha alterada pelo usuário`, user);
      setAlertMessage('Senha alterada com sucesso!');
      setAlertType('success');
      setShowAlert(true);
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setPasswordError('');
    } catch (error) {
      setAlertMessage('Erro ao alterar senha');
      setAlertType('error');
      setShowAlert(true);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} currentPage="profile" />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      <main className="flex-grow p-6">
        <button
          onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
        >
          <div className="icon-arrow-left text-lg"></div>
          <span>Voltar</span>
        </button>
        
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Meu Perfil</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1">
              <div className="card text-center">
                <div className="w-32 h-32 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg border-4 border-[var(--primary-color)]">
                  <span className="text-6xl font-bold text-white">{user.name.charAt(0).toUpperCase()}</span>
                </div>
                <h2 className="text-xl font-bold mb-1">{user.name}</h2>
                <p className="text-gray-500 text-sm mb-4">{user.department}</p>
                <div className={`inline-block px-4 py-2 rounded-full text-sm font-medium ${
                  user.role === 'admin' ? 'bg-blue-50 text-blue-800 border border-blue-200' :
                  user.role === 'patrimonio' ? 'bg-blue-100 text-blue-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {user.role === 'admin' ? 'Administrador' : 
                   user.role === 'patrimonio' ? 'Gestor de Patrimônio' : 'Usuário'}
                </div>
              </div>
            </div>

            <div className="md:col-span-2">
              <div className="card">
                <h3 className="text-xl font-bold mb-6 flex items-center">
                  <div className="icon-info text-xl text-blue-600 mr-2"></div>
                  Informações da Conta
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start p-4 bg-gray-50 rounded-lg">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                      <div className="icon-user text-xl text-blue-600"></div>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-500 mb-1">Nome de Usuário</p>
                      <p className="font-medium text-gray-900">{user.username}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start p-4 bg-gray-50 rounded-lg">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                      <div className="icon-building text-xl text-green-600"></div>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-500 mb-1">Departamento</p>
                      <p className="font-medium text-gray-900">{user.department}</p>
                    </div>
                  </div>

                  <div className="flex items-start p-4 bg-gray-50 rounded-lg">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                      <div className="icon-shield text-xl text-purple-600"></div>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-500 mb-1">Nível de Acesso</p>
                      <p className="font-medium text-gray-900">
                        {user.role === 'admin' ? 'Administrador do Sistema' : 
                         user.role === 'patrimonio' ? 'Gestor de Patrimônio' : 'Usuário Padrão'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="card mt-6">
                <h3 className="text-xl font-bold mb-6 flex items-center">
                  <div className="icon-lock text-xl text-blue-600 mr-2"></div>
                  Alterar Senha
                </h3>
                <form onSubmit={handlePasswordChange} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-700">Senha Atual</label>
                    <input 
                      type="password" 
                      className="input-field"
                      value={passwordData.currentPassword}
                      onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-700">Nova Senha</label>
                    <input 
                      type="password" 
                      className="input-field"
                      value={passwordData.newPassword}
                      minLength="8"
                      onChange={(e) => {
                        setPasswordData({...passwordData, newPassword: e.target.value});
                        setPasswordError('');
                      }}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-700">Confirmar Nova Senha</label>
                    <input 
                      type="password" 
                      className="input-field"
                      value={passwordData.confirmPassword}
                      minLength="8"
                      onChange={(e) => {
                        setPasswordData({...passwordData, confirmPassword: e.target.value});
                        setPasswordError('');
                      }}
                      required
                    />
                    {passwordError && <p className="text-red-500 text-xs mt-1">{passwordError}</p>}
                  </div>
                  <button type="submit" className="btn btn-primary w-full">
                    Atualizar Senha
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ProfileApp />);

