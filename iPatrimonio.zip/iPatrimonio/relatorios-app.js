function RelatoriosApp() {
  const [user, setUser] = React.useState(null);
  const [report, setReport] = React.useState(null);
  const [bensData, setBensData] = React.useState([]);
  const [requisicoesData, setRequisicoesData] = React.useState([]);
  const [filterPeriod, setFilterPeriod] = React.useState('mes');
  const [filterDept, setFilterDept] = React.useState('');
  const [filterUser, setFilterUser] = React.useState('');
  const [filterRequisitante, setFilterRequisitante] = React.useState('');

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    setUser(currentUser);
    generateReport();
  }, [filterPeriod, filterDept, filterUser, filterRequisitante]);

  const generateReport = async () => {
    const bens = await dbListObjects('bem', 1000);
    const requisicoes = await dbListObjects('requisicao', 1000);
    const manutencoes = await dbListObjects('manutencao', 1000);
    const historicosManutencao = await dbListObjects('historico_manutencao', 1000);
    
    let filteredBens = bens.items || [];
    if (filterDept) {
      filteredBens = filteredBens.filter(b => b.objectData.departamento === filterDept);
    }
    
    const now = new Date();
    const filteredReqs = (requisicoes.items || []).filter(r => {
      const reqDate = new Date(r.createdAt);
      let isInPeriod = true;
      
      if (filterPeriod === 'dia') {
        isInPeriod = reqDate.toDateString() === now.toDateString();
      } else if (filterPeriod === 'semana') {
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        isInPeriod = reqDate >= weekAgo;
      } else if (filterPeriod === 'mes') {
        isInPeriod = reqDate.getMonth() === now.getMonth() && reqDate.getFullYear() === now.getFullYear();
      } else if (filterPeriod === 'semestre') {
        const semester = Math.floor(now.getMonth() / 6);
        const reqSemester = Math.floor(reqDate.getMonth() / 6);
        isInPeriod = reqSemester === semester && reqDate.getFullYear() === now.getFullYear();
      } else if (filterPeriod === 'ano') {
        isInPeriod = reqDate.getFullYear() === now.getFullYear();
      }
      
      if (filterDept && r.objectData.departamento !== filterDept) return false;
      if (filterUser) {
        const solicitante = (r.objectData.solicitante || '').toLowerCase();
        const filterLower = filterUser.toLowerCase().trim();
        if (!solicitante.includes(filterLower)) return false;
      }

      if (filterRequisitante) {
        const solicitante = (r.objectData.solicitante || '').toLowerCase();
        const filterLower = filterRequisitante.toLowerCase().trim();
        if (!solicitante.includes(filterLower)) return false;
      }
      
      return isInPeriod;
    });

    // Manutenções e Histórico de Manutenção
    const allManutencoes = manutencoes.items || [];
    const allHistManutencao = historicosManutencao.items || [];

    // Cálculo de Custos de Manutenção
    const custoManutencaoTotal = allHistManutencao.reduce((acc, h) => acc + (parseFloat(h.objectData?.custoTotal) || 0), 0);

    // Bens mais avariados (contagem de ordens de manutenção por bem)
    const avariasCountByBem = {};
    allManutencoes.forEach(m => {
      const code = m.objectData?.bemCodigo || m.objectData?.bemNome;
      if (code) {
        if (!avariasCountByBem[code]) {
          avariasCountByBem[code] = {
            codigo: m.objectData.bemCodigo || 'N/A',
            nome: m.objectData.bemNome || code,
            count: 0,
            departamento: m.objectData.departamento || 'N/A'
          };
        }
        avariasCountByBem[code].count += 1;
      }
    });

    const bensMaisAvariados = Object.values(avariasCountByBem)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // Cálculo de Depreciação (Método de Linha Reta: Vida útil padrão de 5 anos = 20% ao ano)
    let valorOriginalTotal = 0;
    let valorAtualTotal = 0;
    let depreciacaoAcumuladaTotal = 0;

    filteredBens.forEach(b => {
      const p = parseFloat(b.objectData.preco) || 0;
      valorOriginalTotal += p;

      const dataAq = b.objectData.dataAquisicao ? new Date(b.objectData.dataAquisicao) : null;
      let anosUso = 0;
      if (dataAq && !isNaN(dataAq.getTime())) {
        anosUso = Math.max(0, (now.getFullYear() - dataAq.getFullYear()));
      }

      // Taxa de depreciação de 20% ao ano, limite mínimo de 10% do valor residual
      const taxaDepreciacaoAnual = 0.20;
      const pctDepreciado = Math.min(0.90, anosUso * taxaDepreciacaoAnual);
      const valDepreciado = p * pctDepreciado;
      const valAtual = p - valDepreciado;

      depreciacaoAcumuladaTotal += valDepreciado;
      valorAtualTotal += valAtual;
    });
    
    const bensByDept = {};
    filteredBens.forEach(b => {
      const dept = b.objectData.departamento || 'Não especificado';
      if (!bensByDept[dept]) bensByDept[dept] = [];
      bensByDept[dept].push(b);
    });
    
    setBensData(filteredBens);
    setRequisicoesData(filteredReqs);
    
    setReport({
      totalBens: filteredBens.length,
      bensDisponiveis: filteredBens.filter(b => b.objectData.status === 'disponivel').length,
      bensEmUso: filteredBens.filter(b => b.objectData.status === 'em_uso').length,
      bensManutencao: filteredBens.filter(b => b.objectData.status === 'manutencao' || b.objectData.status === 'avariado').length,
      totalRequisicoes: filteredReqs.length,
      requisicoesAprovadas: filteredReqs.filter(r => r.objectData.status === 'aprovada').length,
      requisicoesPendentes: filteredReqs.filter(r => r.objectData.status === 'pendente').length,
      requisicoesRejeitadas: filteredReqs.filter(r => r.objectData.status === 'rejeitada').length,
      bensByDept: bensByDept,
      custoManutencaoTotal,
      bensMaisAvariados,
      valorOriginalTotal,
      valorAtualTotal,
      depreciacaoAcumuladaTotal
    });
  };

  const exportToExcel = (data, filename, sheetName = 'Dados') => {
    const wb = ExcelExporter.createWorkbook();
    ExcelExporter.addWorksheet(wb, data, sheetName);
    ExcelExporter.export(wb, `${filename}_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const handlePrintReport = () => {
    window.print();
  };

  const handleExportBens = async () => {
    const title = ['RELATÓRIO DE BENS PATRIMONIAIS'];
    const subtitle = [`Data: ${new Date().toLocaleDateString('pt-BR')}  |  Departamento: ${filterDept || 'Todos'}`];
    const empty = [''];
    const headers = ['Código', 'Nome', 'Departamento', 'Localização', 'Categoria', 'Quantidade', 'Status', 'Preço (MZN)'];
    const rows = bensData.map(bem => [
      bem.objectData.codigo,
      bem.objectData.nome,
      bem.objectData.departamento || 'N/A',
      bem.objectData.localizacao || 'N/A',
      bem.objectData.categoria,
      bem.objectData.quantidade,
      bem.objectData.status === 'disponivel' ? 'Disponível' : 
        bem.objectData.status === 'em_uso' ? 'Em Uso' : 'Manutenção',
      bem.objectData.preco ? parseFloat(bem.objectData.preco).toFixed(2) : 'N/A'
    ]);
    const footer = ['', '', '', '', '', `Total: ${bensData.length} bens`, '', ''];
    exportToExcel([title, subtitle, empty, headers, ...rows, empty, footer], `bens_${filterDept || 'todos'}`, 'Bens');
    await logAuditAction(AUDIT_ACTIONS.EXPORTAR_RELATORIO, `Exportação de relatório de bens (${bensData.length} registros)`, user);
  };

  const handleExportRequisicoes = async () => {
    const title = ['RELATÓRIO DE REQUISIÇÕES'];
    const subtitle = [`Período: ${getPeriodLabel()}  |  Departamento: ${filterDept || 'Todos'}  |  Data: ${new Date().toLocaleDateString('pt-BR')}`];
    const empty = [''];
    const headers = ['Solicitante', 'Departamento', 'Tipo', 'Bens', 'Motivo', 'Status', 'Data'];
    const rows = requisicoesData.map(req => [
      req.objectData.solicitante,
      req.objectData.departamento,
      req.objectData.tipo === 'pessoal' ? 'Pessoal' : 'Departamento',
      Array.isArray(req.objectData.bens) ? req.objectData.bens.join('; ') : req.objectData.bens,
      req.objectData.motivo,
      req.objectData.status === 'aprovada' ? 'Aprovada' :
        req.objectData.status === 'pendente' ? 'Pendente' : 'Rejeitada',
      new Date(req.createdAt).toLocaleString('pt-BR')
    ]);
    const footer = ['', '', '', '', '', `Total: ${requisicoesData.length} requisições`, '', ''];
    exportToExcel([title, subtitle, empty, headers, ...rows, empty, footer], `requisicoes_${filterPeriod}_${filterDept || 'todos'}`, 'Requisições');
    await logAuditAction(AUDIT_ACTIONS.EXPORTAR_RELATORIO, `Exportação de requisições (${requisicoesData.length} registros)`, user);
  };

  const handleExportEstatisticas = () => {
    const title = ['ESTATÍSTICAS DO SISTEMA'];
    const subtitle = [`Período: ${getPeriodLabel()}  |  Data: ${new Date().toLocaleDateString('pt-BR')}`];
    const empty = [''];
    const secBens = ['BENS PATRIMONIAIS', ''];
    const rowsBens = [
      ['Total de Bens', report.totalBens],
      ['Bens Disponíveis', report.bensDisponiveis],
      ['Bens em Uso', report.bensEmUso],
      ['Bens em Manutenção', report.bensManutencao]
    ];
    const secReqs = ['REQUISIÇÕES', ''];
    const rowsReqs = [
      ['Total de Requisições', report.totalRequisicoes],
      ['Requisições Aprovadas', report.requisicoesAprovadas],
      ['Requisições Pendentes', report.requisicoesPendentes],
      ['Requisições Rejeitadas', report.requisicoesRejeitadas]
    ];
    exportToExcel([title, subtitle, empty, secBens, ...rowsBens, empty, secReqs, ...rowsReqs], `estatisticas_${filterPeriod}_${filterDept || 'todos'}`, 'Estatísticas');
  };

  const handleExportInventario = () => {
    const title = ['INVENTÁRIO COMPLETO POR DEPARTAMENTO'];
    const subtitle = [`UCM-FADIR  |  Data: ${new Date().toLocaleDateString('pt-BR')}`];
    const empty = [''];
    const headers = ['Departamento', 'Código', 'Nome', 'Descrição', 'Marca', 'Modelo', 'Cor', 'Estado', 'Responsável', 'Localização', 'Data Aquisição', 'Ano', 'Valor (MZN)', 'Observações'];
    const rows = [];
    let totalBens = 0;
    Object.entries(report.bensByDept).forEach(([dept, bens]) => {
      bens.forEach(bem => {
        const data = bem.objectData;
        rows.push([
          dept,
          data.codigo,
          data.nome,
          data.descricao || '',
          data.marca || '',
          data.modelo || '',
          data.cor || '',
          data.estadoConservacao === 'bom' ? 'Bom' : data.estadoConservacao === 'razoavel' ? 'Razoável' : 'Avariado',
          data.responsavelAtual || '',
          data.localizacao || '',
          data.dataAquisicao ? new Date(data.dataAquisicao).toLocaleDateString('pt-BR') : '',
          data.dataAquisicao ? new Date(data.dataAquisicao).getFullYear() : '',
          data.preco ? parseFloat(data.preco).toFixed(2) : '',
          ''
        ]);
      });
      totalBens += bens.length;
    });
    const footer = ['', '', '', '', '', '', '', '', '', '', '', `Total: ${totalBens} bens`, '', ''];
    exportToExcel([title, subtitle, empty, headers, ...rows, empty, footer], `inventario_${filterDept || 'todos'}_departamentos`, 'Inventário');
  };

  const handleExportMovimentacoes = async () => {
    try {
      const movResult = await dbListObjects('movimentacao', 100);
      const title = ['RELATÓRIO DE MOVIMENTAÇÕES DE BENS'];
      const subtitle = [`Período: ${getPeriodLabel()}  |  Data: ${new Date().toLocaleDateString('pt-BR')}`];
      const empty = [''];
      const headers = ['Data', 'Bem', 'De (Dept)', 'De (Local)', 'Para (Dept)', 'Para (Local)', 'Responsável', 'Motivo', 'Registrado por'];
      const rows = movResult.items.map(mov => {
        const data = mov.objectData;
        return [
          new Date(data.dataMovimentacao).toLocaleString('pt-BR'),
          data.bemNome,
          data.departamentoOrigem,
          data.localizacaoOrigem,
          data.departamentoDestino,
          data.localizacaoDestino,
          data.novoResponsavel,
          data.motivo || '',
          data.responsavel
        ];
      });
      const footer = ['', '', '', '', '', '', '', `Total: ${movResult.items.length} movimentações`, ''];
      exportToExcel([title, subtitle, empty, headers, ...rows, empty, footer], `movimentacoes_${filterPeriod}`, 'Movimentações');
    } catch (error) {
      console.error('Error exporting movements:', error);
    }
  };

  if (!user || !report) return null;

  const isAdministracao = user.department === 'Administração';
  const canAccessReports = user.role === 'admin' || user.role === 'patrimonio' || isAdministracao;
  if (!canAccessReports) {
    window.location.href = 'dashboard.html';
    return null;
  }

  const getPeriodLabel = () => {
    const labels = {
      dia: 'Hoje',
      semana: 'Esta Semana',
      mes: 'Este Mês',
      semestre: 'Este Semestre',
      ano: 'Este Ano',
      todos: 'Todo Período'
    };
    return labels[filterPeriod] || 'Período Selecionado';
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} currentPage="relatorios" />
      <main className="flex-grow p-4 md:p-6">
        <div className="no-print">
          <button onClick={() => window.location.href = 'dashboard.html'}
            className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar</span>
          </button>
        </div>
        
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 mb-4 md:mb-6">
          <h1 className="text-xl md:text-3xl font-bold">Relatórios</h1>
          <div className="no-print flex gap-2">
            <button onClick={handlePrintReport}
              className="flex items-center gap-1.5 md:gap-2 bg-blue-600 text-white px-3 md:px-4 py-1.5 md:py-2 rounded-lg hover:bg-blue-700 transition text-sm">
              <div className="icon-printer text-base md:text-lg"></div>
              <span>Imprimir</span>
            </button>
          </div>
        </div>
        
        <div className="card mb-4 md:mb-6 no-print">
          <h3 className="font-bold mb-3 md:mb-4 text-sm md:text-base">Filtros</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Período</label>
              <select className="input-field" value={filterPeriod} onChange={(e) => setFilterPeriod(e.target.value)}>
                <option value="dia">Hoje</option>
                <option value="semana">Esta Semana</option>
                <option value="mes">Este Mês</option>
                <option value="semestre">Este Semestre</option>
                <option value="ano">Este Ano</option>
                <option value="todos">Todo Período</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Departamento</label>
              <select className="input-field" value={filterDept} onChange={(e) => setFilterDept(e.target.value)}>
                <option value="">Todos</option>
                <option value="Limpeza">Limpeza</option>
                <option value="Biblioteca">Biblioteca</option>
                <option value="Secretaria">Secretaria</option>
                <option value="Registro Acadêmico">Registro Acadêmico</option>
                <option value="Sala dos Professores">Sala dos Professores</option>
                <option value="Informática">Informática</option>
                <option value="Controle de Crédito">Controle de Crédito</option>
                <option value="Departamento de Patrimônio">Departamento de Patrimônio</option>
                <option value="Administração">Administração</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Requisitante</label>
              <input type="text" className="input-field" placeholder="Nome do requisitante"
                value={filterRequisitante} onChange={(e) => setFilterRequisitante(e.target.value)} />
            </div>
          </div>
        </div>

        <div className="card mb-4 md:mb-6">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 mb-4 md:mb-6">
            <div>
              <h3 className="font-bold text-lg md:text-2xl text-gray-800">Estatísticas Visuais do Patrimônio - {getPeriodLabel()}</h3>
              <p className="text-gray-500 text-xs md:text-sm mt-1">Resumo gráfico do estado dos bens, custos de manutenção e depreciação financeira</p>
            </div>
            <button onClick={handleExportEstatisticas}
              className="no-print flex items-center gap-1.5 md:gap-2 bg-blue-600 text-white px-3 md:px-4 py-1.5 md:py-2 rounded-lg hover:bg-blue-700 transition shadow-md text-sm">
              <div className="icon-download text-base md:text-lg"></div>
              <span>Exportar</span>
            </button>
          </div>
          
          <div className="mb-6">
            <h4 className="font-semibold text-sm md:text-base text-gray-700 mb-3">
              Estado dos Bens Patrimoniais
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
              <StatCard label="Total de Bens" value={report.totalBens} color="blue" icon="package" />
              <StatCard label="Disponíveis" value={report.bensDisponiveis} color="green" icon="check-circle" />
              <StatCard label="Em Uso" value={report.bensEmUso} color="yellow" icon="clock" />
              <StatCard label="Avariados / Manutenção" value={report.bensManutencao} color="red" icon="alert-circle" />
            </div>
          </div>

          {/* PAINEL DE ANÁLISE DE CUSTOS E DEPRECIAÇÃO */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-gray-50 p-4 rounded-xl border">
              <p className="text-xs text-gray-500 font-semibold uppercase">Valor Original Total</p>
              <p className="text-2xl font-bold text-gray-800 mt-1">
                {report.valorOriginalTotal.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MZN
              </p>
              <p className="text-xs text-gray-500 mt-1">Soma do preço de aquisição dos bens</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-xl border">
              <p className="text-xs text-gray-500 font-semibold uppercase">Depreciação Acumulada</p>
              <p className="text-2xl font-bold text-amber-600 mt-1">
                {report.depreciacaoAcumuladaTotal.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MZN
              </p>
              <p className="text-xs text-gray-500 mt-1">Perda de valor estimada (20% ao ano)</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-xl border">
              <p className="text-xs text-gray-500 font-semibold uppercase">Custos de Manutenção</p>
              <p className="text-2xl font-bold text-red-600 mt-1">
                {report.custoManutencaoTotal.toLocaleString('pt-MZ', { minimumFractionDigits: 2 })} MZN
              </p>
              <p className="text-xs text-gray-500 mt-1">Total investido em reparações</p>
            </div>
          </div>

          {/* PAINEL VISUAL COM GRÁFICOS E TOP BENS MAIS AVARIADOS */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Gráfico de Estado do Património */}
            <div className="border rounded-xl p-4 bg-white shadow-sm">
              <h4 className="font-bold text-sm text-gray-700 mb-3">Distribuição do Estado do Patrimônio</h4>
              <ChartEstadoBens report={report} />
            </div>

            {/* Lista dos Bens Mais Avariados */}
            <div className="border rounded-xl p-4 bg-white shadow-sm flex flex-col justify-between">
              <div>
                <h4 className="font-bold text-sm text-gray-700 mb-3">Bens Mais Avariados (Top 5)</h4>
                {report.bensMaisAvariados.length === 0 ? (
                  <p className="text-xs text-gray-500 py-6 text-center">Nenhum registo de avaria encontrado.</p>
                ) : (
                  <div className="space-y-2">
                    {report.bensMaisAvariados.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-center p-2.5 bg-gray-50 rounded-lg border text-xs">
                        <div>
                          <p className="font-bold text-gray-800">{item.nome}</p>
                          <p className="text-gray-500">Cód: {item.codigo} | Depto: {item.departamento}</p>
                        </div>
                        <span className="bg-red-100 text-red-800 font-bold px-2.5 py-1 rounded-full">
                          {item.count} {item.count === 1 ? 'avaria' : 'avarias'}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="mt-4 pt-3 border-t text-xs text-gray-500">
                Identificação rápida de bens críticos com necessidade de substituição ou manutenção preventiva.
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-gray-700 mb-3 flex items-center">
              <div className="icon-file-text text-lg text-purple-600 mr-2"></div>
              Requisições
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatCard label="Total" value={report.totalRequisicoes} color="purple" icon="file-text" />
              <StatCard label="Aprovadas" value={report.requisicoesAprovadas} color="green" icon="check-circle" />
              <StatCard label="Pendentes" value={report.requisicoesPendentes} color="yellow" icon="clock" />
              <StatCard label="Rejeitadas" value={report.requisicoesRejeitadas} color="red" icon="x-circle" />
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 gap-6 mb-6">
          <div className="card shadow-lg">
            <div className="flex justify-between items-center mb-5">
              <div className="flex items-center">
                <div className="icon-building text-2xl text-blue-600 mr-3"></div>
                <div>
                  <h3 className="font-bold text-lg">Inventário Detalhado por Departamento</h3>
                  <p className="text-sm text-gray-500">Bens, responsáveis e estado de conservação</p>
                </div>
              </div>
              <button onClick={handleExportInventario}
                className="no-print flex items-center gap-2 bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 transition shadow-sm">
                <div className="icon-download text-base"></div>
                <span className="text-sm">Exportar Inventário</span>
              </button>
            </div>
            <div className="space-y-4">
              {Object.entries(report.bensByDept).map(([dept, bens]) => (
                <DepartmentInventory key={dept} departamento={dept} bens={bens} />
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 mb-6">
          <div className="card shadow-lg">
            <div className="flex justify-between items-center mb-5">
              <div className="flex items-center">
                <div className="icon-truck text-2xl text-purple-600 mr-3"></div>
                <div>
                  <h3 className="font-bold text-lg">Relatório de Movimentações</h3>
                  <p className="text-sm text-gray-500">Histórico de transferências de bens</p>
                </div>
              </div>
              <button onClick={handleExportMovimentacoes}
                className="no-print flex items-center gap-2 bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 transition shadow-sm">
                <div className="icon-download text-base"></div>
                <span className="text-sm">Exportar</span>
              </button>
            </div>
            <MovimentacoesReport filterPeriod={filterPeriod} />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">

          <div className="card shadow-lg">
            <div className="flex justify-between items-center mb-5">
              <div className="flex items-center">
                <div className="icon-file-text text-2xl text-purple-600 mr-3"></div>
                <div>
                  <h3 className="font-bold text-lg">Requisições do Período</h3>
                  <p className="text-sm text-gray-500">Histórico de solicitações</p>
                </div>
              </div>
              <button onClick={handleExportRequisicoes}
                className="no-print flex items-center gap-2 bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 transition shadow-sm">
                <div className="icon-download text-base"></div>
                <span className="text-sm">Exportar</span>
              </button>
            </div>
            <div className="space-y-2 max-h-96 overflow-y-auto bg-gray-50 rounded-lg p-3">
              {requisicoesData.length === 0 ? (
                <div className="text-center py-12">
                  <div className="icon-inbox text-4xl text-gray-300 mx-auto mb-2 w-fit"></div>
                  <p className="text-gray-500">Nenhuma requisição encontrada</p>
                </div>
              ) : (
                requisicoesData.map(req => (
                  <div key={req.objectId} className="py-3 px-3 bg-white rounded-lg hover:shadow-sm transition">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <p className="font-medium text-gray-800">{req.objectData.solicitante}</p>
                        <p className="text-xs text-gray-500 mt-1">{req.objectData.departamento}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        req.objectData.status === 'aprovada' ? 'bg-blue-50 text-[var(--primary-color)] border border-blue-200' :
                        req.objectData.status === 'pendente' ? 'bg-gray-50 text-gray-700 border border-gray-200' :
                        'bg-gray-200 text-gray-800 border border-gray-300'
                      }`}>
                        {req.objectData.status}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white; }
          .card { box-shadow: none; border: 1px solid #ddd; page-break-inside: avoid; }
        }
      `}</style>
    </div>
  );
}

function ChartEstadoBens({ report }) {
  const canvasRef = React.useRef(null);
  const chartInstanceRef = React.useRef(null);

  React.useEffect(() => {
    if (!canvasRef.current || !window.Chart) return;

    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
    }

    const ctx = canvasRef.current.getContext('2d');
    chartInstanceRef.current = new window.Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Disponíveis', 'Em Uso', 'Avariados / Manutenção'],
        datasets: [{
          data: [
            report.bensDisponiveis || 0,
            report.bensEmUso || 0,
            report.bensManutencao || 0
          ],
          backgroundColor: [
            '#1e40af', // Azul UCM Principal (--primary-color)
            '#3b82f6', // Azul UCM Secundário (--secondary-color)
            '#f59e0b'  // Âmbar / Alerta Manutenção
          ],
          borderColor: '#ffffff',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: { size: 12, family: 'sans-serif' },
              usePointStyle: true,
              padding: 16
            }
          }
        }
      }
    });

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }
    };
  }, [report]);

  return (
    <div className="w-full h-56 flex items-center justify-center">
      <canvas ref={canvasRef} />
    </div>
  );
}

function StatCard({ label, value, color, icon }) {
  const colors = {
    blue: 'bg-blue-50 border-blue-200 text-blue-800',
    green: 'bg-gray-50 border-gray-200 text-gray-800',
    yellow: 'bg-yellow-50 border-yellow-200 text-yellow-800',
    red: 'bg-red-50 border-red-200 text-red-800',
    purple: 'bg-purple-50 border-purple-200 text-purple-800'
  };

  const iconColors = {
    blue: 'text-blue-600',
    green: 'text-green-600',
    yellow: 'text-yellow-600',
    red: 'text-red-600',
    purple: 'text-purple-600'
  };

  return (
    <div className={`p-3 md:p-5 rounded-xl border-2 ${colors[color]} hover:shadow-lg transition-shadow`}>
      {icon && (
        <div className={`icon-${icon} text-xl md:text-2xl ${iconColors[color]} mb-1 md:mb-2`}></div>
      )}
      <p className="text-xs md:text-sm font-medium opacity-80 mb-1">{label}</p>
      <p className="text-2xl md:text-4xl font-bold">{value}</p>
    </div>
  );
}

function ReportCard({ title, data }) {
  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-4">{title}</h2>
      <div className="space-y-3">
        {data.map((item, idx) => (
          <div key={idx} className="flex justify-between items-center py-2 border-b">
            <span className="text-gray-600">{item.label}</span>
            <span className="text-2xl font-bold text-[var(--primary-color)]">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<RelatoriosApp />);

