function DepartamentosApp() {
  const [user, setUser] = React.useState(null);
  const [departamentos, setDepartamentos] = React.useState([]);
  const [filteredDepartamentos, setFilteredDepartamentos] = React.useState([]);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [showModal, setShowModal] = React.useState(false);
  const [editingDept, setEditingDept] = React.useState(null);
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    const isAdministracao = currentUser.department === 'Administração';
    if (currentUser.role !== 'admin' && !isAdministracao) {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadDepartamentos();
  }, []);

  React.useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredDepartamentos(departamentos);
    } else {
      const filtered = departamentos.filter(dept => 
        dept.objectData.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (dept.objectData.descricao && dept.objectData.descricao.toLowerCase().includes(searchTerm.toLowerCase()))
      );
      setFilteredDepartamentos(filtered);
    }
  }, [searchTerm, departamentos]);

  const loadDepartamentos = async () => {
    try {
      setLoading(true);
      const result = await dbListObjects('departamento', 100);
      
      if (result && result.items) {
        const uniqueDepts = [];
        const seenNames = new Set();
        
        for (const dept of result.items) {
          if (dept.objectData && dept.objectData.nome && !seenNames.has(dept.objectData.nome)) {
            seenNames.add(dept.objectData.nome);
            uniqueDepts.push(dept);
          }
        }
        
        setDepartamentos(uniqueDepts);
        setFilteredDepartamentos(uniqueDepts);
      } else {
        setDepartamentos([]);
        setFilteredDepartamentos([]);
      }
    } catch (error) {
      console.error('Error loading departments:', error);
      setDepartamentos([]);
      setFilteredDepartamentos([]);
      
      const errorMsg = error.message || String(error);
      if (errorMsg.includes('Rate limit') || errorMsg.includes('rate limit')) {
        setAlertMessage('Muitas requisições. Aguarde um momento e tente novamente.');
      } else {
        setAlertMessage('Erro ao carregar departamentos');
      }
      setAlertType('error');
      setShowAlert(true);
    } finally {
      setLoading(false);
    }
  };

  const handleAddDepartamento = async (deptData) => {
    await dbCreateObject('departamento', deptData);
    await logAuditAction(AUDIT_ACTIONS.CRIAR_DEPARTAMENTO, `Departamento criado: ${deptData.nome}`, user);
    setAlertMessage('Departamento criado com sucesso!');
    setAlertType('success');
    setShowAlert(true);
    setShowModal(false);
    loadDepartamentos();
  };

  const handleEditDepartamento = async (deptData) => {
    await dbUpdateObject('departamento', editingDept.objectId, deptData);
    await logAuditAction(AUDIT_ACTIONS.EDITAR_DEPARTAMENTO, `Departamento editado: ${deptData.nome}`, user);
    setAlertMessage('Departamento atualizado com sucesso!');
    setAlertType('success');
    setShowAlert(true);
    setShowModal(false);
    setEditingDept(null);
    loadDepartamentos();
  };

  const handleOpenEdit = (dept) => {
    setEditingDept(dept);
    setShowModal(true);
  };

  const handleDeleteDepartamento = async (deptId, deptNome) => {
    if (confirm('Tem certeza que deseja remover este departamento?')) {
      try {
        await dbDeleteObject('departamento', deptId);
        await logAuditAction(AUDIT_ACTIONS.REMOVER_DEPARTAMENTO, `Departamento removido: ${deptNome}`, user);
        setAlertMessage('Departamento removido com sucesso!');
        setAlertType('success');
        setShowAlert(true);
        loadDepartamentos();
      } catch (error) {
        setAlertMessage('Erro ao remover departamento');
        setAlertType('error');
        setShowAlert(true);
      }
    }
  };

  const exportDepartamentos = () => {
    const headers = ['Código', 'Nome', 'Localização', 'Descrição', 'Data de Criação'];
    const rows = departamentos.map(dept => [
      dept.objectData.codigo || 'N/A',
      dept.objectData.nome,
      dept.objectData.localizacao || 'N/A',
      dept.objectData.descricao || 'N/A',
      new Date(dept.createdAt).toLocaleDateString('pt-BR')
    ]);
    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `departamentos_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} currentPage="departamentos" />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      <main className="flex-grow p-6">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="icon-loader-2 animate-spin text-4xl text-[var(--primary-color)] mb-4"></div>
              <p className="text-gray-600">Carregando departamentos...</p>
            </div>
          </div>
        ) : (
          <>
        <div className="mb-6">
          <button 
            onClick={() => window.location.href = 'dashboard.html'}
            className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
          >
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar</span>
          </button>
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold">Gestão de Departamentos</h1>
            <div className="flex gap-3">
              <button onClick={exportDepartamentos} className="btn bg-blue-600 text-white hover:bg-blue-700">
              <div className="flex items-center space-x-2">
                <div className="icon-download text-lg"></div>
                <span>Exportar</span>
              </div>
            </button>
            <button onClick={() => { setEditingDept(null); setShowModal(true); }} className="btn btn-primary">
              Novo Departamento
            </button>
            </div>
          </div>
        </div>
        <div className="mb-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <div className="icon-search text-lg text-gray-400"></div>
            </div>
            <input
              type="text"
              className="input-field pl-10"
              placeholder="Pesquisar departamentos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDepartamentos.length === 0 ? (
            <div className="col-span-full text-center py-8 text-gray-500">
              Nenhum departamento encontrado
            </div>
          ) : (
            filteredDepartamentos.map(dept => (
              <DepartamentoCard 
                key={dept.objectId} 
                departamento={dept.objectData} 
                deptId={dept.objectId}
                onEdit={() => handleOpenEdit(dept)}
                onDelete={(id) => handleDeleteDepartamento(id, dept.objectData.nome)}
              />
            ))
          )}
        </div>
        </>
        )}
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
      {showModal && (
        <DepartamentoModal 
          onClose={() => { setShowModal(false); setEditingDept(null); }} 
          onSave={editingDept ? handleEditDepartamento : handleAddDepartamento}
          initialData={editingDept ? editingDept.objectData : null}
        />
      )}
    </div>
  );
}

function DepartamentoCard({ departamento, deptId, onEdit, onDelete }) {
  const handleCardClick = () => {
    if (departamento.codigo) {
      window.location.href = `departamento-detalhes.html?codigo=${departamento.codigo}`;
    }
  };
  
  return (
    <div className="card hover:shadow-lg transition cursor-pointer" onClick={handleCardClick}>
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
          <div className="icon-building text-xl text-blue-600"></div>
        </div>
        <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={onEdit}
            className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 flex items-center justify-center transition"
            title="Editar departamento"
          >
            <div className="icon-pencil text-sm"></div>
          </button>
          <button
            onClick={() => onDelete(deptId)}
            className="w-8 h-8 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 flex items-center justify-center transition"
            title="Remover departamento"
          >
            <div className="icon-trash-2 text-sm"></div>
          </button>
        </div>
      </div>
      {departamento.codigo && (
        <div className="mb-2">
          <span className="px-2 py-1 bg-blue-50 text-blue-700 text-xs font-mono rounded">
            {departamento.codigo}
          </span>
        </div>
      )}
      <h3 className="font-bold text-lg mb-2">{departamento.nome}</h3>
      {departamento.localizacao && (
        <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
          <div className="icon-map-pin text-base"></div>
          <span>{departamento.localizacao}</span>
        </div>
      )}
      {departamento.descricao && (
        <p className="text-sm text-gray-600 mb-3">{departamento.descricao}</p>
      )}
      <div className="text-xs text-blue-600 font-medium">Clique para ver detalhes →</div>
    </div>
  );
}

function DepartamentoModal({ onClose, onSave, initialData }) {
  const [formData, setFormData] = React.useState(
    initialData || { codigo: '', nome: '', localizacao: '', descricao: '' }
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-2 sm:p-4">
      <div className="bg-white rounded-lg p-3 sm:p-4 md:p-6 w-full max-w-md max-h-[95vh] overflow-y-auto">
        <h2 className="text-lg sm:text-xl md:text-2xl font-bold mb-3 sm:mb-4">
          {initialData ? 'Editar Departamento' : 'Novo Departamento'}
        </h2>
        <form onSubmit={(e) => { e.preventDefault(); onSave(formData); }} className="space-y-3 sm:space-y-4">
          <div>
            <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Código Único *</label>
            <input type="text" className="input-field text-sm sm:text-base px-2 sm:px-4 py-1.5 sm:py-2" value={formData.codigo}
              onChange={(e) => setFormData({...formData, codigo: e.target.value})} 
              placeholder="Ex: DEPT001" required disabled={initialData} />
          </div>
          <div>
            <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Nome *</label>
            <input type="text" className="input-field text-sm sm:text-base px-2 sm:px-4 py-1.5 sm:py-2" value={formData.nome}
              onChange={(e) => setFormData({...formData, nome: e.target.value})} 
              placeholder="Ex: Administração" required />
          </div>
          <div>
            <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Localização *</label>
            <input type="text" className="input-field text-sm sm:text-base px-2 sm:px-4 py-1.5 sm:py-2" value={formData.localizacao}
              onChange={(e) => setFormData({...formData, localizacao: e.target.value})} 
              placeholder="Ex: Edifício A, Sala 101, 1º Piso" required />
          </div>
          <div>
            <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Descrição</label>
            <textarea className="input-field text-sm sm:text-base px-2 sm:px-4 py-1.5 sm:py-2" rows="3" value={formData.descricao}
              onChange={(e) => setFormData({...formData, descricao: e.target.value})} 
              placeholder="Descrição do departamento" />
          </div>
          <div className="flex justify-end space-x-2 sm:space-x-3 mt-4 sm:mt-6">
            <button type="button" onClick={onClose} className="btn bg-gray-200 text-gray-800 hover:bg-gray-300 text-xs sm:text-base px-3 sm:px-4 py-1.5 sm:py-2">Cancelar</button>
            <button type="submit" className="btn btn-primary text-xs sm:text-base px-3 sm:px-4 py-1.5 sm:py-2">
              {initialData ? 'Atualizar' : 'Criar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<DepartamentosApp />);

