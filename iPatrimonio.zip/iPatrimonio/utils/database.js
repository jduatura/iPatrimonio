async function ensureTableExists(tableName, sampleData) {
  try {
    await dbListObjects(tableName, 1);
  } catch (error) {
    console.log(`Table ${tableName} may not exist yet`);
  }
}

async function listBens() {
  try {
    return await dbListObjects('bem', 500, true);
  } catch (error) {
    console.error('Error listing bens:', error);
    throw error;
  }
}

async function listDepartamentos() {
  try {
    return await dbListObjects('departamento', 100, true);
  } catch (error) {
    console.error('Error listing departamentos:', error);
    throw error;
  }
}

async function listDepartamentosUnique() {
  try {
    const result = await dbListObjects('departamento', 100, true);
    if (result && result.items && result.items.length > 0) {
      const uniqueNames = new Set();
      const uniqueDepts = [];
      
      result.items.forEach(dept => {
        if (dept.objectData && dept.objectData.nome) {
          const nomeLower = dept.objectData.nome.toLowerCase().trim();
          if (!uniqueNames.has(nomeLower)) {
            uniqueNames.add(nomeLower);
            uniqueDepts.push(dept);
          }
        }
      });
      
      return {
        items: uniqueDepts.sort((a, b) => 
          a.objectData.nome.localeCompare(b.objectData.nome)
        ),
        nextPageToken: result.nextPageToken
      };
    }
    return result;
  } catch (error) {
    console.error('Error listing unique departamentos:', error);
    throw error;
  }
}

async function listRequisicoes() {
  try {
    return await dbListObjects('requisicao', 500, true);
  } catch (error) {
    console.error('Error listing requisicoes:', error);
    throw error;
  }
}

async function createBem(data) {
  try {
    return await dbCreateObject('bem', {
      codigo: data.codigo,
      nome: data.nome,
      marca: data.marca || '',
      modelo: data.modelo || '',
      numeroSerie: data.numeroSerie || '',
      preco: data.preco,
      descricao: data.descricao || '',
      categoria: data.categoria,
      departamento: data.departamento,
      localizacao: data.localizacao,
      dataAquisicao: data.dataAquisicao,
      fornecedor: data.fornecedor || '',
      status: data.status || 'disponivel',
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error creating bem:', error);
    throw error;
  }
}

async function createRequisicao(data) {
  try {
    if (!data.itensDetalhados || data.itensDetalhados.length === 0) {
      throw new Error('É necessário adicionar pelo menos um item');
    }

    for (const item of data.itensDetalhados) {
      if (!item.descricao || item.descricao.trim() === '') {
        throw new Error('Todos os itens devem ter uma descrição');
      }
      if (item.quantidade && (isNaN(item.quantidade) || Number(item.quantidade) <= 0)) {
        throw new Error('Quantidade deve ser um número maior que zero');
      }
    }

    const requisicao = await dbCreateObject('requisicao', {
      solicitante: data.solicitante,
      beneficiario: data.beneficiario || data.solicitante,
      departamento: data.departamento,
      dataRequisicao: data.dataRequisicao || new Date().toISOString().split('T')[0],
      bens: data.bens,
      motivo: data.motivo || 'Sem motivo especificado',
      itensDetalhados: data.itensDetalhados || [],
      status: data.status || 'pendente',
      createdAt: new Date().toISOString()
    });
    
    return requisicao;
  } catch (error) {
    console.error('Error creating requisicao:', error);
    throw error;
  }
}

async function updateRequisicaoStatus(requisicaoId, status, observacao) {
  try {
    const req = await dbGetObject('requisicao', requisicaoId);
    return await dbUpdateObject('requisicao', requisicaoId, {
      ...req.objectData,
      status: status,
      observacao: observacao,
      updatedAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error updating requisicao status:', error);
    throw error;
  }
}

async function updateBemQuantity(bemCodigo, quantityChange) {
  try {
    const bensResult = await dbListObjects('bem', 500, true);
    const bem = bensResult.items.find(b => b.objectData.codigo === bemCodigo);
    
    if (!bem) {
      throw new Error(`Bem com código ${bemCodigo} não encontrado`);
    }
    
    const currentQuantity = bem.objectData.quantidade || 0;
    const newQuantity = currentQuantity + quantityChange;
    
    if (newQuantity < 0) {
      throw new Error(`Quantidade insuficiente para o bem ${bemCodigo}`);
    }
    
    return await dbUpdateObject('bem', bem.objectId, {
      ...bem.objectData,
      quantidade: newQuantity,
      updatedAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error updating bem quantity:', error);
    throw error;
  }
}
