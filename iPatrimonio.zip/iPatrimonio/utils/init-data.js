async function initializeDefaultDepartments() {
  if (typeof dbListObjects === 'undefined' || typeof dbCreateObject === 'undefined') {
    console.log('Database functions not available yet, skipping department initialization');
    return;
  }

  try {
    const result = await dbListObjects('departamento', 100);
    if (!result || !result.items || typeof result.items === 'string') {
      console.log('Unable to fetch departments, skipping initialization');
      return;
    }
    
    const existingNames = new Set(result.items.map(d => d.objectData.nome));
    
    const defaultDepartments = [
      { codigo: 'DEPT001', nome: 'Limpeza', localizacao: 'Edifício Principal, Térreo', descricao: 'Responsável pela limpeza e manutenção das instalações' },
      { codigo: 'DEPT002', nome: 'Biblioteca', localizacao: 'Edifício B, 1º Piso', descricao: 'Gestão do acervo bibliográfico e atendimento aos estudantes' },
      { codigo: 'DEPT003', nome: 'Secretaria', localizacao: 'Edifício A, Sala 101', descricao: 'Atendimento administrativo e gestão de documentos' },
      { codigo: 'DEPT004', nome: 'Registro Acadêmico', localizacao: 'Edifício A, Sala 102', descricao: 'Gestão de matrículas e históricos escolares' },
      { codigo: 'DEPT005', nome: 'Sala dos Professores', localizacao: 'Edifício A, 2º Piso', descricao: 'Espaço de trabalho e descanso para docentes' },
      { codigo: 'DEPT006', nome: 'Informática', localizacao: 'Edifício C, Sala 201', descricao: 'Suporte técnico e gestão de sistemas' },
      { codigo: 'DEPT007', nome: 'Controle de Crédito', localizacao: 'Edifício A, Sala 103', descricao: 'Gestão financeira e controle de pagamentos' },
      { codigo: 'DEPT008', nome: 'Departamento de Patrimônio', localizacao: 'Edifício A, Sala 104', descricao: 'Gestão e controle do patrimônio institucional' },
      { codigo: 'DEPT009', nome: 'Administração', localizacao: 'Edifício A, Sala 105', descricao: 'Gestão administrativa geral' },
      { codigo: 'DEPT010', nome: 'Diretor', localizacao: 'Edifício A, Sala 201', descricao: 'Direção executiva da instituição' },
      { codigo: 'DEPT011', nome: 'Pedagógico', localizacao: 'Edifício A, 2º Piso', descricao: 'Coordenação pedagógica e apoio acadêmico' },
      { codigo: 'DEPT012', nome: 'Recursos Humanos', localizacao: 'Edifício A, Sala 106', descricao: 'Gestão de pessoal e benefícios' },
      { codigo: 'DEPT013', nome: 'Relações Públicas', localizacao: 'Edifício A, Sala 107', descricao: 'Comunicação institucional e relações externas' },
      { codigo: 'DEPT014', nome: 'Manutenção', localizacao: 'Edifício Técnico, Sala T-01', descricao: 'Equipa técnica de reparação e manutenção preventiva e correctiva' }
    ];
    
    for (const dept of defaultDepartments) {
      if (!existingNames.has(dept.nome)) {
        try {
          await dbCreateObject('departamento', {
            codigo: dept.codigo,
            nome: dept.nome,
            localizacao: dept.localizacao,
            descricao: dept.descricao,
            ativo: true
          });
          console.log(`Department ${dept.nome} created`);
        } catch (error) {
          console.log(`Could not create department ${dept.nome}`);
        }
      }
    }
  } catch (error) {
    console.log('Department initialization skipped');
  }
}

async function initializeDefaultUsers() {
  if (typeof dbListObjects === 'undefined' || typeof dbCreateObject === 'undefined') {
    console.log('Database functions not available yet, skipping user initialization');
    return;
  }

  try {
    const result = await dbListObjects('usuario', 100);
    if (!result || !result.items || typeof result.items === 'string') {
      console.log('Unable to fetch users, skipping initialization');
      return;
    }
    
    const existingUsernames = new Set(result.items.map(u => u.objectData.username));
    
    // 1. Administrador Padrão
    if (!existingUsernames.has('admin@ucm.ac.mz')) {
      try {
        await dbCreateObject('usuario', {
          name: 'Administrador UCM',
          username: 'admin@ucm.ac.mz',
          numeroElemento: '000001',
          password: 'iPatrimonio2025!',
          role: 'admin',
          department: 'Administração',
          ativo: true
        });
        console.log('Default admin user created successfully');
      } catch (e) {}
    }

    // 2. Remoção Cirúrgica de Usuários Antigos
    const usersToRemove = ['tecnico@ucm.ac.mz', 'patrimonio@ucm.ac.mz'];
    for (const user of result.items) {
      if (usersToRemove.includes(user.objectData.username)) {
        try {
          if (typeof dbDeleteObject !== 'undefined') {
            await dbDeleteObject('usuario', user.objectId);
            console.log(`Removed legacy user: ${user.objectData.username}`);
          }
        } catch(e) {}
      }
    }
    
    // Apenas o Administrador Padrão é mantido
  } catch (error) {
    console.log('User initialization skipped');
  }
}
