async function logAuditAction(actionType, details, user) {
  try {
    await dbCreateObject('log_auditoria', {
      usuario: user.name,
      usuarioId: user.id,
      departamento: user.department,
      tipoAcao: actionType,
      detalhes: details,
      timestamp: new Date().toISOString(),
      ipAddress: 'N/A'
    });
  } catch (error) {
    console.error('Error creating audit log (non-critical):', error);
  }
}

const AUDIT_ACTIONS = {
  LOGIN: 'login',
  LOGOUT: 'logout',
  CRIAR_BEM: 'criar_bem',
  EDITAR_BEM: 'editar_bem',
  EXCLUIR_BEM: 'excluir_bem',
  CRIAR_REQUISICAO: 'criar_requisicao',
  APROVAR_REQUISICAO: 'aprovar_requisicao',
  REJEITAR_REQUISICAO: 'rejeitar_requisicao',
  CRIAR_USUARIO: 'criar_usuario',
  EDITAR_USUARIO: 'editar_usuario',
  DESATIVAR_USUARIO: 'desativar_usuario',
  ATIVAR_USUARIO: 'ativar_usuario',
  REMOVER_USUARIO: 'remover_usuario',
  ALTERAR_SENHA: 'alterar_senha',
  EXPORTAR_RELATORIO: 'exportar_relatorio',
  CRIAR_MOVIMENTACAO: 'criar_movimentacao',
  CRIAR_DEPARTAMENTO: 'criar_departamento',
  REMOVER_DEPARTAMENTO: 'remover_departamento',
  CRIAR_BACKUP: 'criar_backup',
  RESTAURAR_BACKUP: 'restaurar_backup',
  ATIVAR_BACKUP_AUTO: 'ativar_backup_auto',
  DESATIVAR_BACKUP_AUTO: 'desativar_backup_auto',
  SOLICITAR_MANUTENCAO: 'solicitar_manutencao',
  ATRIBUIR_MANUTENCAO: 'atribuir_manutencao',
  SUBMETER_ORCAMENTO_MANUTENCAO: 'submeter_orcamento_manutencao',
  ENCAMINHAR_MANUTENCAO_ADMIN: 'encaminhar_manutencao_admin',
  APROVAR_ORCAMENTO_MANUTENCAO: 'aprovar_orcamento_manutencao',
  REPROVAR_ORCAMENTO_MANUTENCAO: 'reprovar_orcamento_manutencao',
  CONCLUIR_MANUTENCAO: 'concluir_manutencao',
  AGENDAR_MANUTENCAO_PREVENTIVA: 'agendar_manutencao_preventiva'
};
