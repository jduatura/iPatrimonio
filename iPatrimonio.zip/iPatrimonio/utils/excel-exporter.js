// Utilitário para exportação Excel com formatação elegante
const ExcelExporter = {
  // Criar workbook com estilo
  createWorkbook: function() {
    return XLSX.utils.book_new();
  },

  // Adicionar worksheet com formatação
  addWorksheet: function(workbook, data, sheetName, options = {}) {
    const ws = XLSX.utils.aoa_to_sheet(data);
    
    // Aplicar larguras de coluna automáticas
    const colWidths = this.calculateColumnWidths(data);
    ws['!cols'] = colWidths;
    
    // Aplicar altura de linhas
    if (options.rowHeights) {
      ws['!rows'] = options.rowHeights;
    }
    
    XLSX.utils.book_append_sheet(workbook, ws, sheetName);
    return ws;
  },

  // Calcular larguras ideais das colunas
  calculateColumnWidths: function(data) {
    if (!data || data.length === 0) return [];
    
    const maxWidths = data[0].map((_, colIndex) => {
      const columnData = data.map(row => String(row[colIndex] || ''));
      const maxLength = Math.max(...columnData.map(cell => cell.length));
      return { wch: Math.min(Math.max(maxLength + 2, 10), 50) };
    });
    
    return maxWidths;
  },

  // Exportar para arquivo
  export: function(workbook, filename) {
    XLSX.writeFile(workbook, filename);
  },

  // Função simplificada para exportação rápida
  exportData: function(data, filename, sheetName = 'Dados') {
    const wb = this.createWorkbook();
    this.addWorksheet(wb, data, sheetName);
    this.export(wb, filename);
  }
};