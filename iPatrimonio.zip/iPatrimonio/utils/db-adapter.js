/**
 * iPatrimônio Database Adapter
 * Suporta execução local (LocalStorage) e migração para Supabase.
 * Fornece compatibilidade total com as funções globais legadas.
 */

(function() {
  // Prefixo para chaves locais
  const LOCAL_PREFIX = 'ipatrimonio_';
  const LEGACY_PREFIX = 'legacy_';

  // Configuração padrão
  const DEFAULT_CONFIG = {
    provider: 'local', // 'local' | 'supabase'
    supabase: {
      url: '',
      anonKey: '',
      enabled: false
    }
  };

  // Carrega configuração persistida (se houver)
  function loadConfig() {
    try {
      const saved = localStorage.getItem('ipatrimonio_db_config');
      if (saved) {
        return { ...DEFAULT_CONFIG, ...JSON.parse(saved) };
      }
    } catch (e) {
      console.warn('Erro ao carregar configuração do banco:', e);
    }
    return DEFAULT_CONFIG;
  }

  const config = loadConfig();
  window.DB_CONFIG = config;

  // Função para salvar nova configuração (ex: quando configurar o Supabase)
  window.saveDbConfig = function(newConfig) {
    try {
      const merged = { ...window.DB_CONFIG, ...newConfig };
      localStorage.setItem('ipatrimonio_db_config', JSON.stringify(merged));
      window.DB_CONFIG = merged;
      console.log('Configuração do banco de dados atualizada:', merged);
      return true;
    } catch (e) {
      console.error('Erro ao salvar configuração do banco:', e);
      return false;
    }
  };

  // ==========================================================
  // 1. ADAPTER LOCAL (LocalStorage)
  // ==========================================================
  const LocalAdapter = {
    // Obter todos os objetos de um tipo no LocalStorage
    getObjectsByType(objectType) {
      const objects = [];
      const seenIds = new Set();

      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        const isCurrent = key.startsWith(LOCAL_PREFIX + objectType + '_');
        const isLegacy = key.startsWith(LEGACY_PREFIX + objectType + '_');

        if (isCurrent || isLegacy) {
          try {
            const data = JSON.parse(localStorage.getItem(key));
            if (data && data.objectId && !seenIds.has(data.objectId)) {
              seenIds.add(data.objectId);
              objects.push(data);
            }
          } catch (e) {
            console.error('Erro ao ler objeto local:', key, e);
          }
        }
      }
      return objects;
    },

    async create(objectType, objectData) {
      const objectId = Date.now().toString() + Math.random().toString(36).substr(2, 9);
      const timestamp = new Date().toISOString();

      const record = {
        objectId: objectId,
        objectType: objectType,
        objectData: objectData,
        createdAt: timestamp,
        updatedAt: timestamp
      };

      const key = LOCAL_PREFIX + objectType + '_' + objectId;
      try {
        localStorage.setItem(key, JSON.stringify(record));
      } catch (quotaError) {
        if (quotaError.name === 'QuotaExceededError') {
          console.warn('Cota de armazenamento atingida. Limpando dados antigos...');
          window.clearOldestObjects(objectType, 30);
          localStorage.setItem(key, JSON.stringify(record));
        } else {
          throw quotaError;
        }
      }

      await new Promise(resolve => setTimeout(resolve, 30));
      return record;
    },

    async update(objectType, objectId, objectData) {
      const currentKey = LOCAL_PREFIX + objectType + '_' + objectId;
      const legacyKey = LEGACY_PREFIX + objectType + '_' + objectId;

      let existingData = localStorage.getItem(currentKey) || localStorage.getItem(legacyKey);
      if (!existingData) {
        throw new Error(`Objeto ${objectType} (${objectId}) não encontrado.`);
      }

      const existing = JSON.parse(existingData);
      const updated = {
        ...existing,
        objectData: { ...existing.objectData, ...objectData },
        updatedAt: new Date().toISOString()
      };

      localStorage.setItem(currentKey, JSON.stringify(updated));
      if (localStorage.getItem(legacyKey)) {
        localStorage.removeItem(legacyKey);
      }

      await new Promise(resolve => setTimeout(resolve, 30));
      return updated;
    },

    async get(objectType, objectId) {
      const currentKey = LOCAL_PREFIX + objectType + '_' + objectId;
      const legacyKey = LEGACY_PREFIX + objectType + '_' + objectId;

      const data = localStorage.getItem(currentKey) || localStorage.getItem(legacyKey);
      if (!data) {
        throw new Error(`Objeto ${objectType} (${objectId}) não encontrado.`);
      }
      return JSON.parse(data);
    },

    async list(objectType, limit = 100, descent = true) {
      const objects = this.getObjectsByType(objectType);

      objects.sort((a, b) => {
        const timeA = new Date(a.createdAt || 0).getTime();
        const timeB = new Date(b.createdAt || 0).getTime();
        return descent ? (timeB - timeA) : (timeA - timeB);
      });

      const items = objects.slice(0, limit);
      await new Promise(resolve => setTimeout(resolve, 20));
      return {
        items: items,
        nextPageToken: null
      };
    },

    async delete(objectType, objectId) {
      const currentKey = LOCAL_PREFIX + objectType + '_' + objectId;
      const legacyKey = LEGACY_PREFIX + objectType + '_' + objectId;
      localStorage.removeItem(currentKey);
      localStorage.removeItem(legacyKey);
    }
  };

  // ==========================================================
  // 2. ADAPTER SUPABASE (Pronto para migração futura)
  // ==========================================================
  const SupabaseAdapter = {
    getHeaders() {
      const cfg = window.DB_CONFIG.supabase;
      return {
        'apikey': cfg.anonKey,
        'Authorization': `Bearer ${cfg.anonKey}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation'
      };
    },

    getBaseUrl() {
      const url = window.DB_CONFIG.supabase.url.replace(/\/$/, '');
      return `${url}/rest/v1`;
    },

    formatRecord(row, objectType) {
      if (!row) return null;
      return {
        objectId: row.id || row.objectId,
        objectType: objectType,
        objectData: row.object_data || row.objectData || row,
        createdAt: row.created_at || row.createdAt || new Date().toISOString(),
        updatedAt: row.updated_at || row.updatedAt || new Date().toISOString()
      };
    },

    async create(objectType, objectData) {
      const objectId = Date.now().toString() + Math.random().toString(36).substr(2, 9);
      const timestamp = new Date().toISOString();
      const payload = {
        id: objectId,
        object_data: objectData,
        created_at: timestamp,
        updated_at: timestamp
      };

      const res = await fetch(`${this.getBaseUrl()}/${objectType}`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Erro Supabase ao criar ${objectType}: ${errorText}`);
      }

      const rows = await res.json();
      return this.formatRecord(rows[0] || payload, objectType);
    },

    async update(objectType, objectId, objectData) {
      const current = await this.get(objectType, objectId);
      const merged = { ...current.objectData, ...objectData };
      const timestamp = new Date().toISOString();

      const res = await fetch(`${this.getBaseUrl()}/${objectType}?id=eq.${objectId}`, {
        method: 'PATCH',
        headers: this.getHeaders(),
        body: JSON.stringify({
          object_data: merged,
          updated_at: timestamp
        })
      });

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Erro Supabase ao atualizar ${objectType}: ${errorText}`);
      }

      const rows = await res.json();
      return this.formatRecord(rows[0] || { id: objectId, object_data: merged, updated_at: timestamp }, objectType);
    },

    async get(objectType, objectId) {
      const res = await fetch(`${this.getBaseUrl()}/${objectType}?id=eq.${objectId}&select=*`, {
        method: 'GET',
        headers: this.getHeaders()
      });

      if (!res.ok) {
        throw new Error(`Objeto ${objectType} (${objectId}) não encontrado no Supabase.`);
      }

      const rows = await res.json();
      if (!rows || rows.length === 0) {
        throw new Error(`Objeto ${objectType} (${objectId}) não encontrado.`);
      }
      return this.formatRecord(rows[0], objectType);
    },

    async list(objectType, limit = 100, descent = true) {
      const order = descent ? 'created_at.desc' : 'created_at.asc';
      const res = await fetch(`${this.getBaseUrl()}/${objectType}?select=*&limit=${limit}&order=${order}`, {
        method: 'GET',
        headers: this.getHeaders()
      });

      if (!res.ok) {
        console.error(`Erro Supabase ao listar ${objectType}:`, await res.text());
        return { items: [], nextPageToken: null };
      }

      const rows = await res.json();
      return {
        items: (rows || []).map(r => this.formatRecord(r, objectType)),
        nextPageToken: null
      };
    },

    async delete(objectType, objectId) {
      const res = await fetch(`${this.getBaseUrl()}/${objectType}?id=eq.${objectId}`, {
        method: 'DELETE',
        headers: this.getHeaders()
      });

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Erro Supabase ao excluir ${objectType}: ${errorText}`);
      }
    }
  };

  // ==========================================================
  // 3. ROTEADOR DE PROVIDER
  // ==========================================================
  function getActiveAdapter() {
    if (window.DB_CONFIG?.provider === 'supabase' && window.DB_CONFIG?.supabase?.enabled && window.DB_CONFIG?.supabase?.url) {
      return SupabaseAdapter;
    }
    return LocalAdapter;
  }

  // Interface Unificada
  const DB = {
    create: (type, data) => getActiveAdapter().create(type, data),
    update: (type, id, data) => getActiveAdapter().update(type, id, data),
    get: (type, id) => getActiveAdapter().get(type, id),
    list: (type, limit, descent) => getActiveAdapter().list(type, limit, descent),
    delete: (type, id) => getActiveAdapter().delete(type, id),
    getProviderName: () => (getActiveAdapter() === SupabaseAdapter ? 'supabase' : 'local')
  };

  // ==========================================================
  // 4. EXPOSIÇÃO GLOBAL E COMPATIBILIDADE TOTAL COM CÓDIGOS EXISTENTES
  // ==========================================================
  window.db = DB;
  window.ipatrimonioDB = DB;

  // Aliases compatíveis com o código existente em todos os componentes
  window.dbCreateObject = (type, data) => DB.create(type, data);
  window.dbUpdateObject = (type, id, data) => DB.update(type, id, data);
  window.dbGetObject = (type, id) => DB.get(type, id);
  window.dbListObjects = (type, limit, descent, token) => DB.list(type, limit, descent);
  window.dbDeleteObject = (type, id) => DB.delete(type, id);

  // Utilitários de gerenciamento de armazenamento
  window.getStorageSize = () => {
    let total = 0;
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        total += localStorage[key].length + key.length;
      }
    }
    return total;
  };

  window.clearOldestObjects = (objectType, keepCount = 50) => {
    const keys = [];
    for (let key in localStorage) {
      if (key.startsWith(`${LOCAL_PREFIX}${objectType}_`) || key.startsWith(`${LEGACY_PREFIX}${objectType}_`)) {
        keys.push(key);
      }
    }
    if (keys.length <= keepCount) return 0;
    keys.sort();
    const toRemove = keys.slice(0, keys.length - keepCount);
    toRemove.forEach(key => localStorage.removeItem(key));
    return toRemove.length;
  };

  console.log(`✓ iPatrimônio Database Adapter ativo [Provider: ${DB.getProviderName()}]`);
})();