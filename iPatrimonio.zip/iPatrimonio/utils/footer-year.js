// Utilitário para atualizar automaticamente o ano no rodapé
// Deve ser incluído em todas as páginas que possuem rodapé

function updateFooterYear() {
    const yearElement = document.getElementById('year');
    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }
}

// Executar quando o DOM estiver pronto
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', updateFooterYear);
} else {
    updateFooterYear();
}

// Também executar após um pequeno delay para React apps
setTimeout(updateFooterYear, 100);
