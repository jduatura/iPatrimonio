async function login(username, password) {
  try {
    const result = await dbListObjects('usuario', 100);
    
    if (!result || !result.items) {
      return { success: false, message: 'Erro ao buscar usuários. Tente novamente.' };
    }
    
    const user = result.items.find(u => 
      u.objectData.username === username && u.objectData.password === password
    );
    
    if (user) {
      if (user.objectData.ativo === false) {
        return { success: false, message: 'Usuário desativado. Entre em contato com o administrador.' };
      }

      const userData = {
        id: user.objectId,
        name: user.objectData.name,
        username: user.objectData.username,
        role: user.objectData.role,
        department: user.objectData.department
      };
      localStorage.setItem('currentUser', JSON.stringify(userData));
      
      try {
        await logAuditAction(AUDIT_ACTIONS.LOGIN, `Login realizado com sucesso`, userData);
      } catch (logError) {
        console.error('Error creating audit log (non-critical):', logError);
      }
      
      return { success: true, user: userData };
    }
    return { success: false, message: 'Usuário ou senha incorretos' };
  } catch (error) {
    console.error('Login error:', error);
    return { success: false, message: 'Erro ao processar login. Verifique se os dados iniciais foram criados.' };
  }
}

function canManageUsers(user) {
  return user && (user.role === 'admin' || user.department === 'Administração');
}

function canManageDepartments(user) {
  return user && (user.role === 'admin' || user.department === 'Administração');
}

async function logout() {
  const currentUser = getCurrentUser();
  if (currentUser) {
    try {
      await logAuditAction(AUDIT_ACTIONS.LOGOUT, `Logout do sistema`, currentUser);
    } catch (error) {
      console.error('Error creating audit log (non-critical):', error);
    }
  }
  localStorage.removeItem('currentUser');
  window.location.href = 'login.html';
}

function getCurrentUser() {
  const userData = localStorage.getItem('currentUser');
  return userData ? JSON.parse(userData) : null;
}