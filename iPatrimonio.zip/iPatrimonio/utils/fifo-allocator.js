// FIFO (First In, First Out) allocator for automatic asset assignment

async function allocateBensToRequisicao(requisicaoId, itensDetalhados, emailSolicitante, departamento) {
  const bensAtribuidos = [];
  const itensPendentes = [];

  for (const item of itensDetalhados) {
    const quantidade = parseInt(item.quantidade) || 1;
    const descricao = item.descricao.toLowerCase().trim();

    console.log(`🔍 Procurando ${quantidade} unidade(s) de "${item.descricao}" no departamento "${departamento}"`);

    // PASSO 1: Percorrer e encontrar bens livres
    let result;
    try {
      result = await dbListObjects('bem', 1000, false);
    } catch (error) {
      console.error('❌ Erro ao listar bens:', error);
      await new Promise(resolve => setTimeout(resolve, 1000));
      continue;
    }
    
    // Filtrar bens disponíveis que correspondem ao material requisitado
    const bensDisponiveis = result.items
      .filter(b => {
        const nomeMatch = b.objectData.nome.toLowerCase().includes(descricao);
        const statusDisponivel = b.objectData.status === 'disponivel';
        const deptMatch = b.objectData.departamento === departamento;
        
        return nomeMatch && statusDisponivel && deptMatch;
      })
      .sort((a, b) => {
        // FIFO: Ordenar por data de criação (mais antigo primeiro)
        const timeA = new Date(a.createdAt).getTime();
        const timeB = new Date(b.createdAt).getTime();
        return timeA - timeB;
      });

    const quantidadeDisponivel = bensDisponiveis.length;
    console.log(`📦 Encontrado: ${quantidadeDisponivel} bem(ns) disponível(eis)`);

    // PASSO 2: Validar se encontrou bens suficientes
    if (quantidadeDisponivel >= quantidade) {
      // Caso: Stock suficiente - alocar todos os bens necessários
      console.log(`✅ Stock suficiente! Alocando ${quantidade} bem(ns)...`);
      
      for (let i = 0; i < quantidade; i++) {
        const bem = bensDisponiveis[i];
        try {
          // PASSO 3: Bloquear bem e registrar responsável
          await dbUpdateObject('bem', bem.objectId, {
            ...bem.objectData,
            status: 'em_uso',
            usuarioAtual: emailSolicitante,
            responsavelAtual: emailSolicitante,
            dataAtribuicao: new Date().toISOString(),
            requisicaoId: requisicaoId
          });
          
          bensAtribuidos.push({
            itemId: bem.objectId,
            codigo: bem.objectData.codigo,
            nome: bem.objectData.nome
          });
          
          console.log(`✓ Bem ${bem.objectData.codigo} (${bem.objectData.nome}) alocado para ${emailSolicitante}`);
          await new Promise(resolve => setTimeout(resolve, 200));
        } catch (error) {
          console.error('❌ Erro ao atualizar bem:', error);
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
    } else if (quantidadeDisponivel > 0) {
      // Caso: Stock parcial - alocar o que tem e marcar resto como pendente
      console.log(`⚠️ Stock parcial: ${quantidadeDisponivel} de ${quantidade}. Alocando disponíveis...`);
      
      for (let i = 0; i < quantidadeDisponivel; i++) {
        const bem = bensDisponiveis[i];
        try {
          await dbUpdateObject('bem', bem.objectId, {
            ...bem.objectData,
            status: 'em_uso',
            usuarioAtual: emailSolicitante,
            responsavelAtual: emailSolicitante,
            dataAtribuicao: new Date().toISOString(),
            requisicaoId: requisicaoId
          });
          
          bensAtribuidos.push({
            itemId: bem.objectId,
            codigo: bem.objectData.codigo,
            nome: bem.objectData.nome
          });
          
          console.log(`✓ Bem ${bem.objectData.codigo} alocado para ${emailSolicitante}`);
          await new Promise(resolve => setTimeout(resolve, 200));
        } catch (error) {
          console.error('❌ Erro ao atualizar bem:', error);
        }
      }
      
      // Criar requisição pendente para quantidade restante
      const quantidadePendente = quantidade - quantidadeDisponivel;
      try {
        await dbCreateObject('requisicao_pendente', {
          descricaoBem: item.descricao,
          quantidade: quantidadePendente,
          solicitante: item.solicitante || '',
          emailSolicitante: emailSolicitante,
          departamento: departamento,
          dataSolicitacao: new Date().toISOString(),
          requisicaoId: requisicaoId,
          status: 'aguardando'
        });
        itensPendentes.push(`${item.descricao} (${quantidadePendente} pendente)`);
        console.log(`⏳ ${quantidadePendente} unidade(s) marcada(s) como pendente por falta de stock`);
      } catch (error) {
        console.error('❌ Erro ao criar requisição pendente:', error);
      }
    } else {
      // Caso: Sem stock - marcar todo o pedido como pendente
      console.log(`❌ Sem stock disponível. Marcando ${quantidade} unidade(s) como pendente...`);
      
      try {
        await dbCreateObject('requisicao_pendente', {
          descricaoBem: item.descricao,
          quantidade: quantidade,
          solicitante: item.solicitante || '',
          emailSolicitante: emailSolicitante,
          departamento: departamento,
          dataSolicitacao: new Date().toISOString(),
          requisicaoId: requisicaoId,
          status: 'aguardando'
        });
        itensPendentes.push(item.descricao);
        console.log(`⏳ ${quantidade} unidade(s) de ${item.descricao} marcada(s) como pendente por falta de stock`);
      } catch (error) {
        console.error('❌ Erro ao criar requisição pendente:', error);
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
  }

  console.log(`\n📊 Resumo da Alocação:`);
  console.log(`✅ Bens alocados: ${bensAtribuidos.length}`);
  console.log(`⏳ Itens pendentes: ${itensPendentes.length}`);

  return { bensAtribuidos, itensPendentes };
}

async function processPendingRequests(bemNome, departamento) {
  console.log(`\n🔄 Processando requisições pendentes para "${bemNome}" no departamento "${departamento}"`);
  
  try {
    // Buscar requisições pendentes
    let result;
    try {
      result = await dbListObjects('requisicao_pendente', 500, false);
    } catch (error) {
      console.error('❌ Erro ao listar requisições pendentes:', error);
      return;
    }
    
    // Filtrar requisições pendentes deste material e departamento
    const pendentes = result.items.filter(p => 
      p.objectData.descricaoBem.toLowerCase().includes(bemNome.toLowerCase()) &&
      p.objectData.departamento === departamento &&
      p.objectData.status === 'aguardando'
    ).sort((a, b) => {
      // Processar pedidos mais antigos primeiro (FIFO)
      const timeA = new Date(a.objectData.dataSolicitacao).getTime();
      const timeB = new Date(b.objectData.dataSolicitacao).getTime();
      return timeA - timeB;
    });

    if (pendentes.length === 0) {
      console.log('ℹ️ Nenhuma requisição pendente encontrada');
      return;
    }

    console.log(`📋 ${pendentes.length} requisição(ões) pendente(s) encontrada(s)`);

    // Buscar bens disponíveis usando FIFO
    let bensResult;
    try {
      bensResult = await dbListObjects('bem', 1000, false);
    } catch (error) {
      console.error('❌ Erro ao listar bens:', error);
      return;
    }
    
    const bensDisponiveis = bensResult.items
      .filter(b => 
        b.objectData.nome.toLowerCase().includes(bemNome.toLowerCase()) &&
        b.objectData.status === 'disponivel' &&
        b.objectData.departamento === departamento
      )
      .sort((a, b) => {
        // FIFO: Itens mais antigos primeiro
        const timeA = new Date(a.createdAt).getTime();
        const timeB = new Date(b.createdAt).getTime();
        return timeA - timeB;
      });

    if (bensDisponiveis.length === 0) {
      console.log('❌ Nenhum bem disponível para processar');
      return;
    }

    console.log(`📦 ${bensDisponiveis.length} bem(ns) disponível(eis) para alocar`);

    let bensAllocated = 0;

    // Processar cada requisição pendente em ordem FIFO
    for (const pendente of pendentes) {
      const quantidadeNecessaria = parseInt(pendente.objectData.quantidade) || 1;
      const bensParaAlocar = bensDisponiveis.slice(bensAllocated, bensAllocated + quantidadeNecessaria);

      console.log(`\n🔍 Processando requisição de ${pendente.objectData.emailSolicitante} (${quantidadeNecessaria} unidade(s))`);

      if (bensParaAlocar.length >= quantidadeNecessaria) {
        // Stock suficiente - alocar todos os bens
        console.log(`✅ Stock suficiente! Alocando ${quantidadeNecessaria} bem(ns)...`);
        
        for (const bem of bensParaAlocar) {
          try {
            await dbUpdateObject('bem', bem.objectId, {
              ...bem.objectData,
              status: 'em_uso',
              usuarioAtual: pendente.objectData.emailSolicitante,
              responsavelAtual: pendente.objectData.emailSolicitante,
              dataAtribuicao: new Date().toISOString(),
              requisicaoId: pendente.objectData.requisicaoId
            });
            console.log(`✓ Bem ${bem.objectData.codigo} alocado para ${pendente.objectData.emailSolicitante}`);
            await new Promise(resolve => setTimeout(resolve, 200));
          } catch (error) {
            console.error('❌ Erro ao alocar bem:', error);
            continue;
          }
        }

        // Marcar requisição pendente como processada
        try {
          await dbUpdateObject('requisicao_pendente', pendente.objectId, {
            ...pendente.objectData,
            status: 'processado',
            dataProcessamento: new Date().toISOString()
          });
          console.log(`✅ Requisição pendente completamente atendida`);
        } catch (error) {
          console.error('❌ Erro ao atualizar requisição pendente:', error);
        }

        bensAllocated += quantidadeNecessaria;
      } else if (bensParaAlocar.length > 0) {
        // Atendimento parcial
        console.log(`⚠️ Atendimento parcial: ${bensParaAlocar.length} de ${quantidadeNecessaria}`);
        
        for (const bem of bensParaAlocar) {
          try {
            await dbUpdateObject('bem', bem.objectId, {
              ...bem.objectData,
              status: 'em_uso',
              usuarioAtual: pendente.objectData.emailSolicitante,
              responsavelAtual: pendente.objectData.emailSolicitante,
              dataAtribuicao: new Date().toISOString(),
              requisicaoId: pendente.objectData.requisicaoId
            });
            console.log(`✓ Bem ${bem.objectData.codigo} alocado`);
            await new Promise(resolve => setTimeout(resolve, 200));
          } catch (error) {
            console.error('❌ Erro ao alocar bem:', error);
          }
        }
        
        // Atualizar requisição pendente com quantidade reduzida
        const quantidadeRestante = quantidadeNecessaria - bensParaAlocar.length;
        try {
          await dbUpdateObject('requisicao_pendente', pendente.objectId, {
            ...pendente.objectData,
            quantidade: quantidadeRestante
          });
          console.log(`⏳ ${quantidadeRestante} unidade(s) ainda pendente(s)`);
        } catch (error) {
          console.error('❌ Erro ao atualizar requisição pendente:', error);
        }

        bensAllocated += bensParaAlocar.length;
      }

      if (bensAllocated >= bensDisponiveis.length) {
        console.log('ℹ️ Todos os bens disponíveis foram alocados');
        break;
      }
    }
    
    console.log(`\n✅ Processamento concluído: ${bensAllocated} bem(ns) alocado(s)`);
  } catch (error) {
    console.error('❌ Erro ao processar requisições pendentes:', error);
  }
}
