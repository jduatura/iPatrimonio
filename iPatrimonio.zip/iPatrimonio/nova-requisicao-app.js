function NovaRequisicaoApp() {
  const [user, setUser] = React.useState(null);
  const [formData, setFormData] = React.useState({
    sector: '',
    beneficiario: '',
    dataRequisicao: new Date().toISOString().split('T')[0],
    pedido: '',
    itens: [{ descricao: '', quantidade: '', observacao: '' }]
  });
  const [errors, setErrors] = React.useState({});
  
  const [departamentos, setDepartamentos] = React.useState([]);
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    setUser(currentUser);
    setFormData(prev => ({
      ...prev, 
      sector: currentUser.department,
      beneficiario: currentUser.name
    }));
    
    loadDepartamentos();
  }, []);

  const loadDepartamentos = async () => {
    try {
      const result = await dbListObjects('departamento', 100, true);
      if (result && result.items && result.items.length > 0) {
        const deptNames = result.items
          .filter(dept => dept.objectData && dept.objectData.nome)
          .map(dept => dept.objectData.nome)
          .sort();
        setDepartamentos(deptNames);
      }
    } catch (error) {
      console.error('Error loading departments:', error);
    }
  };

  const handleAddItem = () => {
    setFormData({
      ...formData,
      itens: [...formData.itens, { descricao: '', quantidade: '', observacao: '' }]
    });
  };

  const handleRemoveItem = (index) => {
    const newItens = formData.itens.filter((_, i) => i !== index);
    setFormData({ ...formData, itens: newItens });
  };

  const handleItemChange = (index, field, value) => {
    const newItens = [...formData.itens];
    newItens[index][field] = value;
    setFormData({ ...formData, itens: newItens });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.sector || !formData.sector.trim()) {
      newErrors.sector = 'Departamento é obrigatório';
    }

    if (!formData.beneficiario || !formData.beneficiario.trim()) {
      newErrors.beneficiario = 'Beneficiário é obrigatório';
    }

    if (!formData.dataRequisicao) {
      newErrors.dataRequisicao = 'Data é obrigatória';
    }

    const validItems = formData.itens.filter(item => item.descricao && item.descricao.trim());
    if (validItems.length === 0) {
      newErrors.itens = 'Adicione pelo menos um item à requisição';
    }

    formData.itens.forEach((item, index) => {
      if (item.descricao && item.descricao.trim()) {
        if (!item.quantidade || isNaN(item.quantidade) || Number(item.quantidade) <= 0) {
          newErrors[`item_${index}_quantidade`] = 'Quantidade é obrigatória e deve ser maior que zero';
        }
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      setAlertMessage('Por favor, corrija os erros no formulário');
      setAlertType('error');
      setShowAlert(true);
      return;
    }

    const validItems = formData.itens.filter(item => item.descricao.trim());
    
    try {
      const bensResult = await dbListObjects('bem', 500, true);
      const allBens = bensResult.items;
      
      const itensComCodigo = validItems.map(item => {
        const descricaoItem = item.descricao.toLowerCase().trim();
        
        const bemEncontrado = allBens.find(b => 
          b.objectData.descricao && 
          b.objectData.descricao.toLowerCase().trim() === descricaoItem
        );
        
        if (!bemEncontrado) {
          const bemParcial = allBens.find(b => 
            b.objectData.descricao && 
            (b.objectData.descricao.toLowerCase().includes(descricaoItem) ||
             descricaoItem.includes(b.objectData.descricao.toLowerCase()))
          );
          
          if (bemParcial) {
            return {
              ...item,
              descricao: bemParcial.objectData.descricao,
              codigo: bemParcial.objectData.codigo,
              quantidade: parseInt(item.quantidade) || 1,
              encontrado: true
            };
          }
        }
        
        return {
          ...item,
          codigo: bemEncontrado ? bemEncontrado.objectData.codigo : null,
          quantidade: parseInt(item.quantidade) || 1,
          encontrado: !!bemEncontrado
        };
      });
      
      const bensFormatados = itensComCodigo.map(item => {
        let texto = item.descricao;
        if (item.quantidade) texto += ` (Qtd: ${item.quantidade})`;
        if (item.observacao) texto += ` - Obs: ${item.observacao}`;
        return texto;
      });

      const requisicao = await createRequisicao({
        solicitante: user.username || user.name,
        beneficiario: formData.beneficiario,
        departamento: formData.sector || user.department,
        dataRequisicao: formData.dataRequisicao,
        bens: bensFormatados,
        motivo: formData.pedido || 'Sem descrição',
        itensDetalhados: itensComCodigo,
        status: 'pendente'
      });
      
      try {
        await dbCreateObject('notificacao', {
          tipo: 'nova_requisicao',
          destinatario: 'patrimonio',
          mensagem: `Nova requisição de ${user.name} (${formData.sector || user.department})`,
          lida: false,
          requisicaoId: requisicao.objectId
        });
      } catch (notifError) {
        console.error('Error creating notification (non-critical):', notifError);
      }
      
      setAlertMessage('Requisição criada com sucesso!');
      setAlertType('success');
      setShowAlert(true);
      setFormData({
        sector: user.department,
        beneficiario: user.name,
        dataRequisicao: new Date().toISOString().split('T')[0],
        pedido: '',
        itens: [{ descricao: '', quantidade: '', observacao: '' }]
      });
      setErrors({});
    } catch (error) {
      console.error('Error creating requisition:', error);
      setAlertMessage('Erro ao criar requisição');
      setAlertType('error');
      setShowAlert(true);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} currentPage="nova-requisicao" />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      <main className="flex-grow p-6">
        <button
          onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
        >
          <div className="icon-arrow-left text-lg"></div>
          <span>Voltar</span>
        </button>
        
        <div className="max-w-4xl mx-auto">
          <h1 className="text-xl md:text-3xl font-bold mb-4 md:mb-6">Nova Requisição de Material</h1>
          
            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <div className="border border-gray-800 p-3">
                  <label className="block text-sm font-medium mb-2">Data *</label>
                  <input 
                    type="date" 
                    className={`input-field ${errors.dataRequisicao ? 'border-red-500' : ''}`}
                    value={formData.dataRequisicao}
                    min={new Date().toISOString().split('T')[0]}
                    onChange={(e) => {
                      setFormData({...formData, dataRequisicao: e.target.value});
                      setErrors({...errors, dataRequisicao: ''});
                    }}
                    required
                  />
                  {errors.dataRequisicao && <p className="text-red-500 text-xs mt-1">{errors.dataRequisicao}</p>}
                </div>
              </div>

              <div className="mb-4 md:mb-6">
              <div className="border border-gray-800 p-2 md:p-3 mb-3">
                <p className="text-xs md:text-sm"><strong>Departamento Requisitante: *</strong></p>
                <select 
                  className={`input-field mt-2 ${errors.sector ? 'border-red-500' : ''}`}
                  value={formData.sector}
                  onChange={(e) => {
                    setFormData({...formData, sector: e.target.value});
                    setErrors({...errors, sector: ''});
                  }}
                  required
                >
                  <option value="">Selecione o departamento...</option>
                  {departamentos.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
                {errors.sector && <p className="text-red-500 text-xs mt-1">{errors.sector}</p>}
              </div>

              <div className="border border-gray-800 p-3">
                <p className="text-sm"><strong>Beneficiário: *</strong></p>
                <input 
                  type="text" 
                  className={`input-field mt-2 ${errors.beneficiario ? 'border-red-500' : ''}`}
                  value={formData.beneficiario}
                  onChange={(e) => {
                    setFormData({...formData, beneficiario: e.target.value});
                    setErrors({...errors, beneficiario: ''});
                  }}
                  placeholder="Nome do beneficiário"
                  required
                />
                {errors.beneficiario && <p className="text-red-500 text-xs mt-1">{errors.beneficiario}</p>}
              </div>
              </div>

              <div className="mb-4 md:mb-6">
                <p className="text-xs md:text-sm font-bold mb-2">Detalhes:</p>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-3">
                  <label className="block text-xs md:text-sm font-medium">Itens</label>
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="btn bg-blue-600 text-white hover:bg-blue-700 text-xs md:text-sm px-3 py-1.5 flex items-center gap-2 w-full sm:w-auto"
                >
                  <div className="icon-plus text-base"></div>
                  <span>Adicionar Item</span>
                </button>
              </div>

              {errors.itens && <p className="text-red-500 text-xs mb-2">{errors.itens}</p>}
              <div className="border-2 border-gray-800 rounded-lg overflow-x-auto">
                <div className="grid grid-cols-12 bg-gray-100 border-b-2 border-gray-800 text-xs md:text-sm font-bold min-w-[600px]">
                  <div className="col-span-5 p-2 md:p-3 border-r-2 border-gray-800">Descrição *</div>
                  <div className="col-span-2 p-2 md:p-3 border-r-2 border-gray-800 text-center">Quantidade *</div>
                  <div className="col-span-5 p-2 md:p-3 text-center">Observação</div>
                </div>

                {formData.itens.map((item, index) => (
                  <div key={index} className="grid grid-cols-12 border-b border-gray-400 relative">
                    <div className="col-span-5 p-2 border-r-2 border-gray-800">
                      <input
                        type="text"
                        className="w-full px-2 py-1 border rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                        value={item.descricao}
                        onChange={(e) => handleItemChange(index, 'descricao', e.target.value)}
                        placeholder="Ex: Livro de turma"
                        required
                      />
                    </div>
                    <div className="col-span-2 p-2 border-r-2 border-gray-800">
                      <input
                        type="number"
                        className={`w-full px-2 py-1 border rounded text-center focus:outline-none focus:ring-1 ${errors[`item_${index}_quantidade`] ? 'border-red-500' : 'focus:ring-blue-500'}`}
                        value={item.quantidade}
                        onChange={(e) => {
                          handleItemChange(index, 'quantidade', e.target.value);
                          setErrors({...errors, [`item_${index}_quantidade`]: ''});
                        }}
                        placeholder="1"
                        min="1"
                      />
                      {errors[`item_${index}_quantidade`] && (
                        <p className="text-red-500 text-xs mt-1">{errors[`item_${index}_quantidade`]}</p>
                      )}
                    </div>
                    <div className="col-span-5 p-2 relative">
                      <input
                        type="text"
                        className="w-full px-2 py-1 border rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                        value={item.observacao}
                        onChange={(e) => handleItemChange(index, 'observacao', e.target.value)}
                        placeholder="Ex: Para uso no laboratório"
                      />
                      {formData.itens.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(index)}
                          className="absolute -right-8 top-1/2 -translate-y-1/2 text-red-600 hover:text-red-800"
                          title="Remover item"
                        >
                          <div className="icon-trash-2 text-lg"></div>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                </div>
              </div>



              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6 mb-4 md:mb-6 text-xs md:text-sm">
                <div className="text-center">
                  <div className="border-t-2 border-gray-800 pt-2 mt-8 md:mt-16">
                    <p className="font-semibold">Requisitado Por:</p>
                    <p className="text-xs mt-1">(Coordenador do Dpto)</p>
                  </div>
                </div>
                <div className="text-center">
                  <div className="border-t-2 border-gray-800 pt-2 mt-8 md:mt-16">
                    <p className="font-semibold">Autorizado Por:</p>
                    <p className="text-xs mt-1">(Administração)</p>
                  </div>
                </div>
                <div className="text-center">
                  <div className="border-t-2 border-gray-800 pt-2 mt-8 md:mt-16">
                    <p className="font-semibold">Entregue Por:</p>
                    <p className="text-xs mt-1">(Patrimônio)</p>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <button 
                  type="submit" 
                  className="btn btn-primary px-8"
                >
                  Enviar Requisição
                </button>
              </div>
            </form>
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<NovaRequisicaoApp />);

