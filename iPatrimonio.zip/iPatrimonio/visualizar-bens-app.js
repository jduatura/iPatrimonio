function VisualizarBensApp() {
  const [user, setUser] = React.useState(null);
  const [bens, setBens] = React.useState([]);

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    const isAdministracao = currentUser.department === 'Administração' && currentUser.role === 'default';
    const isTecnico = currentUser.role === 'tecnico' || currentUser.department === 'Manutenção';
    if ((currentUser.role !== 'patrimonio' && !isAdministracao) || isTecnico) {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadBens();
  }, []);

  const loadBens = async () => {
    const result = await dbListObjects('bem', 100);
    setBens(result.items);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} currentPage="visualizar-bens" />
      <main className="flex-grow p-6">
        <button
          onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
        >
          <div className="icon-arrow-left text-lg"></div>
          <span>Voltar</span>
        </button>
        <h1 className="text-3xl font-bold mb-6">Todos os Bens da Faculdade</h1>
        
        <div className="mb-4 text-gray-600">
          {bens.length} {bens.length === 1 ? 'bem registrado' : 'bens registrados'}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bens.length === 0 ? (
            <div className="col-span-full card text-center py-12">
              <div className="icon-inbox text-5xl text-gray-300 mx-auto mb-4 w-fit"></div>
              <p className="text-gray-500 text-lg">Nenhum bem registrado no sistema</p>
            </div>
          ) : (
            bens.map(bem => (
              <BemCard key={bem.objectId} bem={bem} />
            ))
          )}
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

function BemCard({ bem }) {
  const bemData = bem.objectData;
  const statusColors = {
    disponivel: 'bg-blue-50 text-[var(--primary-color)] border border-blue-200',
    em_uso: 'bg-gray-50 text-gray-700 border border-gray-200',
    manutencao: 'bg-gray-200 text-gray-800 border border-gray-300'
  };

  return (
    <div className="card">
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 rounded-lg flex items-center justify-center overflow-hidden"
          style={{backgroundColor: bemData.foto ? 'transparent' : '#dbeafe'}}>
          {bemData.foto ? (
            <img src={bemData.foto} alt={bemData.nome} className="w-full h-full object-cover" />
          ) : (
            <div className="icon-package text-xl text-blue-600"></div>
          )}
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[bemData.status]}`}>
          {bemData.status === 'disponivel' ? 'Disponível' : bemData.status === 'em_uso' ? 'Em Uso' : 'Manutenção'}
        </span>
      </div>
      <h3 className="font-bold text-lg mb-2">{bemData.nome}</h3>
      <p className="text-sm text-gray-600 mb-3">{bemData.descricao}</p>
      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-500">Código:</span>
          <span className="font-medium">{bemData.codigo}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">Departamento:</span>
          <span className="font-medium">{bemData.departamento || 'N/A'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">Localização:</span>
          <span className="font-medium">{bemData.localizacao || bemData.departamento || 'Instalações UCM-FADIR'}</span>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<VisualizarBensApp />);

