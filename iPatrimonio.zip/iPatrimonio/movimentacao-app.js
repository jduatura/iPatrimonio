function MovimentacaoApp() {
  const [user, setUser] = React.useState(null);
  const [bens, setBens] = React.useState([]);
  const [movimentacoes, setMovimentacoes] = React.useState([]);
  const [filteredMovimentacoes, setFilteredMovimentacoes] = React.useState([]);
  const [showModal, setShowModal] = React.useState(false);
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');
  const [filters, setFilters] = React.useState({
    periodo: 'todos',
    departamento: '',
    usuario: ''
  });

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    const isAdministracao = currentUser.department === 'Administração';
    if (currentUser.role !== 'patrimonio' && !isAdministracao) {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadData();
  }, []);

  React.useEffect(() => {
    applyFilters();
  }, [filters, movimentacoes]);

  const loadData = async () => {
    const bensResult = await dbListObjects('bem', 100);
    setBens(bensResult.items);
    const movResult = await dbListObjects('movimentacao', 100);
    setMovimentacoes(movResult.items);
  };

  const applyFilters = () => {
    let filtered = [...movimentacoes];
    const now = new Date();

    if (filters.periodo !== 'todos') {
      filtered = filtered.filter(mov => {
        const movDate = new Date(mov.objectData.dataMovimentacao);
        if (filters.periodo === 'dia') {
          return movDate.toDateString() === now.toDateString();
        } else if (filters.periodo === 'semana') {
          const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          return movDate >= weekAgo;
        } else if (filters.periodo === 'mes') {
          return movDate.getMonth() === now.getMonth() && movDate.getFullYear() === now.getFullYear();
        } else if (filters.periodo === 'semestre') {
          const semester = Math.floor(now.getMonth() / 6);
          const movSemester = Math.floor(movDate.getMonth() / 6);
          return movSemester === semester && movDate.getFullYear() === now.getFullYear();
        } else if (filters.periodo === 'ano') {
          return movDate.getFullYear() === now.getFullYear();
        }
        return true;
      });
    }

    if (filters.departamento) {
      filtered = filtered.filter(mov => 
        mov.objectData.departamentoOrigem === filters.departamento || 
        mov.objectData.departamentoDestino === filters.departamento
      );
    }

    if (filters.usuario.trim()) {
      const userLower = filters.usuario.toLowerCase();
      filtered = filtered.filter(mov => 
        mov.objectData.responsavel.toLowerCase().includes(userLower)
      );
    }

    setFilteredMovimentacoes(filtered);
  };

  const handlePrintAll = () => {
    const printWindow = window.open('', '_blank');
    const content = generatePrintContent();
    printWindow.document.write(content);
    printWindow.document.close();
    printWindow.print();
  };

  const generatePrintContent = () => {
    const periodoLabels = {
      dia: 'Hoje',
      semana: 'Esta Semana',
      mes: 'Este Mês',
      semestre: 'Este Semestre',
      ano: 'Este Ano',
      todos: 'Todo Período'
    };

    return `
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <title>Relatório de Movimentações</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          h1 { text-align: center; margin-bottom: 10px; }
          .filters { text-align: center; margin-bottom: 20px; font-size: 14px; color: #666; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 12px; }
          th { background-color: #f2f2f2; font-weight: bold; }
        </style>
      </head>
      <body>
        <h1>Relatório de Movimentações</h1>
        <div class="filters">
          <strong>Período:</strong> ${periodoLabels[filters.periodo]} | 
          <strong>Departamento:</strong> ${filters.departamento || 'Todos'} | 
          <strong>Usuário:</strong> ${filters.usuario || 'Todos'} | 
          <strong>Total:</strong> ${filteredMovimentacoes.length} movimentações
        </div>
        <table>
          <thead>
            <tr>
              <th>Data</th>
              <th>Ref. N°</th>
              <th>De</th>
              <th>Para</th>
              <th>Bens</th>
              <th>Responsável</th>
            </tr>
          </thead>
          <tbody>
            ${filteredMovimentacoes.map(mov => `
              <tr>
                <td>${new Date(mov.objectData.dataMovimentacao).toLocaleDateString('pt-BR')}</td>
                <td>${mov.objectData.numeroReferencia}</td>
                <td>${mov.objectData.departamentoOrigem}</td>
                <td>${mov.objectData.departamentoDestino}</td>
                <td>${mov.objectData.bensMovimentados.map(b => `${b.quantidade} ${b.bemNome}`).join(', ')}</td>
                <td>${mov.objectData.responsavel}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </body>
      </html>
    `;
  };

  const handleCreateMovimentacao = async (movData) => {
    try {
      // Create individual movimentacao record for each bem
      for (const bemMov of movData.bensMovimentados) {
        const bem = await dbGetObject('bem', bemMov.bemId);
        
        await dbCreateObject('movimentacao', {
          numeroReferencia: movData.numeroReferencia,
          dataMovimentacao: movData.dataMovimentacao,
          numeroPatrimonio: bem.objectData.numeroPatrimonio || bem.objectData.codigo,
          descricaoBem: bem.objectData.nome,
          localOrigem: `${movData.departamentoOrigem}${movData.localizacaoOrigem ? ' - ' + movData.localizacaoOrigem : ''}`,
          localDestino: `${movData.departamentoDestino}${movData.localizacaoDestino ? ' - ' + movData.localizacaoDestino : ''}`,
          quantidade: bemMov.quantidade,
          responsavel: user.name,
          departamentoOrigem: movData.departamentoOrigem,
          departamentoDestino: movData.departamentoDestino,
          createdAt: new Date().toISOString()
        });

        // Update bem location
        await dbUpdateObject('bem', bemMov.bemId, {
          ...bem.objectData,
          departamento: movData.departamentoDestino,
          localizacao: movData.localizacaoDestino
        });
      }

      const bensDesc = movData.bensMovimentados.map(b => `${b.quantidade} ${b.bemNome}`).join(', ');
      await logAuditAction(AUDIT_ACTIONS.CRIAR_MOVIMENTACAO, `Movimentação ${movData.numeroReferencia}: ${bensDesc} de ${movData.departamentoOrigem} para ${movData.departamentoDestino}`, user);
      setAlertMessage('Movimentação registrada com sucesso!');
      setAlertType('success');
      setShowAlert(true);
      setShowModal(false);
      loadData();
    } catch (error) {
      console.error('Error creating movimentacao:', error);
      setAlertMessage('Erro ao registrar movimentação');
      setAlertType('error');
      setShowAlert(true);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      <main className="flex-grow p-3 sm:p-4 md:p-6">
        <button onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-1.5 md:gap-2 bg-gray-200 text-gray-700 px-2.5 md:px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-xs md:text-sm mb-3 md:mb-4">
          <div className="icon-arrow-left text-base md:text-lg"></div>
          <span>Voltar</span>
        </button>

        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2 sm:gap-3 mb-3 md:mb-6">
          <h1 className="text-lg sm:text-xl md:text-3xl font-bold">Movimentação de Bens</h1>
          <div className="flex gap-2 flex-wrap">
            <button onClick={handlePrintAll}
              className="flex items-center gap-1.5 md:gap-2 bg-blue-600 text-white px-3 md:px-4 py-1.5 md:py-2 rounded-lg hover:bg-blue-700 transition text-sm">
              <div className="icon-printer text-base md:text-lg"></div>
              <span className="hidden sm:inline">Imprimir Todas</span>
              <span className="sm:hidden">Imprimir</span>
            </button>
            <button onClick={() => setShowModal(true)} className="btn btn-primary flex items-center gap-1.5 md:gap-2 text-sm">
              <div className="icon-plus text-base md:text-lg"></div>
              <span className="hidden sm:inline">Nova Movimentação</span>
              <span className="sm:hidden">Nova</span>
            </button>
          </div>
        </div>

        <div className="card mb-3 md:mb-6">
          <h3 className="font-bold mb-2 sm:mb-3 md:mb-4 text-xs sm:text-sm md:text-base">Filtros de Pesquisa</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 sm:gap-3 md:gap-4">
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Período</label>
              <select className="input-field text-xs sm:text-sm md:text-base" value={filters.periodo}
                onChange={(e) => setFilters({...filters, periodo: e.target.value})}>
                <option value="todos">Todos</option>
                <option value="dia">Hoje</option>
                <option value="semana">Esta Semana</option>
                <option value="mes">Este Mês</option>
                <option value="semestre">Este Semestre</option>
                <option value="ano">Este Ano</option>
              </select>
            </div>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Departamento</label>
              <select className="input-field text-xs sm:text-sm md:text-base" value={filters.departamento}
                onChange={(e) => setFilters({...filters, departamento: e.target.value})}>
                <option value="">Todos</option>
                <option value="Armazém">Armazém</option>
                <option value="Laboratório">Laboratório</option>
                <option value="Limpeza">Limpeza</option>
                <option value="Biblioteca">Biblioteca</option>
                <option value="Secretaria">Secretaria</option>
                <option value="Registro Acadêmico">Registro Acadêmico</option>
                <option value="Sala dos Professores">Sala dos Professores</option>
                <option value="Informática">Informática</option>
                <option value="Controle de Crédito">Controle de Crédito</option>
                <option value="Departamento de Patrimônio">Departamento de Patrimônio</option>
                <option value="Administração">Administração</option>
              </select>
            </div>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Usuário</label>
              <input type="text" className="input-field text-xs sm:text-sm md:text-base" placeholder="Nome do responsável..."
                value={filters.usuario} onChange={(e) => setFilters({...filters, usuario: e.target.value})} />
            </div>
          </div>
          <p className="text-xs sm:text-sm text-gray-500 mt-2 sm:mt-3">{filteredMovimentacoes.length} movimentações encontradas</p>
        </div>

        <div className="space-y-4">
          {filteredMovimentacoes.map(mov => (
            <MovimentacaoCard key={mov.objectId} movimentacao={mov} />
          ))}
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
      {showModal && <MovimentacaoModal bens={bens} onClose={() => setShowModal(false)} onSave={handleCreateMovimentacao} />}
    </div>
  );
}

function MovimentacaoCard({ movimentacao }) {
  const data = movimentacao.objectData;
  
  const handlePrint = () => {
    window.open(`imprimir-movimentacao.html?id=${movimentacao.objectId}`, '_blank');
  };
  
  return (
    <div className="card">
      <div className="flex items-start justify-between mb-2 sm:mb-3">
        <div>
          <p className="text-xs sm:text-sm text-gray-500">Ref. N°</p>
          <p className="font-medium text-sm sm:text-base">{data.numeroReferencia}</p>
        </div>
        <div className="text-right">
          <p className="text-xs sm:text-sm text-gray-500">Data</p>
          <p className="font-medium text-sm sm:text-base">{new Date(data.dataMovimentacao).toLocaleDateString('pt-BR')}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 mb-3 sm:mb-4">
        <div className="p-2 sm:p-3 bg-red-50 rounded-lg">
          <p className="text-xs sm:text-sm text-red-600 font-medium mb-1">De:</p>
          <p className="font-medium text-sm sm:text-base">{data.departamentoOrigem}</p>
          {data.localizacaoOrigem && <p className="text-[10px] sm:text-xs text-gray-600">{data.localizacaoOrigem}</p>}
        </div>
        <div className="p-2 sm:p-3 bg-gray-50 rounded-lg">
          <p className="text-xs sm:text-sm text-green-600 font-medium mb-1">Para:</p>
          <p className="font-medium text-sm sm:text-base">{data.departamentoDestino}</p>
          {data.localizacaoDestino && <p className="text-[10px] sm:text-xs text-gray-600">{data.localizacaoDestino}</p>}
        </div>
      </div>

      <div className="border-t pt-2 sm:pt-3 mb-2 sm:mb-3">
        <p className="text-xs sm:text-sm font-medium mb-1 sm:mb-2">Bens Movimentados:</p>
        <ul className="list-disc list-inside text-xs sm:text-sm space-y-1">
          {data.bensMovimentados && data.bensMovimentados.map((bem, idx) => (
            <li key={idx}>{bem.quantidade} {bem.bemNome} ({bem.bemCodigo})</li>
          ))}
        </ul>
      </div>

      <div className="border-t pt-2 sm:pt-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <p className="text-[10px] sm:text-xs text-gray-500">Registrado por: {data.responsavel}</p>
        <button
          onClick={handlePrint}
          className="btn bg-blue-600 text-white hover:bg-blue-700 text-xs sm:text-sm px-2.5 sm:px-3 py-1.5 flex items-center gap-1.5 sm:gap-2 w-full sm:w-auto justify-center"
        >
          <div className="icon-printer text-sm sm:text-base"></div>
          <span>Imprimir</span>
        </button>
      </div>
    </div>
  );
}

function MovimentacaoModal({ bens, onClose, onSave }) {
  const [usuarios, setUsuarios] = React.useState([]);
  const [departamentos, setDepartamentos] = React.useState([]);
  const [departamentosComBens, setDepartamentosComBens] = React.useState([]);
  const [formData, setFormData] = React.useState({
    numeroReferencia: '',
    dataMovimentacao: new Date().toISOString().split('T')[0],
    departamentoOrigem: '',
    localizacaoOrigem: '',
    departamentoDestino: '',
    localizacaoDestino: '',
    numeroPatrimonio: '',
    descricaoBem: '',
    localOrigem: '',
    localDestino: '',
    responsavel: '',
    bensMovimentados: []
  });
  const [bensSelecionados, setBensSelecionados] = React.useState([]);

  console.log('Departamentos com bens:', departamentosComBens);

  React.useEffect(() => {
    loadUsuarios();
    loadDepartamentos();
    generateReferenceNumber();
  }, []);

  React.useEffect(() => {
    loadDepartamentosComBens();
  }, [bens]);

  const loadUsuarios = async () => {
    try {
      const result = await dbListObjects('usuario', 100);
      setUsuarios(result.items);
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const loadDepartamentos = async () => {
    try {
      const result = await dbListObjects('departamento', 100, true);
      const deptNames = [...new Set(result.items.map(dept => dept.objectData.nome))].sort();
      setDepartamentos(deptNames);
    } catch (error) {
      console.error('Error loading departments:', error);
      setDepartamentos([]);
    }
  };

  const loadDepartamentosComBens = () => {
    try {
      if (!bens || bens.length === 0) {
        setDepartamentosComBens([]);
        return;
      }
      
      // Filtra bens que têm departamento definido e quantidade maior que 0
      const departamentosUnicos = [...new Set(
        bens
          .filter(bem => 
            bem.objectData.departamento && 
            bem.objectData.departamento.trim() !== '' &&
            (!bem.objectData.quantidade || parseInt(bem.objectData.quantidade) > 0)
          )
          .map(bem => bem.objectData.departamento)
      )].sort();
      
      setDepartamentosComBens(departamentosUnicos);
    } catch (error) {
      console.error('Error loading departments with assets:', error);
      setDepartamentosComBens([]);
    }
  };

  const generateReferenceNumber = () => {
    const year = new Date().getFullYear();
    const num = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    setFormData(prev => ({
      ...prev,
      numeroReferencia: `${num}/${year}/UCM/FADIR/Departamento de Património`
    }));
  };

  const handleAddBem = () => {
    setBensSelecionados([...bensSelecionados, { bemId: '', quantidade: 1 }]);
  };

  const handleRemoveBem = (index) => {
    setBensSelecionados(bensSelecionados.filter((_, i) => i !== index));
  };

  const handleBemChange = (index, field, value) => {
    const updated = [...bensSelecionados];
    updated[index][field] = value;
    setBensSelecionados(updated);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const bensComDetalhes = bensSelecionados.map(sel => {
      const bem = bens.find(b => b.objectId === sel.bemId);
      return {
        bemId: sel.bemId,
        bemNome: bem.objectData.nome,
        bemCodigo: bem.objectData.codigo,
        quantidade: parseInt(sel.quantidade)
      };
    });

    onSave({
      ...formData,
      bensMovimentados: bensComDetalhes
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto p-2 sm:p-4">
      <div className="bg-white rounded-lg p-3 sm:p-4 md:p-6 w-full max-w-4xl my-4 sm:my-8 max-h-[95vh] sm:max-h-[90vh] overflow-y-auto">
        <div className="mb-3 sm:mb-4 md:mb-6 border-b pb-2 sm:pb-3 md:pb-4">
          <div className="flex items-center gap-2 sm:gap-3 md:gap-4 mb-2">
            <img src="assets/logo.png" alt="UCM Logo" className="h-8 sm:h-10 md:h-12" />
            <div>
              <h2 className="text-sm sm:text-base md:text-xl font-bold">Universidade Católica de Moçambique</h2>
              <p className="text-xs sm:text-sm text-gray-600">Faculdade de Direito</p>
            </div>
          </div>
        </div>

        <h3 className="text-base sm:text-lg font-bold mb-2 sm:mb-3 md:mb-4">Pedido de Movimentação de Bens</h3>
        
        <form onSubmit={handleSubmit} className="space-y-2 sm:space-y-3 md:space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 md:gap-4">
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Ref. N° *</label>
              <input type="text" className="input-field text-sm sm:text-base" value={formData.numeroReferencia}
                onChange={(e) => setFormData({...formData, numeroReferencia: e.target.value})} required />
            </div>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Data *</label>
              <input type="date" className="input-field text-sm sm:text-base" value={formData.dataMovimentacao}
                onChange={(e) => setFormData({...formData, dataMovimentacao: e.target.value})} required />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 md:gap-4">
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">De (Departamento) *</label>
              <select className="input-field text-sm sm:text-base" value={formData.departamentoOrigem}
                onChange={async (e) => {
                  const deptName = e.target.value;
                  setFormData({...formData, departamentoOrigem: deptName});
                  setBensSelecionados([]);
                  
                  if (deptName) {
                    try {
                      const deptResult = await dbListObjects('departamento', 100);
                      const dept = deptResult.items.find(d => d.objectData.nome === deptName);
                      if (dept && dept.objectData.sala) {
                        const localizacao = `${dept.objectData.sala}${dept.objectData.edificio ? ', ' + dept.objectData.edificio : ''}${dept.objectData.piso ? ', Piso ' + dept.objectData.piso : ''}`;
                        setFormData(prev => ({...prev, localizacaoOrigem: localizacao}));
                      }
                    } catch (error) {
                      console.error('Error loading department location:', error);
                    }
                  }
                }} required>
                <option value="">Selecione...</option>
                {departamentosComBens.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Localização Origem</label>
              <input type="text" className="input-field text-sm sm:text-base bg-gray-100" value={formData.localizacaoOrigem}
                readOnly
                placeholder="Preenchido automaticamente" />
              <p className="text-[10px] sm:text-xs text-gray-500 mt-1">Localização preenchida automaticamente</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 md:gap-4">
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Para (Departamento) *</label>
              <select className="input-field text-sm sm:text-base" value={formData.departamentoDestino}
                onChange={async (e) => {
                  const deptName = e.target.value;
                  setFormData({...formData, departamentoDestino: deptName});
                  
                  if (deptName) {
                    try {
                      const deptResult = await dbListObjects('departamento', 100);
                      const dept = deptResult.items.find(d => d.objectData.nome === deptName);
                      if (dept && dept.objectData.sala) {
                        const localizacao = `${dept.objectData.sala}${dept.objectData.edificio ? ', ' + dept.objectData.edificio : ''}${dept.objectData.piso ? ', Piso ' + dept.objectData.piso : ''}`;
                        setFormData(prev => ({...prev, localizacaoDestino: localizacao}));
                      }
                    } catch (error) {
                      console.error('Error loading department location:', error);
                    }
                  }
                }} required>
                <option value="">Selecione...</option>
                {departamentos.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1 sm:mb-2">Localização Destino</label>
              <input type="text" className="input-field text-sm sm:text-base bg-gray-100" value={formData.localizacaoDestino}
                readOnly
                placeholder="Preenchido automaticamente" />
              <p className="text-[10px] sm:text-xs text-gray-500 mt-1">Localização preenchida automaticamente</p>
            </div>
          </div>

          <div className="border-t pt-2 sm:pt-3 md:pt-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-2 sm:mb-3">
              <label className="block text-xs sm:text-sm font-medium">Bens a Movimentar *</label>
              <button type="button" onClick={handleAddBem}
                className="btn bg-blue-600 text-white hover:bg-blue-700 text-xs sm:text-sm px-2.5 sm:px-3 py-1 w-full sm:w-auto">
                + Adicionar Bem
              </button>
            </div>
            <div className="space-y-2 sm:space-y-3">
              {bensSelecionados.map((sel, index) => (
                <div key={index} className="flex flex-col sm:flex-row gap-2">
                  <select className="input-field flex-1 text-sm sm:text-base" value={sel.bemId}
                    onChange={(e) => handleBemChange(index, 'bemId', e.target.value)} required>
                    <option value="">Selecione um bem...</option>
                    {bens
                      .filter(bem => bem.objectData.departamento === formData.departamentoOrigem)
                      .map(bem => (
                        <option key={bem.objectId} value={bem.objectId}>
                          {bem.objectData.nome} ({bem.objectData.codigo}) - Qtd: {bem.objectData.quantidade || 'N/A'}
                        </option>
                      ))}
                  </select>
                  <div className="flex gap-2">
                    <input type="number" min="1" className="input-field w-20 sm:w-24 text-sm sm:text-base" value={sel.quantidade}
                      onChange={(e) => handleBemChange(index, 'quantidade', e.target.value)} 
                      placeholder="Qtd" required />
                    <button type="button" onClick={() => handleRemoveBem(index)}
                      className="btn bg-red-100 text-red-600 hover:bg-red-200 px-2.5 sm:px-3">
                      <div className="icon-x text-base sm:text-lg"></div>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-3 mt-3 sm:mt-4 md:mt-6 pt-2 sm:pt-3 md:pt-4 border-t">
            <button type="button" onClick={onClose} className="btn bg-gray-200 text-gray-800 hover:bg-gray-300 text-sm sm:text-base w-full sm:w-auto">
              Cancelar
            </button>
            <button type="submit" className="btn btn-primary text-sm sm:text-base w-full sm:w-auto">Registrar Movimentação</button>
          </div>
        </form>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<MovimentacaoApp />);

