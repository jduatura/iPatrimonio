class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Algo deu errado</h1>
            <p className="text-gray-600 mb-4">Desculpe, mas algo inesperado aconteceu.</p>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Recarregar Página
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function LoginApp() {
  try {
    const [user, setUser] = React.useState(null);
    const [showAlert, setShowAlert] = React.useState(false);
    const [alertMessage, setAlertMessage] = React.useState('');
    const [alertType, setAlertType] = React.useState('success');

    React.useEffect(() => {
      initializeDefaultDepartments();
      initializeDefaultUsers();
      const currentUser = getCurrentUser();
      setUser(currentUser);
    }, []);

    const handleLogin = async (username, password) => {
      const result = await login(username, password);
      if (result.success) {
        setAlertMessage('Login realizado com sucesso!');
        setAlertType('success');
        setShowAlert(true);
        setTimeout(() => {
          setUser(result.user);
          window.location.href = 'dashboard.html';
        }, 1000);
      } else {
        setAlertMessage(result.message);
        setAlertType('error');
        setShowAlert(true);
      }
    };

    if (user) {
      window.location.href = 'dashboard.html';
      return null;
    }

    return (
      <div className="bg-gray-100 min-h-screen flex flex-col" data-name="login-app" data-file="login-app.js">
        {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
        <LoginForm onLogin={handleLogin} />
      </div>
    );
  } catch (error) {
    console.error('LoginApp component error:', error);
    return null;
  }
}

function LoginForm({ onLogin }) {
  const [username, setUsername] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [errorMessage, setErrorMessage] = React.useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage('');
    await onLogin(username, password);
    setIsSubmitting(false);
  };

  return (
    <React.Fragment>
      <header className="bg-white shadow-md py-4" data-name="login-header" data-file="login-app.js">
        <div className="px-6 flex items-center space-x-4">
          <div>
            <img src="assets/logo.png" alt="UCM Logo" className="h-12 w-auto" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold text-[var(--primary-color)]">iPatrimônio</h1>
            <p className="text-sm text-gray-600">Universidade Católica de Moçambique - FADIR</p>
          </div>
        </div>
      </header>

      <main className="flex-grow" data-name="login-form" data-file="login-app.js">
        <header className="bg-white border-b shadow-sm p-4 flex justify-end items-center">
          <button
            onClick={() => window.location.href = 'index.html'}
            className="flex items-center gap-2 bg-blue-600 text-white px-3 py-1.5 rounded-lg font-medium hover:bg-blue-700 transition text-sm"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6A2.25 2.25 0 005.25 5.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9" />
            </svg>
            <span>Voltar ao Início</span>
          </button>
        </header>

        <main className="flex flex-col items-center justify-center flex-grow px-4 py-10 bg-gray-50 w-full">
          <div className="bg-white shadow-lg rounded-xl p-8 w-full max-w-md text-center">
            <div className="mx-auto mb-3" style={{background: '#ffffff', width: '120px', height: '120px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <img src="assets/logo.png" alt="UCM Logo" className="w-12 h-12 object-contain" />
            </div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">Acesso ao Sistema</h2>
            <p className="text-gray-500 text-sm mb-6">Insira suas credenciais para continuar</p>

            <form onSubmit={handleSubmit} className="text-left">
              <label className="block mb-2 text-gray-700 font-medium">E-mail</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />

              <label className="block mb-2 text-gray-700 font-medium">Senha</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg mb-6 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition disabled:opacity-50"
              >
                {isSubmitting ? 'Aguarde...' : 'Entrar'}
              </button>
            </form>

            {errorMessage && (
              <p className="text-red-500 text-sm mt-4">{errorMessage}</p>
            )}
          </div>
        </main>
      </main>

      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t" data-name="login-footer" data-file="login-app.js">
        © <span id="year"></span> - iPatrimônio | UCM-FADIR
      </footer>
    </React.Fragment>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <LoginApp />
  </ErrorBoundary>
);

// Atualizar ano no rodapé
setTimeout(() => {
  const yearElement = document.getElementById('year');
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }
}, 100);


