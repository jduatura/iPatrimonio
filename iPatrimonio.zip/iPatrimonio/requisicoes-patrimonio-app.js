function RequisicoesPatrimonioApp() {
  const [user, setUser] = React.useState(null);
  const [requisicoes, setRequisicoes] = React.useState([]);
  const [userNames, setUserNames] = React.useState({});
  const [activeTab, setActiveTab] = React.useState('novas');
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    const isAdministracao = currentUser.department === 'Administração';
    if (currentUser.role !== 'patrimonio' && !isAdministracao) {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadRequisicoes();
  }, []);

  const loadRequisicoes = async () => {
    const result = await dbListObjects('requisicao', 100);
    setRequisicoes(result.items);
    
    // Load user names
    try {
      const users = await dbListObjects('usuario', 200, true);
      const names = {};
      users.items.forEach(u => {
        if (u.objectData.email) {
          names[u.objectData.email] = u.objectData.nome;
        }
      });
      setUserNames(names);
    } catch (error) {
      console.error('Error loading user names:', error);
    }
  };

  const handleForward = async (reqId) => {
    try {
      const req = await dbGetObject('requisicao', reqId);
      await dbUpdateObject('requisicao', reqId, {
        ...req.objectData,
        status: 'encaminhada',
        encaminhadaPor: user.name,
        dataEncaminhamento: new Date().toISOString()
      });
      
      const isFromAdmin = req.objectData.departamento === 'Administração';
      
      try {
        await dbCreateObject('notificacao', {
          tipo: 'requisicao_encaminhada',
          destinatario: 'Administração',
          mensagem: isFromAdmin 
            ? `Requisição da Administração pronta para aprovação - Solicitante: ${req.objectData.solicitante}`
            : `Requisição encaminhada - Solicitante: ${req.objectData.solicitante} (${req.objectData.departamento})`,
          lida: false,
          requisicaoId: reqId
        });
      } catch (notifError) {
        console.error('Error creating notification (non-critical):', notifError);
      }
      
      setAlertMessage(isFromAdmin 
        ? 'Requisição encaminhada de volta para aprovação da Administração!'
        : 'Requisição encaminhada para Administração!');
      setAlertType('success');
      setShowAlert(true);
      loadRequisicoes();
    } catch (error) {
      console.error('Error forwarding requisition:', error);
      setAlertMessage('Erro ao encaminhar requisição');
      setAlertType('error');
      setShowAlert(true);
    }
  };

  const handlePrint = (reqId) => {
    window.open(`imprimir-requisicao.html?id=${reqId}`, '_blank');
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      <main className="flex-grow p-6">
        <button
          onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
        >
          <div className="icon-arrow-left text-lg"></div>
          <span>Voltar</span>
        </button>
        <h1 className="text-3xl font-bold mb-6">Requisições Recebidas</h1>
        <div className="flex gap-4 mb-6 border-b">
          <button
            onClick={() => setActiveTab('novas')}
            className={`py-2 px-4 font-semibold text-sm border-b-2 ${activeTab === 'novas' ? 'border-[var(--primary-color)] text-[var(--primary-color)]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            Novas / Encaminhadas
          </button>
          <button
            onClick={() => setActiveTab('historico')}
            className={`py-2 px-4 font-semibold text-sm border-b-2 ${activeTab === 'historico' ? 'border-[var(--primary-color)] text-[var(--primary-color)]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            Histórico (Aprovadas/Rejeitadas)
          </button>
        </div>
        <div className="space-y-4">
          {requisicoes.filter(req => 
            activeTab === 'novas' 
              ? (req.objectData.status === 'pendente' || req.objectData.status === 'encaminhada')
              : (req.objectData.status === 'aprovada' || req.objectData.status === 'rejeitada')
          ).map(req => (
            <RequisicaoCard 
              key={req.objectId} 
              requisicao={req}
              userNames={userNames}
              onForward={handleForward}
              onPrint={handlePrint}
            />
          ))}
          {requisicoes.filter(req => 
            activeTab === 'novas' 
              ? (req.objectData.status === 'pendente' || req.objectData.status === 'encaminhada')
              : (req.objectData.status === 'aprovada' || req.objectData.status === 'rejeitada')
          ).length === 0 && (
            <div className="text-center py-8 text-gray-500 bg-white rounded-xl shadow-sm border">
              Nenhuma requisição encontrada nesta aba.
            </div>
          )}
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

function RequisicaoCard({ requisicao, userNames, onForward, onPrint }) {
  const { objectId, objectData } = requisicao;
  const statusColors = {
    pendente: 'bg-gray-50 text-gray-700 border border-gray-200',
    encaminhada: 'bg-blue-100 text-blue-800',
    aprovada: 'bg-blue-50 text-[var(--primary-color)] border border-blue-200',
    rejeitada: 'bg-gray-200 text-gray-800 border border-gray-300'
  };

  const statusLabels = {
    pendente: 'Pendente',
    encaminhada: 'Encaminhada',
    aprovada: 'Aprovada',
    rejeitada: 'Rejeitada'
  };

  const displayName = userNames[objectData.solicitante] || objectData.solicitante;

  return (
    <div className="card">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="font-bold text-lg">{displayName}</h3>
          <p className="text-sm text-gray-500">{objectData.departamento}</p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[objectData.status]}`}>
          {statusLabels[objectData.status]}
        </span>
      </div>
      <p className="text-gray-700 mb-4">{objectData.motivo}</p>
      <div className="text-xs sm:text-sm text-gray-700 bg-gray-50 p-3 rounded-lg border mb-4">
        <p className="font-semibold text-gray-800 mb-1 border-b pb-1">Bens solicitados:</p>
        <p className="text-gray-700">
          {Array.isArray(objectData.bens) ? objectData.bens.join(', ') : (objectData.bens || 'Nenhum bem especificado')}
        </p>
      </div>
      <div className="flex gap-3">
        {objectData.status === 'pendente' && (
          <button 
            onClick={() => onForward(objectId)} 
            className="btn bg-[var(--primary-color)] text-white hover:opacity-90 flex items-center gap-2 flex-1"
          >
            <div className="icon-send text-lg"></div>
            <span>Encaminhar para Administração</span>
          </button>
        )}
        {objectData.status === 'encaminhada' && (
          <div className="text-sm text-gray-600 p-3 bg-blue-50 border border-blue-100 rounded-lg w-full">
            <div className="flex items-center gap-2">
              <div className="icon-clock text-lg text-[var(--primary-color)]"></div>
              <span>Aguardando aprovação da Administração</span>
            </div>
          </div>
        )}
        {objectData.status === 'aprovada' && (
          <button
            onClick={() => onPrint(objectId)}
            className="btn bg-[var(--primary-color)] text-white hover:opacity-90 flex items-center gap-2 flex-1"
          >
            <div className="icon-printer text-lg"></div>
            <span>Imprimir Requisição Aprovada</span>
          </button>
        )}
        {objectData.status === 'rejeitada' && (
          <div className="text-sm text-gray-600 p-3 bg-gray-50 border border-gray-200 rounded-lg w-full">
            <div className="flex items-center gap-2">
              <div className="icon-x-circle text-lg text-gray-600"></div>
              <span>Requisição rejeitada pela Administração</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<RequisicoesPatrimonioApp />);

