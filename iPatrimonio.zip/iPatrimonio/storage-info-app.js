const { useState, useEffect } = React;

function StorageInfoApp() {
    const [storageInfo, setStorageInfo] = useState({});
    const [alert, setAlert] = useState(null);

    useEffect(() => {
        checkAuth();
        loadStorageInfo();
    }, []);

    const checkAuth = () => {
        const user = getCurrentUser();
        if (!user || user.objectData.role !== 'admin') {
            window.location.href = 'dashboard.html';
        }
    };

    const loadStorageInfo = () => {
        const info = {};
        const types = ['bem', 'requisicao', 'usuario', 'departamento', 'movimentacao', 'termo_entrega', 'abate', 'saida_material'];
        
        types.forEach(type => {
            let count = 0;
            let size = 0;
            for (let key in localStorage) {
                if (key.startsWith(`legacy_${type}_`)) {
                    count++;
                    size += localStorage[key].length + key.length;
                }
            }
            info[type] = { count, size };
        });

        info.total = window.getStorageSize();
        setStorageInfo(info);
    };

    const formatBytes = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    };

    const clearOldData = (type) => {
        const removed = window.clearOldestObjects(type, 20);
        setAlert({ type: 'success', message: `${removed} registros antigos removidos de ${type}` });
        setTimeout(() => {
            loadStorageInfo();
            setAlert(null);
        }, 2000);
    };

    return (
        <div>
            <Header />
            <div className="container mx-auto px-4 py-8">
                <h1 className="text-3xl font-bold text-gray-800 mb-6">Informações de Armazenamento</h1>
                
                {alert && <Alert type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}

                <div className="card mb-6">
                    <h2 className="text-xl font-semibold mb-4">Uso Total do Armazenamento</h2>
                    <p className="text-2xl text-[var(--primary-color)] font-bold">{formatBytes(storageInfo.total || 0)}</p>
                    <p className="text-gray-600 mt-2">Limite aproximado: 5-10 MB (dependendo do navegador)</p>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                    {Object.entries(storageInfo).filter(([key]) => key !== 'total').map(([type, data]) => (
                        <div key={type} className="card">
                            <div className="flex justify-between items-start mb-3">
                                <div>
                                    <h3 className="font-semibold text-lg capitalize">{type.replace('_', ' ')}</h3>
                                    <p className="text-gray-600">Registros: {data.count}</p>
                                    <p className="text-gray-600">Tamanho: {formatBytes(data.size)}</p>
                                </div>
                                {data.count > 50 && (
                                    <button 
                                        onClick={() => clearOldData(type)}
                                        className="btn btn-primary text-sm"
                                    >
                                        Limpar Antigos
                                    </button>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<StorageInfoApp />);

