function UsuariosApp() {
  const [user, setUser] = React.useState(null);
  const [usuarios, setUsuarios] = React.useState([]);
  const [filteredUsuarios, setFilteredUsuarios] = React.useState([]);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [showModal, setShowModal] = React.useState(false);
  const [editingUser, setEditingUser] = React.useState(null);
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    if (!canManageUsers(currentUser)) {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadUsuarios();
  }, []);

  React.useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredUsuarios(usuarios);
    } else {
      const term = searchTerm.toLowerCase();
      const filtered = usuarios.filter(u => 
        u.objectData.name.toLowerCase().includes(term) ||
        u.objectData.username.toLowerCase().includes(term) ||
        u.objectId.toLowerCase().includes(term)
      );
      setFilteredUsuarios(filtered);
    }
  }, [searchTerm, usuarios]);

  const loadUsuarios = async () => {
    const result = await dbListObjects('usuario', 100);
    setUsuarios(result.items);
    setFilteredUsuarios(result.items);
  };

  const handleAddUser = async (userData) => {
    const result = await dbListObjects('usuario', 1000);
    const emailExists = result.items.some(u => u.objectData.username === userData.username);
    
    if (emailExists) {
      setAlertMessage('Já existe um usuário cadastrado com este e-mail!');
      setAlertType('error');
      setShowAlert(true);
      return;
    }
    
    await dbCreateObject('usuario', { ...userData, ativo: true });
    await logAuditAction(AUDIT_ACTIONS.CRIAR_USUARIO, `Usuário criado: ${userData.name} (${userData.username})`, user);
    setAlertMessage('Usuário criado com sucesso!');
    setAlertType('success');
    setShowAlert(true);
    setShowModal(false);
    loadUsuarios();
  };

  const handleEditUser = async (userData) => {
    try {
      const targetUser = await dbGetObject('usuario', editingUser.objectId);
      await dbUpdateObject('usuario', editingUser.objectId, {
        ...targetUser.objectData,
        name: userData.name,
        department: userData.department,
        role: userData.role
      });
      await logAuditAction(AUDIT_ACTIONS.EDITAR_USUARIO, `Usuário editado: ${userData.name}`, user);
      setAlertMessage('Usuário atualizado com sucesso!');
      setAlertType('success');
      setShowAlert(true);
      setShowModal(false);
      setEditingUser(null);
      loadUsuarios();
    } catch (error) {
      console.error('Error editing user:', error);
      setAlertMessage('Erro ao atualizar usuário');
      setAlertType('error');
      setShowAlert(true);
    }
  };

  const handleOpenEdit = (userObj) => {
    setEditingUser(userObj);
    setShowModal(true);
  };

  const handleToggleStatus = async (userId, currentStatus) => {
    try {
      const targetUser = await dbGetObject('usuario', userId);
      await dbUpdateObject('usuario', userId, {
        ...targetUser.objectData,
        ativo: !currentStatus
      });
      const action = !currentStatus ? AUDIT_ACTIONS.ATIVAR_USUARIO : AUDIT_ACTIONS.DESATIVAR_USUARIO;
      await logAuditAction(action, `Usuário ${!currentStatus ? 'ativado' : 'desativado'}: ${targetUser.objectData.name}`, user);
      setAlertMessage(`Usuário ${!currentStatus ? 'ativado' : 'desativado'} com sucesso!`);
      setShowAlert(true);
      loadUsuarios();
    } catch (error) {
      setAlertMessage('Erro ao alterar status do usuário');
      setShowAlert(true);
    }
  };



  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} currentPage="usuarios" />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      <main className="flex-grow p-6">
          <button
            onClick={() => window.location.href = 'dashboard.html'}
            className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
          >
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar</span>
          </button>
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">Gestão de Usuários</h1>
            <button onClick={() => { setEditingUser(null); setShowModal(true); }} className="btn btn-primary">
              Novo Usuário
            </button>
          </div>
          
          <div className="mb-6">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <div className="icon-search text-lg text-gray-400"></div>
              </div>
              <input
                type="text"
                className="input-field pl-10"
                placeholder="Pesquisar por nome, usuário ou ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <p className="text-sm text-gray-500 mt-2">
              {filteredUsuarios.length} {filteredUsuarios.length === 1 ? 'usuário encontrado' : 'usuários encontrados'}
            </p>
          </div>

          <div className="hidden md:block card overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3">Nome</th>
                  <th className="text-left py-3">Usuário</th>
                  <th className="text-left py-3">Departamento</th>
                  <th className="text-left py-3">Função</th>
                  <th className="text-left py-3">Status</th>
                  <th className="text-left py-3">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsuarios.map(u => (
                  <UserRow 
                    key={u.objectId} 
                    user={u} 
                    onEdit={() => handleOpenEdit(u)}
                    onToggleStatus={handleToggleStatus}
                  />
                ))}
              </tbody>
            </table>
          </div>

          <div className="md:hidden space-y-3">
            {filteredUsuarios.map(u => (
              <UserCard
                key={u.objectId}
                user={u}
                onEdit={() => handleOpenEdit(u)}
                onToggleStatus={handleToggleStatus}
              />
            ))}
          </div>
        </main>
        <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
          © 2026 - iPatrimônio | UCM-FADIR
        </footer>
        {showModal && (
          <UserModal 
            onClose={() => { setShowModal(false); setEditingUser(null); }} 
            onSave={editingUser ? handleEditUser : handleAddUser}
            initialData={editingUser ? editingUser.objectData : null}
            isEditing={!!editingUser}
          />
        )}
      </div>
  );
}

function UserCard({ user, onEdit, onToggleStatus }) {
  const { objectId, objectData } = user;
  const isActive = objectData.ativo !== false;

  return (
    <div className="card">
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1">
          <h3 className="font-bold text-base break-words">{objectData.name}</h3>
          <p className="text-xs text-gray-500 mt-1 break-words">{objectData.username}</p>
          <p className="text-xs text-gray-600 mt-1 break-words">{objectData.department}</p>
        </div>
        <span className={`px-2 py-1 rounded text-xs font-medium flex-shrink-0 ${
          isActive ? 'bg-blue-50 text-[var(--primary-color)] border border-blue-200' : 'bg-gray-200 text-gray-800 border border-gray-300'
        }`}>
          {isActive ? 'Ativo' : 'Inativo'}
        </span>
      </div>
      
      <div className="mb-3">
        <span className={`px-2 py-1 rounded text-xs font-medium ${
          objectData.role === 'admin' ? 'bg-blue-50 text-blue-800 border border-blue-200' :
          objectData.role === 'patrimonio' ? 'bg-blue-100 text-blue-800' :
          objectData.role === 'administracao' ? 'bg-blue-50 text-blue-800 border border-blue-200' :
          'bg-gray-100 text-gray-800'
        }`}>
          {objectData.role === 'admin' ? 'Administrador' : 
           objectData.role === 'patrimonio' ? 'Patrimônio' : 
           objectData.role === 'administracao' ? 'Administração' : 'Usuário'}
        </span>
      </div>

      <div className="flex gap-2">
        <button
          onClick={onEdit}
          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium bg-blue-600 text-white hover:bg-blue-700 transition"
        >
          Editar
        </button>
        <button
          onClick={() => onToggleStatus(objectId, isActive)}
          className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition ${
            isActive 
              ? 'bg-yellow-600 text-white hover:bg-yellow-700' 
              : 'bg-green-600 text-white hover:bg-green-700'
          }`}
        >
          {isActive ? 'Desativar' : 'Ativar'}
        </button>
      </div>
    </div>
  );
}

function UserRow({ user, onEdit, onToggleStatus }) {
  const { objectId, objectData } = user;
  const isActive = objectData.ativo !== false;

  return (
    <tr className="border-b hover:bg-gray-50">
      <td className="py-3">{objectData.name}</td>
      <td className="py-3">{objectData.username}</td>
      <td className="py-3">{objectData.department}</td>
      <td className="py-3">
        <span className={`px-2 py-1 rounded text-xs font-medium ${
          objectData.role === 'admin' ? 'bg-blue-50 text-blue-800 border border-blue-200' :
          objectData.role === 'patrimonio' ? 'bg-blue-100 text-blue-800' :
          objectData.role === 'administracao' ? 'bg-blue-50 text-blue-800 border border-blue-200' :
          'bg-gray-100 text-gray-800'
        }`}>
          {objectData.role === 'admin' ? 'Administrador' : 
           objectData.role === 'patrimonio' ? 'Patrimônio' : 
           objectData.role === 'administracao' ? 'Administração' : 'Usuário'}
        </span>
      </td>
      <td className="py-3">
        <span className={`px-2 py-1 rounded text-xs font-medium ${
          isActive ? 'bg-blue-50 text-[var(--primary-color)] border border-blue-200' : 'bg-gray-200 text-gray-800 border border-gray-300'
        }`}>
          {isActive ? 'Ativo' : 'Inativo'}
        </span>
      </td>
      <td className="py-3">
        <div className="flex items-center gap-2">
          <button
            onClick={onEdit}
            className="px-3 py-1 rounded text-xs font-medium bg-blue-100 text-blue-800 hover:bg-blue-200 transition"
            title="Editar usuário"
          >
            Editar
          </button>
          <button
            onClick={() => onToggleStatus(objectId, isActive)}
            className={`px-3 py-1 rounded text-xs font-medium transition ${
              isActive 
                ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200' 
                : 'bg-green-100 text-gray-800 hover:bg-green-200'
            }`}
            title={isActive ? 'Desativar usuário' : 'Ativar usuário'}
          >
            {isActive ? 'Desativar' : 'Ativar'}
          </button>
        </div>
      </td>
    </tr>
  );
}

function UserModal({ onClose, onSave, initialData, isEditing }) {
  const [formData, setFormData] = React.useState(
    initialData 
      ? { name: initialData.name, username: initialData.username, password: '', confirmPassword: '', department: initialData.department, role: initialData.role }
      : { name: '', username: '', password: '', confirmPassword: '', department: '', role: 'default' }
  );
  const [emailError, setEmailError] = React.useState('');
  const [passwordError, setPasswordError] = React.useState('');

  const handleEmailChange = (value) => {
    setFormData({...formData, username: value});
    if (value && !value.endsWith('@ucm.ac.mz')) {
      setEmailError('O e-mail deve terminar com @ucm.ac.mz');
    } else {
      setEmailError('');
    }
  };

  const handleNameChange = (value) => {
    if (value === '' || /^[a-zA-ZÀ-ÿ\s]*$/.test(value)) {
      setFormData({...formData, name: value});
    }
  };

  const handleDepartmentChange = (dept) => {
    let role = formData.role;
    if (dept === 'Departamento de Patrimônio') role = 'patrimonio';
    else if (dept === 'Manutenção') role = 'tecnico';
    else if (role === 'patrimonio' || role === 'tecnico') role = 'default';

    setFormData({
      ...formData, 
      department: dept,
      role: role
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isEditing && !formData.username.endsWith('@ucm.ac.mz')) {
      setEmailError('O e-mail deve terminar com @ucm.ac.mz');
      return;
    }
    if (!isEditing && formData.password.length < 8) {
      setPasswordError('A senha deve ter no mínimo 8 caracteres');
      return;
    }
    if (!isEditing && formData.password !== formData.confirmPassword) {
      setPasswordError('As senhas não correspondem');
      return;
    }
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-2 xs:p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-lg p-3 xs:p-4 sm:p-6 w-full max-w-md my-auto min-w-0 max-h-[92vh] flex flex-col shadow-xl">
        <h2 className="text-base xs:text-lg sm:text-2xl font-bold mb-3 sm:mb-4 text-gray-800 flex-shrink-0">
          {isEditing ? 'Editar Usuário' : 'Novo Usuário'}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-2.5 sm:space-y-4 overflow-y-auto pr-0.5 min-w-0">
          <div>
            <label className="block text-xs sm:text-sm font-medium mb-1">Nome</label>
            <input 
              type="text" 
              className="input-field w-full text-xs sm:text-sm py-1.5 px-3 sm:py-2 sm:px-4" 
              value={formData.name}
              onChange={(e) => handleNameChange(e.target.value)} 
              required 
            />
          </div>
          {!isEditing && (
            <>
              <div>
                <label className="block text-xs sm:text-sm font-medium mb-1">E-mail (@ucm.ac.mz)</label>
                <input 
                  type="email" 
                  className="input-field w-full text-xs sm:text-sm py-1.5 px-3 sm:py-2 sm:px-4" 
                  value={formData.username}
                  onChange={(e) => handleEmailChange(e.target.value)} 
                  placeholder="exemplo@ucm.ac.mz"
                  required 
                />
                {emailError && <p className="text-red-500 text-[11px] sm:text-xs mt-1">{emailError}</p>}
              </div>
              <div>
                <label className="block text-xs sm:text-sm font-medium mb-1">Senha</label>
                <input 
                  type="password" 
                  className="input-field w-full text-xs sm:text-sm py-1.5 px-3 sm:py-2 sm:px-4" 
                  value={formData.password}
                  minLength="8"
                  onChange={(e) => {
                    setFormData({...formData, password: e.target.value});
                    setPasswordError('');
                  }} 
                  required 
                />
              </div>
              <div>
                <label className="block text-xs sm:text-sm font-medium mb-1">Confirmar Senha</label>
                <input 
                  type="password" 
                  className="input-field w-full text-xs sm:text-sm py-1.5 px-3 sm:py-2 sm:px-4" 
                  value={formData.confirmPassword}
                  minLength="8"
                  onChange={(e) => {
                    setFormData({...formData, confirmPassword: e.target.value});
                    setPasswordError('');
                  }} 
                  required 
                />
                {passwordError && <p className="text-red-500 text-[11px] sm:text-xs mt-1">{passwordError}</p>}
              </div>
            </>
          )}
          <div>
            <label className="block text-xs sm:text-sm font-medium mb-1">Departamento</label>
            <select className="input-field w-full text-xs sm:text-sm py-1.5 px-3 sm:py-2 sm:px-4" value={formData.department}
              onChange={(e) => handleDepartmentChange(e.target.value)} required>
              <option value="">Selecione...</option>
              <option value="Limpeza">Limpeza</option>
              <option value="Biblioteca">Biblioteca</option>
              <option value="Secretaria">Secretaria</option>
              <option value="Registro Acadêmico">Registro Acadêmico</option>
              <option value="Sala dos Professores">Sala dos Professores</option>
              <option value="Informática">Informática</option>
              <option value="Controle de Crédito">Controle de Crédito</option>
              <option value="Departamento de Patrimônio">Departamento de Patrimônio</option>
              <option value="Administração">Administração</option>
              <option value="Manutenção">Manutenção</option>
              <option value="Diretor">Diretor</option>
              <option value="Pedagógico">Pedagógico</option>
              <option value="Recursos Humanos">Recursos Humanos</option>
              <option value="Relações Públicas">Relações Públicas</option>
            </select>
          </div>
          {formData.department !== 'Departamento de Patrimônio' && formData.department !== 'Manutenção' && (
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1">Função</label>
              <select className="input-field w-full text-xs sm:text-sm py-1.5 px-3 sm:py-2 sm:px-4" value={formData.role}
                onChange={(e) => setFormData({...formData, role: e.target.value})} required>
                <option value="default">Usuário</option>
                <option value="admin">Administrador</option>
                <option value="administracao">Administração</option>
                <option value="tecnico">Técnico de Manutenção</option>
              </select>
            </div>
          )}
          {formData.department === 'Manutenção' && (
            <div className="p-2 sm:p-3 bg-blue-50 border border-blue-200 rounded-lg text-[11px] sm:text-xs text-blue-800 leading-snug">
              ℹ️ Membros do departamento de Manutenção são atribuídos automaticamente com a função <strong>Técnico de Manutenção</strong>.
            </div>
          )}
          <div className="flex flex-col-reverse xs:flex-row justify-end gap-2 sm:gap-3 pt-2 sm:pt-4 border-t border-gray-100 flex-shrink-0">
            <button type="button" onClick={onClose} className="btn btn-secondary w-full xs:w-auto text-xs sm:text-sm py-1.5 px-3 sm:py-2 sm:px-4">Cancelar</button>
            <button type="submit" className="btn btn-primary w-full xs:w-auto text-xs sm:text-sm py-1.5 px-3 sm:py-2 sm:px-4">
              {isEditing ? 'Atualizar' : 'Criar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<UsuariosApp />);


