function LogsAuditoriaApp() {
  const [user, setUser] = React.useState(null);
  const [logs, setLogs] = React.useState([]);
  const [filteredLogs, setFilteredLogs] = React.useState([]);
  const [filters, setFilters] = React.useState({
    usuario: '',
    tipoAcao: '',
    dataInicio: '',
    dataFim: ''
  });

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser || currentUser.role !== 'admin') {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadLogs();
  }, []);

  React.useEffect(() => {
    applyFilters();
  }, [filters, logs]);

  const loadLogs = async () => {
    try {
      const result = await dbListObjects('log_auditoria', 200);
      setLogs(result.items);
    } catch (error) {
      console.error('Error loading audit logs:', error);
      setLogs([]);
    }
  };

  const applyFilters = () => {
    let filtered = [...logs];

    if (filters.usuario) {
      filtered = filtered.filter(log => 
        log.objectData.usuario.toLowerCase().includes(filters.usuario.toLowerCase())
      );
    }

    if (filters.tipoAcao) {
      filtered = filtered.filter(log => 
        log.objectData.tipoAcao === filters.tipoAcao
      );
    }

    if (filters.dataInicio) {
      filtered = filtered.filter(log => 
        new Date(log.objectData.timestamp) >= new Date(filters.dataInicio)
      );
    }

    if (filters.dataFim) {
      const endDate = new Date(filters.dataFim);
      endDate.setHours(23, 59, 59, 999);
      filtered = filtered.filter(log => 
        new Date(log.objectData.timestamp) <= endDate
      );
    }

    setFilteredLogs(filtered);
  };

  const exportLogs = () => {
    const headers = ['Data/Hora', 'Usuário', 'Departamento', 'Tipo de Ação', 'Detalhes'];
    const rows = filteredLogs.map(log => [
      new Date(log.objectData.timestamp).toLocaleString('pt-BR'),
      log.objectData.usuario,
      log.objectData.departamento,
      getActionLabel(log.objectData.tipoAcao),
      log.objectData.detalhes
    ]);
    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `logs_auditoria_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const getActionLabel = (action) => {
    const labels = {
      login: 'Login',
      logout: 'Logout',
      criar_bem: 'Criar Bem',
      editar_bem: 'Editar Bem',
      excluir_bem: 'Excluir Bem',
      criar_requisicao: 'Criar Requisição',
      aprovar_requisicao: 'Aprovar Requisição',
      rejeitar_requisicao: 'Rejeitar Requisição',
      criar_usuario: 'Criar Usuário',
      editar_usuario: 'Editar Usuário',
      desativar_usuario: 'Desativar Usuário',
      ativar_usuario: 'Ativar Usuário',
      remover_usuario: 'Remover Usuário',
      alterar_senha: 'Alterar Senha',
      exportar_relatorio: 'Exportar Relatório',
      criar_movimentacao: 'Criar Movimentação',
      criar_departamento: 'Criar Departamento',
      remover_departamento: 'Remover Departamento',
      criar_backup: 'Criar Backup',
      restaurar_backup: 'Restaurar Backup',
      ativar_backup_auto: 'Ativar Backup Automático',
      desativar_backup_auto: 'Desativar Backup Automático'
    };
    return labels[action] || action;
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      <main className="flex-grow p-6">
        <button onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4">
          <div className="icon-arrow-left text-lg"></div>
          <span>Voltar</span>
        </button>

        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Logs de Auditoria</h1>
          <button onClick={exportLogs} className="btn bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 rounded-lg flex items-center gap-2">
            <div className="icon-download text-lg"></div>
            <span>Exportar</span>
          </button>
        </div>

        <div className="card mb-6">
          <h3 className="font-bold mb-4">Filtros</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <input type="text" className="input-field" placeholder="Usuário..." 
              value={filters.usuario} onChange={(e) => setFilters({...filters, usuario: e.target.value})} />
            <select className="input-field" value={filters.tipoAcao} 
              onChange={(e) => setFilters({...filters, tipoAcao: e.target.value})}>
              <option value="">Todas as ações</option>
              <option value="login">Login</option>
              <option value="logout">Logout</option>
              <option value="criar_bem">Criar Bem</option>
              <option value="editar_bem">Editar Bem</option>
              <option value="excluir_bem">Excluir Bem</option>
              <option value="criar_requisicao">Criar Requisição</option>
              <option value="aprovar_requisicao">Aprovar Requisição</option>
              <option value="rejeitar_requisicao">Rejeitar Requisição</option>
              <option value="criar_usuario">Criar Usuário</option>
              <option value="exportar_relatorio">Exportar Relatório</option>
              <option value="criar_backup">Criar Backup</option>
              <option value="restaurar_backup">Restaurar Backup</option>
              <option value="ativar_backup_auto">Ativar Backup Automático</option>
              <option value="desativar_backup_auto">Desativar Backup Automático</option>
            </select>
            <input type="date" className="input-field" value={filters.dataInicio} 
              onChange={(e) => setFilters({...filters, dataInicio: e.target.value})} />
            <input type="date" className="input-field" value={filters.dataFim} 
              onChange={(e) => setFilters({...filters, dataFim: e.target.value})} />
          </div>
          <p className="text-sm text-gray-500 mt-3">{filteredLogs.length} registros encontrados</p>
        </div>

        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-2">Data/Hora</th>
                <th className="text-left py-3 px-2">Usuário</th>
                <th className="text-left py-3 px-2">Departamento</th>
                <th className="text-left py-3 px-2">Ação</th>
                <th className="text-left py-3 px-2">Detalhes</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.map(log => (
                <tr key={log.objectId} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-2">{new Date(log.objectData.timestamp).toLocaleString('pt-BR')}</td>
                  <td className="py-3 px-2 font-medium">{log.objectData.usuario}</td>
                  <td className="py-3 px-2">{log.objectData.departamento}</td>
                  <td className="py-3 px-2">
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                      {getActionLabel(log.objectData.tipoAcao)}
                    </span>
                  </td>
                  <td className="py-3 px-2">{log.objectData.detalhes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<LogsAuditoriaApp />);

