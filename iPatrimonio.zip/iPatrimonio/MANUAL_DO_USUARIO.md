﻿# iPatrimônio - Manual do Usuário

## Bem-vindo ao iPatrimônio
O Sistema Integrado de Gestão de Patrimônio da UCM-FADIR foi desenhado para facilitar a solicitação, aprovação e monitoramento de bens materiais e consumíveis.

## Primeiros Passos
1. **Login**: Acesse a plataforma com seu E-mail e Senha fornecidos pela Administração.
2. **Dashboard**: A tela inicial exibirá o panorama do patrimônio, suas requisições e ações rápidas (se aplicável ao seu nível de acesso).

## Perfis de Acesso
- **Usuário Padrão**: Pode visualizar bens do seu departamento e abrir requisições.
- **Departamento de Patrimônio**: Gerencia o estoque, cadastra novos bens e encaminha requisições para a Administração.
- **Administração**: Aprova requisições, abates e supervisiona as movimentações. Recebe e despacha os Termos de Entrega.

## Fluxo de Requisição de Bem
1. Vá até o módulo **Requisições**.
2. Clique em **Nova Requisição** e preencha os itens desejados.
3. O Departamento de Patrimônio fará o encaminhamento.
4. A Administração analisará para aprovação ou rejeição.
5. Após aprovado, o documento **Termo de Entrega** será gerado automaticamente, podendo ser impresso e assinado pelas 3 partes: Administração, Patrimônio e Departamento Solicitante.

## Relatórios e Auditoria
Acesse a aba **Relatórios** (apenas Admin/Patrimônio) para extrair dados analíticos. A aba de **Auditoria** mantém um registro inalterável de quem realizou cada ação, garantindo total transparência.

