function RequisicoesApp() {
  const [user, setUser] = React.useState(null);
  const [requisicoes, setRequisicoes] = React.useState([]);
  const [filteredRequisicoes, setFilteredRequisicoes] = React.useState([]);
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');
  const [showEditModal, setShowEditModal] = React.useState(false);
  const [editingRequisicao, setEditingRequisicao] = React.useState(null);
  const [userNames, setUserNames] = React.useState({});
  const [activeTab, setActiveTab] = React.useState('novas');
  const [filters, setFilters] = React.useState({
    periodo: 'todos',
    departamento: '',
    usuario: ''
  });

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    if (currentUser.department !== 'Administração') {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadRequisicoes();
  }, []);

  React.useEffect(() => {
    applyFilters();
  }, [filters, requisicoes]);

  const loadRequisicoes = async () => {
    const result = await dbListObjects('requisicao', 100);
    const encaminhadas = result.items.filter(r => 
      r.objectData.status === 'encaminhada' || 
      r.objectData.status === 'aprovada' || 
      r.objectData.status === 'rejeitada' || 
      r.objectData.status === 'pendente'
    );
    setRequisicoes(encaminhadas);
    
    // Load user names
    try {
      const users = await dbListObjects('usuario', 200, true);
      const names = {};
      users.items.forEach(u => {
        if (u.objectData.email) {
          names[u.objectData.email] = u.objectData.nome;
        }
      });
      setUserNames(names);
    } catch (error) {
      console.error('Error loading user names:', error);
    }
  };

  const applyFilters = () => {
    let filtered = [...requisicoes];
    const now = new Date();

    if (filters.periodo !== 'todos') {
      filtered = filtered.filter(req => {
        const reqDate = new Date(req.createdAt);
        if (filters.periodo === 'dia') {
          return reqDate.toDateString() === now.toDateString();
        } else if (filters.periodo === 'semana') {
          const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          return reqDate >= weekAgo;
        } else if (filters.periodo === 'mes') {
          return reqDate.getMonth() === now.getMonth() && reqDate.getFullYear() === now.getFullYear();
        } else if (filters.periodo === 'semestre') {
          const semester = Math.floor(now.getMonth() / 6);
          const reqSemester = Math.floor(reqDate.getMonth() / 6);
          return reqSemester === semester && reqDate.getFullYear() === now.getFullYear();
        } else if (filters.periodo === 'ano') {
          return reqDate.getFullYear() === now.getFullYear();
        }
        return true;
      });
    }

    if (filters.departamento) {
      filtered = filtered.filter(req => req.objectData.departamento === filters.departamento);
    }

    if (filters.usuario.trim()) {
      const userLower = filters.usuario.toLowerCase();
      filtered = filtered.filter(req => 
        req.objectData.solicitante.toLowerCase().includes(userLower)
      );
    }

    setFilteredRequisicoes(filtered);
  };


  const handleEdit = (requisicao) => {
    setEditingRequisicao(requisicao);
    setShowEditModal(true);
  };

  const handleSaveEdit = async (updatedItens, motivoEdicao) => {
    try {
      await dbUpdateObject('requisicao', editingRequisicao.objectId, {
        ...editingRequisicao.objectData,
        itensDetalhados: updatedItens,
        editada: true,
        motivoEdicao: motivoEdicao || '',
        dataEdicao: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });

      const mensagemNotificacao = motivoEdicao 
        ? `Sua requisição foi editada pela administração. Motivo: ${motivoEdicao}`
        : 'Sua requisição foi editada pela administração. As quantidades foram ajustadas.';

      await dbCreateObject('notificacao', {
        userId: editingRequisicao.objectData.userId,
        message: mensagemNotificacao,
        type: 'info',
        read: false,
        requisicaoId: editingRequisicao.objectId,
        createdAt: new Date().toISOString()
      });
      
      setAlertMessage('Requisição editada com sucesso!');
      setAlertType('success');
      setShowAlert(true);
      setShowEditModal(false);
      loadRequisicoes();
    } catch (error) {
      console.error('Error editing requisition:', error);
      setAlertMessage('Erro ao editar requisição: ' + error.message);
      setAlertType('error');
      setShowAlert(true);
    }
  };

  const handleMarkPending = async (reqId) => {
    try {
      const req = await dbGetObject('requisicao', reqId);
      await dbUpdateObject('requisicao', reqId, {
        ...req.objectData,
        status: 'pendente',
        updatedAt: new Date().toISOString()
      });
      
      setAlertMessage('Requisição marcada como pendente!');
      setAlertType('success');
      setShowAlert(true);
      loadRequisicoes();
    } catch (error) {
      console.error('Error marking as pending:', error);
      setAlertMessage('Erro ao marcar como pendente: ' + error.message);
      setAlertType('error');
      setShowAlert(true);
    }
  };

  const handleApprove = async (reqId) => {
    try {
      const req = await dbGetObject('requisicao', reqId);
      
      // Use FIFO allocator to assign bens
      const { bensAtribuidos, itensPendentes } = await allocateBensToRequisicao(
        reqId,
        req.objectData.itensDetalhados || [],
        req.objectData.emailSolicitante,
        req.objectData.departamento
      );
      
      await updateRequisicaoStatus(reqId, 'aprovada', '');
      await dbUpdateObject('requisicao', reqId, {
        ...req.objectData,
        status: 'aprovada',
        bensAtribuidos: bensAtribuidos,
        dataAprovacao: new Date().toISOString(),
        aprovadoPor: user.name
      });
      
      try {
        const year = new Date().getFullYear();
        const existingTermos = await dbListObjects('termo_entrega', 100);
        const num = (existingTermos.items.length + 1).toString().padStart(3, '0');
        const numeroTermo = `${num}/${year}`;
        
        await dbCreateObject('termo_entrega', {
          numeroTermo: numeroTermo,
          dataEntrega: new Date().toISOString().split('T')[0],
          departamento: req.objectData.departamento,
          localDestino: req.objectData.departamento,
          responsavelEntrega: req.objectData.encaminhadaPor || 'Património FADIR',
          cargoEntrega: 'Administrador Patrimonio',
          responsavelRecebimento: req.objectData.solicitante,
          cargoRecebimento: `Responsável do Departamento de ${req.objectData.departamento}`,
          requisicaoId: reqId,
          registradoPor: user.name,
          aprovadoPor: user.name,
          createdAt: new Date().toISOString()
        });
        console.log(`✓ Termo de entrega criado: ${numeroTermo}`);
      } catch (termoError) {
        console.error('Error creating termo (non-critical):', termoError);
      }
      
      try {
        if (req.objectData.itensDetalhados && req.objectData.itensDetalhados.length > 0) {
          for (const item of req.objectData.itensDetalhados) {
            if (!item.descricao || !item.quantidade) continue;
            
            await dbCreateObject('saida_material', {
              dataSaida: new Date().toISOString().split('T')[0],
              numeroDocumento: reqId,
              descricaoMaterial: item.descricao,
              quantidade: parseInt(item.quantidade) || 0,
              departamentoDestino: req.objectData.departamento,
              responsavelRequisicao: req.objectData.solicitante,
              observacoes: `Requisição aprovada - ${req.objectData.motivo || ''}`,
              registradoPor: user.name,
              requisicaoId: reqId,
              createdAt: new Date().toISOString()
            });
          }
          console.log(`✓ Registros de controle de saída criados`);
        }
      } catch (saidaError) {
        console.error('Error creating saida records (non-critical):', saidaError);
      }
      
      try {
        await dbCreateObject('notificacao', {
          tipo: 'requisicao_aprovada',
          destinatario: 'patrimonio',
          mensagem: `Requisição aprovada pela Administração - Solicitante: ${req.objectData.solicitante} (${req.objectData.departamento})`,
          lida: false,
          requisicaoId: reqId
        });
        
        if (req.objectData.solicitante !== user.name && req.objectData.solicitante !== user.username) {
          await dbCreateObject('notificacao', {
            tipo: 'requisicao_aprovada',
            destinatario: req.objectData.solicitante,
            mensagem: `Sua requisição foi aprovada pela Administração`,
            lida: false,
            requisicaoId: reqId
          });
        }
      } catch (notifError) {
        console.error('Error creating notification (non-critical):', notifError);
      }
      
      setAlertMessage('Requisição aprovada com sucesso!');
      setAlertType('success');
      setShowAlert(true);
      loadRequisicoes();
    } catch (error) {
      console.error('Error approving requisition:', error);
      setAlertMessage('Erro ao aprovar requisição: ' + error.message);
      setAlertType('error');
      setShowAlert(true);
    }
  };



  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} currentPage="requisicoes" />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      {showEditModal && (
        <EditModal
          requisicao={editingRequisicao}
          onSave={handleSaveEdit}
          onClose={() => setShowEditModal(false)}
        />
      )}
      <main className="flex-grow p-4 md:p-6">
          <button
            onClick={() => window.location.href = 'dashboard.html'}
            className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
          >
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar</span>
          </button>
          
          <div className="flex justify-between items-center mb-4 md:mb-6">
            <h1 className="text-xl md:text-3xl font-bold">Requisições</h1>
          </div>

          <div className="card mb-4 md:mb-6">
            <h3 className="font-bold mb-3 md:mb-4 text-sm md:text-base">Filtros de Pesquisa</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Período</label>
                <select className="input-field" value={filters.periodo}
                  onChange={(e) => setFilters({...filters, periodo: e.target.value})}>
                  <option value="todos">Todos</option>
                  <option value="dia">Hoje</option>
                  <option value="semana">Esta Semana</option>
                  <option value="mes">Este Mês</option>
                  <option value="semestre">Este Semestre</option>
                  <option value="ano">Este Ano</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Departamento</label>
                <select className="input-field" value={filters.departamento}
                  onChange={(e) => setFilters({...filters, departamento: e.target.value})}>
                  <option value="">Todos</option>
                  <option value="Limpeza">Limpeza</option>
                  <option value="Biblioteca">Biblioteca</option>
                  <option value="Secretaria">Secretaria</option>
                  <option value="Registro Acadêmico">Registro Acadêmico</option>
                  <option value="Sala dos Professores">Sala dos Professores</option>
                  <option value="Informática">Informática</option>
                  <option value="Controle de Crédito">Controle de Crédito</option>
                  <option value="Departamento de Patrimônio">Departamento de Patrimônio</option>
                  <option value="Administração">Administração</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Usuário</label>
                <input type="text" className="input-field" placeholder="Nome do solicitante..."
                  value={filters.usuario} onChange={(e) => setFilters({...filters, usuario: e.target.value})} />
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-3">{filteredRequisicoes.length} requisições encontradas</p>
          </div>

          <div className="flex gap-4 mb-4 border-b">
            <button
              onClick={() => setActiveTab('novas')}
              className={`py-2 px-4 font-semibold text-sm border-b-2 ${activeTab === 'novas' ? 'border-[var(--primary-color)] text-[var(--primary-color)]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
            >
              Novas / Pendentes
            </button>
            <button
              onClick={() => setActiveTab('historico')}
              className={`py-2 px-4 font-semibold text-sm border-b-2 ${activeTab === 'historico' ? 'border-[var(--primary-color)] text-[var(--primary-color)]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
            >
              Histórico (Aprovadas/Rejeitadas)
            </button>
          </div>

          <div className="space-y-4">
            {filteredRequisicoes.filter(req => 
              activeTab === 'novas' 
                ? (req.objectData.status === 'encaminhada' || req.objectData.status === 'pendente')
                : (req.objectData.status === 'aprovada' || req.objectData.status === 'rejeitada')
            ).map(req => (
              <RequisicaoCard 
                key={req.objectId} 
                requisicao={req} 
                userNames={userNames}
                onApprove={handleApprove}
                onEdit={handleEdit}
                onMarkPending={handleMarkPending}
              />
            ))}
            {filteredRequisicoes.filter(req => 
              activeTab === 'novas' 
                ? (req.objectData.status === 'encaminhada' || req.objectData.status === 'pendente')
                : (req.objectData.status === 'aprovada' || req.objectData.status === 'rejeitada')
            ).length === 0 && (
              <div className="text-center py-8 text-gray-500 bg-white rounded-xl shadow-sm border">
                Nenhuma requisição encontrada nesta aba.
              </div>
            )}
          </div>
        </main>
        <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
          © 2026 - iPatrimônio | UCM-FADIR
        </footer>
      </div>
  );
}

function RequisicaoCard({ requisicao, userNames, onApprove, onEdit, onMarkPending }) {
  const { objectId, objectData } = requisicao;
  const statusColors = {
    pendente: 'bg-gray-50 text-gray-700 border border-gray-200',
    encaminhada: 'bg-blue-100 text-blue-800',
    aprovada: 'bg-blue-50 text-[var(--primary-color)] border border-blue-200',
    rejeitada: 'bg-gray-200 text-gray-800 border border-gray-300'
  };

  const statusLabels = {
    pendente: 'Pendente',
    encaminhada: 'Encaminhada',
    aprovada: 'Aprovada',
    rejeitada: 'Rejeitada'
  };

  const formatItensDetalhados = () => {
    if (!objectData.itensDetalhados || objectData.itensDetalhados.length === 0) {
      return Array.isArray(objectData.bens) ? objectData.bens.join(', ') : objectData.bens;
    }
    return objectData.itensDetalhados.map(item => 
      `${item.descricao} (${item.quantidade})`
    ).join(', ');
  };

  const displayName = userNames[objectData.solicitante] || objectData.solicitante;

  return (
    <div className="card">
      <div className="flex flex-col gap-2 mb-4">
        <div className="flex justify-between items-start gap-2">
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-base break-words">{displayName}</h3>
            <p className="text-xs text-gray-500 mt-1 break-words">{objectData.departamento}</p>
          </div>
          <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColors[objectData.status]} whitespace-nowrap flex-shrink-0`}>
            {statusLabels[objectData.status] || objectData.status}
          </span>
        </div>
      </div>
      <p className="text-sm text-gray-700 mb-4 break-words">{objectData.motivo}</p>
      <div className="text-xs sm:text-sm text-gray-700 bg-gray-50 p-3 rounded-lg border mb-3">
        <p className="font-semibold text-gray-800 mb-1 border-b pb-1">Bens solicitados:</p>
        <p className="text-gray-700">{formatItensDetalhados()}</p>
      </div>
      {objectData.editada && (
        <div className="bg-blue-50 border-l-4 border-blue-500 p-2 mb-4">
          <p className="text-xs font-semibold text-blue-800">Requisição editada pela administração</p>
          {objectData.motivoEdicao && (
            <p className="text-xs text-blue-700 mt-1">Motivo: {objectData.motivoEdicao}</p>
          )}
        </div>
      )}
      {objectData.status === 'encaminhada' && (
        <div className="flex flex-col gap-2">
          <button onClick={() => onEdit(requisicao)} className="btn bg-[var(--primary-color)] text-white hover:opacity-90 w-full text-sm py-2.5">
            Editar Requisição
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => onMarkPending(objectId)} className="btn bg-gray-500 text-white hover:bg-gray-600 text-sm py-2.5">
              Marcar Pendente
            </button>
            <button onClick={() => onApprove(objectId)} className="btn bg-[var(--primary-color)] text-white hover:opacity-90 text-sm py-2.5">
              Aprovar
            </button>
          </div>
        </div>
      )}
      {objectData.status === 'pendente' && (
        <button onClick={() => onApprove(objectId)} className="btn bg-[var(--primary-color)] text-white hover:opacity-90 w-full text-sm py-2.5">
          Aprovar
        </button>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<RequisicoesApp />);

