function VerMapaControleSaidaApp() {
  const [user, setUser] = React.useState(null);
  const [registros, setRegistros] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [searchTerm, setSearchTerm] = React.useState('');

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    // Allow admin and Administração department
    if (currentUser.role !== 'admin' && currentUser.department !== 'Administração') {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadRegistros();
  }, []);

  const loadRegistros = async () => {
    try {
      setLoading(true);
      const result = await dbListObjects('saida_material', 100, true);
      setRegistros(result.items || []);
    } catch (error) {
      console.error('Error loading registros:', error);
      setRegistros([]);
    } finally {
      setLoading(false);
    }
  };

  const filteredRegistros = registros.filter(reg => {
    if (!reg.objectData) return false;
    const search = searchTerm.toLowerCase();
    const numeroGuia = (reg.objectData.numeroGuiaSaida || '').toLowerCase();
    const descricao = (reg.objectData.descricaoMaterial || '').toLowerCase();
    const requisitante = (reg.objectData.requisitante || '').toLowerCase();
    return numeroGuia.includes(search) || descricao.includes(search) || requisitante.includes(search);
  });

  if (!user) return null;

  return (
    <div className="bg-gray-100 min-h-screen flex flex-col">
      <Header user={user} />
      
      <main className="flex-grow p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-800">Ver Controle de Saída</h1>
            <button onClick={() => window.location.href = 'dashboard.html'} className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300">
              Voltar
            </button>
          </div>

          <div className="card mb-6">
            <input
              type="text"
              placeholder="Pesquisar por número da guia, descrição ou requisitante..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-field"
            />
          </div>

          {loading ? (
            <div className="card text-center py-12">
              <p className="text-gray-500 text-lg">Carregando...</p>
            </div>
          ) : filteredRegistros.length === 0 ? (
            <div className="card text-center py-12">
              <div className="icon-inbox text-5xl text-gray-300 mx-auto mb-4 w-fit"></div>
              <p className="text-gray-500 text-lg">Nenhum registro encontrado</p>
            </div>
          ) : (
            <div className="card overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Nº Guia</th>
                    <th className="text-left py-3 px-4">Data</th>
                    <th className="text-left py-3 px-4">Descrição</th>
                    <th className="text-left py-3 px-4">Quantidade</th>
                    <th className="text-left py-3 px-4">Requisitante</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredRegistros.map(reg => {
                    const data = reg.objectData.dataSaida ? new Date(reg.objectData.dataSaida) : null;
                    const dataFormatada = data && !isNaN(data.getTime()) 
                      ? data.toLocaleDateString('pt-BR')
                      : '-';
                    
                    return (
                      <tr key={reg.objectId} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4">{reg.objectData.numeroGuiaSaida || '-'}</td>
                        <td className="py-3 px-4">{dataFormatada}</td>
                        <td className="py-3 px-4">{reg.objectData.descricaoMaterial || '-'}</td>
                        <td className="py-3 px-4">{reg.objectData.quantidade || 0}</td>
                        <td className="py-3 px-4">{reg.objectData.requisitante || '-'}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>

      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<VerMapaControleSaidaApp />);

