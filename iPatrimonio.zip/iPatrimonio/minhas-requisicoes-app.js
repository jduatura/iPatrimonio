function MinhasRequisicoesApp() {
  const [user, setUser] = React.useState(null);
  const [requisicoes, setRequisicoes] = React.useState([]);
  const [termos, setTermos] = React.useState({});

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    setUser(currentUser);
    loadRequisicoes(currentUser);
  }, []);

  const loadRequisicoes = async (currentUser) => {
    try {
      const result = await dbListObjects('requisicao', 100);
      const userName = currentUser.username || currentUser.name;
      const minhas = result.items.filter(r => {
        const solicitante = r.objectData.solicitante;
        return solicitante === currentUser.name || 
               solicitante === currentUser.username || 
               solicitante === userName;
      });
      setRequisicoes(minhas);

      try {
        const termosRes = await dbListObjects('termo_entrega', 200, true);
        const termosMap = {};
        if (termosRes && termosRes.items) {
          termosRes.items.forEach(t => {
            if (t.objectData && t.objectData.requisicaoId) {
              termosMap[t.objectData.requisicaoId] = t;
            }
          });
        }
        setTermos(termosMap);
      } catch (errTermos) {
        console.error('Erro ao carregar termos de entrega:', errTermos);
      }
    } catch (error) {
      console.error('Error loading requisicoes:', error);
      setRequisicoes([]);
    }
  };

  const handleConfirmar = async (reqId, termo, reqData) => {
    try {
      let termoObj = termo;
      if (!termoObj) {
        const year = new Date().getFullYear();
        const existingTermos = await dbListObjects('termo_entrega', 100);
        const num = (existingTermos.items.length + 1).toString().padStart(3, '0');
        const numeroTermo = `${num}/${year}`;
        termoObj = await dbCreateObject('termo_entrega', {
          numeroTermo: numeroTermo,
          dataEntrega: new Date().toISOString().split('T')[0],
          departamento: reqData.departamento,
          localDestino: reqData.departamento,
          responsavelEntrega: reqData.encaminhadaPor || 'Património FADIR',
          cargoEntrega: 'Administrador Patrimonio',
          responsavelRecebimento: reqData.solicitante,
          cargoRecebimento: `Responsável do Departamento de ${reqData.departamento}`,
          requisicaoId: reqId,
          registradoPor: user.name,
          aprovadoPor: reqData.aprovadoPor || user.name,
          confirmado: true,
          confirmadoEm: new Date().toISOString(),
          createdAt: new Date().toISOString()
        });
      } else {
        await dbUpdateObject('termo_entrega', termoObj.objectId, {
          ...termoObj.objectData,
          confirmado: true,
          confirmadoEm: new Date().toISOString()
        });
      }

      await dbUpdateObject('requisicao', reqId, {
        ...reqData,
        confirmadoRecebimento: true,
        confirmadoRecebimentoEm: new Date().toISOString()
      });

      await loadRequisicoes(user);
    } catch (error) {
      console.error('Erro ao confirmar recebimento:', error);
      alert('Ocorreu um erro ao confirmar o recebimento.');
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} currentPage="minhas-requisicoes" />
      <main className="flex-grow p-6">
          <button
            onClick={() => window.location.href = 'dashboard.html'}
            className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
          >
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar</span>
          </button>
          <h1 className="text-3xl font-bold mb-6">Minhas Requisições</h1>
          <div className="space-y-4">
            {requisicoes.length === 0 ? (
              <div className="card text-center text-gray-500">
                Você ainda não fez nenhuma requisição.
              </div>
            ) : (
              requisicoes.map(req => (
                <RequisicaoCard 
                  key={req.objectId} 
                  requisicao={req.objectData} 
                  reqId={req.objectId} 
                  termo={termos[req.objectId]}
                  onConfirmar={handleConfirmar}
                />
              ))
            )}
          </div>
        </main>
        <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
          © 2026 - iPatrimônio | UCM-FADIR
        </footer>
      </div>
  );
}

function RequisicaoCard({ requisicao, reqId, termo, onConfirmar }) {
  const statusColors = {
    pendente: 'bg-gray-50 text-gray-700 border border-gray-200',
    aprovada: 'bg-blue-50 text-[var(--primary-color)] border border-blue-200',
    rejeitada: 'bg-gray-200 text-gray-800 border border-gray-300'
  };

  const isConfirmado = Boolean(
    (termo && termo.objectData && termo.objectData.confirmado) || 
    requisicao.confirmadoRecebimento
  );

  return (
    <div className="card">
      <div className="flex flex-col sm:flex-row justify-between items-start gap-3 mb-4">
        <div className="flex-1">
          <h3 className="font-bold text-base sm:text-lg">Requisição</h3>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            {requisicao.dataRequisicao ? new Date(requisicao.dataRequisicao).toLocaleDateString('pt-BR') : new Date(requisicao.createdAt).toLocaleDateString('pt-BR')}
          </p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[requisicao.status]} whitespace-nowrap`}>
          {requisicao.status.charAt(0).toUpperCase() + requisicao.status.slice(1)}
        </span>
      </div>

      {requisicao.editada && (
        <div className="bg-blue-50 border-l-4 border-blue-500 p-3 mb-4">
          <p className="text-sm font-semibold text-blue-800 mb-1">Requisição editada pela administração</p>
          {requisicao.motivoEdicao && (
            <p className="text-sm text-blue-700">Motivo: {requisicao.motivoEdicao}</p>
          )}
        </div>
      )}

      <p className="text-sm text-gray-700 mb-4 break-words">{requisicao.motivo}</p>
      
      {requisicao.itensDetalhados && requisicao.itensDetalhados.length > 0 ? (
        <div className="text-xs sm:text-sm text-gray-700 bg-gray-50 p-3 rounded-lg border mb-2">
          <p className="font-semibold text-gray-800 mb-2 border-b pb-1">Bens solicitados:</p>
          <ul className="space-y-1">
            {requisicao.itensDetalhados.map((item, idx) => {
              const nomeItem = item.nome || item.descricao || 'Item sem nome';
              const qtd = item.quantidadeSolicitada !== undefined ? item.quantidadeSolicitada : (item.quantidade || 1);
              return (
                <li key={idx} className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[var(--primary-color)] font-bold">•</span>
                  <span className="font-medium text-gray-800">{nomeItem}</span>
                  <span className="text-gray-500 font-mono text-xs">(Qtd: {qtd})</span>
                  {requisicao.status === 'aprovada' && item.quantidadeAprovada !== undefined && (
                    <span className="text-green-700 font-semibold text-xs bg-gray-50 px-1.5 py-0.5 rounded border border-gray-200">
                      Aprovada: {item.quantidadeAprovada}
                    </span>
                  )}
                  {item.observacao && <span className="text-gray-500 italic text-xs">- {item.observacao}</span>}
                </li>
              );
            })}
          </ul>
        </div>
      ) : (
        <div className="text-xs sm:text-sm text-gray-700 bg-gray-50 p-3 rounded-lg border mb-2">
          <p className="font-semibold text-gray-800 mb-1 border-b pb-1">Bens solicitados:</p>
          <p className="text-gray-700">
            {Array.isArray(requisicao.bens) ? requisicao.bens.join(', ') : (requisicao.bens || 'Nenhum bem especificado')}
          </p>
        </div>
      )}

      {requisicao.status === 'aprovada' && (
        <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-3 border-t">
          <div>
            {isConfirmado ? (
              <span className="text-xs font-semibold text-green-700 bg-green-50 border border-green-200 px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-sm">
                <span>✓</span> Recebimento Confirmado
              </span>
            ) : (
              <button
                onClick={() => onConfirmar(reqId, termo, requisicao)}
                className="btn bg-[var(--primary-color)] text-white hover:bg-blue-800 flex items-center text-xs sm:text-sm shadow"
              >
                Confirmo que recebi os bens
              </button>
            )}
          </div>
          <div>
            {isConfirmado ? (
              <button
                onClick={() => {
                  const termoId = termo ? termo.objectId : null;
                  if (termoId) {
                    window.open(`imprimir-termo.html?id=${termoId}`, '_blank');
                  }
                }}
                className="btn bg-[var(--primary-color)] text-white hover:bg-blue-800 flex items-center gap-1.5 text-xs sm:text-sm shadow"
              >
                <span>🖨️</span> Imprimir Termo
              </button>
            ) : (
              <button
                disabled
                title="Confirme o recebimento para emitir e imprimir o termo"
                className="btn bg-gray-200 text-gray-400 cursor-not-allowed flex items-center gap-1.5 text-xs sm:text-sm"
              >
                <span>🖨️</span> Imprimir Termo
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<MinhasRequisicoesApp />);

