function TermoEntregaApp() {
  const [user, setUser] = React.useState(null);
  const [termos, setTermos] = React.useState([]);
  const [showModal, setShowModal] = React.useState(false);
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    const isAdministracao = currentUser.department === 'Administração';
    if (currentUser.role !== 'patrimonio' && !isAdministracao) {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadTermos();
  }, []);

  const loadTermos = async () => {
    try {
      setLoading(true);
      const result = await dbListObjects('termo_entrega', 100);
      setTermos(result.items || []);
    } catch (error) {
      console.error('Error loading termos:', error);
      setTermos([]);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTermo = async (data) => {
    try {
      const termo = await dbCreateObject('termo_entrega', {
        ...data,
        registradoPor: user.name,
        createdAt: new Date().toISOString()
      });
      
      // Registrar automaticamente no Mapa de Controle de Saída
      await dbCreateObject('mapa_controle_saida', {
        termoId: termo.objectId,
        numeroTermo: data.numeroTermo,
        dataSaida: data.dataEntrega,
        departamento: data.departamento,
        localDestino: data.localDestino,
        responsavelEntrega: data.responsavelEntrega,
        responsavelRecebimento: data.responsavelRecebimento,
        status: 'Entregue',
        registradoPor: user.name,
        createdAt: new Date().toISOString()
      });
      
      await logAuditAction('criar_termo_entrega', `Termo criado: ${data.numeroTermo} - Saída registrada automaticamente`, user);
      setAlertMessage('Termo criado e saída registrada com sucesso!');
      setAlertType('success');
      setShowAlert(true);
      setShowModal(false);
      loadTermos();
    } catch (error) {
      console.error('Error creating termo:', error);
      setAlertMessage('Erro ao criar termo');
      setAlertType('error');
      setShowAlert(true);
    }
  };

  const handlePrint = (termoId) => {
    window.open(`imprimir-termo.html?id=${termoId}`, '_blank');
  };

  if (!user) return null;

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="icon-loader-2 text-4xl text-blue-600 animate-spin"></div>
          <p className="mt-4 text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      <main className="flex-grow p-3 sm:p-4 md:p-6">
        <button onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-1.5 md:gap-2 bg-gray-200 text-gray-700 px-2.5 md:px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-xs md:text-sm mb-3 md:mb-4">
          <div className="icon-arrow-left text-base md:text-lg"></div>
          <span>Voltar</span>
        </button>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4 md:mb-6">
          <h1 className="text-lg sm:text-xl md:text-3xl font-bold">Termo de Entrega e Recebimento</h1>
          <button onClick={() => setShowModal(true)} className="btn btn-primary flex items-center gap-1.5 md:gap-2 text-sm sm:text-base w-full sm:w-auto justify-center">
            <div className="icon-plus text-lg"></div>
            <span>Novo Termo</span>
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {termos.length === 0 ? (
            <div className="card text-center py-12">
              <div className="icon-file-text text-5xl text-gray-300 mx-auto mb-4"></div>
              <p className="text-gray-500 text-lg">Nenhum termo cadastrado</p>
              <p className="text-gray-400 text-sm mt-2">Clique em "Novo Termo" para criar o primeiro termo</p>
            </div>
          ) : (
            termos.map(termo => (
              <TermoCard key={termo.objectId} termo={termo} onPrint={handlePrint} />
            ))
          )}
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
      {showModal && <TermoModal onClose={() => setShowModal(false)} onSave={handleCreateTermo} />}
    </div>
  );
}

function TermoCard({ termo, onPrint }) {
  const data = termo.objectData;
  
  return (
    <div className="card hover:shadow-lg transition-shadow">
      <div className="flex flex-col sm:flex-row justify-between items-start gap-2 sm:gap-0 mb-3 sm:mb-4">
        <div>
          <p className="font-bold text-base sm:text-lg md:text-xl text-blue-700">Termo N° {data.numeroTermo}</p>
          <p className="text-xs sm:text-sm text-gray-500 flex items-center gap-1 mt-1">
            <div className="icon-calendar text-sm sm:text-base"></div>
            {new Date(data.dataEntrega).toLocaleDateString('pt-BR')}
          </p>
        </div>
        <button onClick={() => onPrint(termo.objectId)}
          className="btn bg-blue-600 text-white hover:bg-blue-700 flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm w-full sm:w-auto justify-center">
          <div className="icon-printer text-base sm:text-lg"></div>
          <span>Imprimir</span>
        </button>
      </div>
      <div className="space-y-2 sm:space-y-3 border-t pt-2 sm:pt-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-4 text-xs sm:text-sm">
          <div>
            <p className="text-gray-500 text-[10px] sm:text-xs mb-1">Departamento:</p>
            <p className="font-medium text-xs sm:text-sm">{data.departamento}</p>
          </div>
          <div>
            <p className="text-gray-500 text-[10px] sm:text-xs mb-1">Local Destino:</p>
            <p className="font-medium text-xs sm:text-sm">{data.localDestino}</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-4 text-xs sm:text-sm pt-2 border-t">
          <div>
            <p className="text-blue-600 text-[10px] sm:text-xs font-semibold mb-1">Entregue por:</p>
            <p className="font-medium text-xs sm:text-sm">{data.responsavelEntrega}</p>
            <p className="text-[10px] sm:text-xs text-gray-500">{data.cargoEntrega}</p>
          </div>
          <div>
            <p className="text-green-600 text-[10px] sm:text-xs font-semibold mb-1">Recebido por:</p>
            <p className="font-medium text-xs sm:text-sm">{data.responsavelRecebimento}</p>
            <p className="text-[10px] sm:text-xs text-gray-500">{data.cargoRecebimento}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function TermoModal({ onClose, onSave }) {
  const [formData, setFormData] = React.useState({
    numeroTermo: '',
    dataEntrega: new Date().toISOString().split('T')[0],
    departamento: '',
    localDestino: '',
    responsavelEntrega: '',
    cargoEntrega: '',
    responsavelRecebimento: '',
    cargoRecebimento: ''
  });
  const [errors, setErrors] = React.useState({});
  const [touched, setTouched] = React.useState({});

  React.useEffect(() => {
    generateNumeroTermo();
  }, []);

  const generateNumeroTermo = () => {
    const year = new Date().getFullYear();
    const num = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    setFormData(prev => ({...prev, numeroTermo: `${num}/${year}`}));
  };

  const validateField = (name, value) => {
    let error = '';
    switch(name) {
      case 'numeroTermo':
        if (!value.trim()) error = 'Número do termo é obrigatório';
        else if (!/^\d{3}\/\d{4}$/.test(value)) error = 'Formato inválido (000/0000)';
        break;
      case 'dataEntrega':
        if (!value) error = 'Data é obrigatória';
        else if (new Date(value) > new Date()) error = 'Data não pode ser futura';
        break;
      case 'departamento':
        if (!value) error = 'Departamento é obrigatório';
        break;
      case 'localDestino':
        if (!value.trim()) error = 'Local de destino é obrigatório';
        break;
      case 'responsavelEntrega':
        if (!value.trim()) error = 'Nome é obrigatório';
        else if (value.trim().length < 3) error = 'Nome deve ter no mínimo 3 caracteres';
        else if (!/^[a-zA-ZÀ-ÿ\s]+$/.test(value)) error = 'Nome deve conter apenas letras';
        break;
      case 'cargoEntrega':
        if (!value.trim()) error = 'Cargo é obrigatório';
        else if (value.trim().length < 2) error = 'Cargo deve ter no mínimo 2 caracteres';
        break;
      case 'responsavelRecebimento':
        if (!value.trim()) error = 'Nome é obrigatório';
        else if (value.trim().length < 3) error = 'Nome deve ter no mínimo 3 caracteres';
        else if (!/^[a-zA-ZÀ-ÿ\s]+$/.test(value)) error = 'Nome deve conter apenas letras';
        break;
      case 'cargoRecebimento':
        if (!value.trim()) error = 'Cargo é obrigatório';
        else if (value.trim().length < 2) error = 'Cargo deve ter no mínimo 2 caracteres';
        break;
    }
    return error;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({...prev, [name]: value}));
    if (touched[name]) {
      setErrors(prev => ({...prev, [name]: validateField(name, value)}));
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    setTouched(prev => ({...prev, [name]: true}));
    setErrors(prev => ({...prev, [name]: validateField(name, value)}));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = {};
    Object.keys(formData).forEach(key => {
      const error = validateField(key, formData[key]);
      if (error) newErrors[key] = error;
    });
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setTouched(Object.keys(formData).reduce((acc, key) => ({...acc, [key]: true}), {}));
      return;
    }
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <h2 className="text-2xl font-bold mb-4">Novo Termo de Entrega e Recebimento</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">N° do Termo *</label>
              <input type="text" name="numeroTermo" className={`input-field ${errors.numeroTermo && touched.numeroTermo ? 'border-red-500' : ''}`}
                value={formData.numeroTermo} onChange={handleChange} onBlur={handleBlur} placeholder="000/0000" />
              {errors.numeroTermo && touched.numeroTermo && (
                <p className="text-red-500 text-xs mt-1">{errors.numeroTermo}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Data de Entrega *</label>
              <input type="date" name="dataEntrega" className={`input-field ${errors.dataEntrega && touched.dataEntrega ? 'border-red-500' : ''}`}
                value={formData.dataEntrega} onChange={handleChange} onBlur={handleBlur} />
              {errors.dataEntrega && touched.dataEntrega && (
                <p className="text-red-500 text-xs mt-1">{errors.dataEntrega}</p>
              )}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Departamento *</label>
            <select name="departamento" className={`input-field ${errors.departamento && touched.departamento ? 'border-red-500' : ''}`}
              value={formData.departamento} onChange={handleChange} onBlur={handleBlur}>
              <option value="">Selecione o departamento...</option>
              <option value="Limpeza">Limpeza</option>
              <option value="Biblioteca">Biblioteca</option>
              <option value="Secretaria">Secretaria</option>
              <option value="Registro Acadêmico">Registro Acadêmico</option>
              <option value="Sala dos Professores">Sala dos Professores</option>
              <option value="Informática">Informática</option>
              <option value="Controle de Crédito">Controle de Crédito</option>
              <option value="Departamento de Patrimônio">Departamento de Patrimônio</option>
              <option value="Administração">Administração</option>
              <option value="Diretor">Diretor</option>
              <option value="Pedagógico">Pedagógico</option>
              <option value="Recursos Humanos">Recursos Humanos</option>
              <option value="Relações Públicas">Relações Públicas</option>
            </select>
            {errors.departamento && touched.departamento && (
              <p className="text-red-500 text-xs mt-1">{errors.departamento}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Local de Destino *</label>
            <input type="text" name="localDestino" className={`input-field ${errors.localDestino && touched.localDestino ? 'border-red-500' : ''}`}
              value={formData.localDestino} onChange={handleChange} onBlur={handleBlur} placeholder="Ex: Sala 101, Biblioteca" />
            {errors.localDestino && touched.localDestino && (
              <p className="text-red-500 text-xs mt-1">{errors.localDestino}</p>
            )}
          </div>

          <div className="border-t pt-4">
            <h3 className="font-semibold mb-3 text-blue-700">Entregue por</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Nome Completo *</label>
                <input type="text" name="responsavelEntrega" className={`input-field ${errors.responsavelEntrega && touched.responsavelEntrega ? 'border-red-500' : ''}`}
                  value={formData.responsavelEntrega} onChange={handleChange} onBlur={handleBlur} placeholder="Nome de quem entrega" />
                {errors.responsavelEntrega && touched.responsavelEntrega && (
                  <p className="text-red-500 text-xs mt-1">{errors.responsavelEntrega}</p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Cargo/Função *</label>
                <input type="text" name="cargoEntrega" className={`input-field ${errors.cargoEntrega && touched.cargoEntrega ? 'border-red-500' : ''}`}
                  value={formData.cargoEntrega} onChange={handleChange} onBlur={handleBlur} placeholder="Ex: Gestor de Patrimônio" />
                {errors.cargoEntrega && touched.cargoEntrega && (
                  <p className="text-red-500 text-xs mt-1">{errors.cargoEntrega}</p>
                )}
              </div>
            </div>
          </div>

          <div className="border-t pt-4">
            <h3 className="font-semibold mb-3 text-green-700">Recebido por</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Nome Completo *</label>
                <input type="text" name="responsavelRecebimento" className={`input-field ${errors.responsavelRecebimento && touched.responsavelRecebimento ? 'border-red-500' : ''}`}
                  value={formData.responsavelRecebimento} onChange={handleChange} onBlur={handleBlur} placeholder="Nome de quem recebe" />
                {errors.responsavelRecebimento && touched.responsavelRecebimento && (
                  <p className="text-red-500 text-xs mt-1">{errors.responsavelRecebimento}</p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Cargo/Função *</label>
                <input type="text" name="cargoRecebimento" className={`input-field ${errors.cargoRecebimento && touched.cargoRecebimento ? 'border-red-500' : ''}`}
                  value={formData.cargoRecebimento} onChange={handleChange} onBlur={handleBlur} placeholder="Ex: Coordenador" />
                {errors.cargoRecebimento && touched.cargoRecebimento && (
                  <p className="text-red-500 text-xs mt-1">{errors.cargoRecebimento}</p>
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <button type="button" onClick={onClose} className="btn bg-gray-200 text-gray-800 hover:bg-gray-300">
              Cancelar
            </button>
            <button type="submit" className="btn btn-primary">Criar Termo</button>
          </div>
        </form>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<TermoEntregaApp />);

