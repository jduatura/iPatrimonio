function VerMovimentacaoApp() {
  const [user, setUser] = React.useState(null);
  const [movimentacoes, setMovimentacoes] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [searchTerm, setSearchTerm] = React.useState('');

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    // Allow admin and Administração department
    if (currentUser.role !== 'admin' && currentUser.department !== 'Administração') {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadMovimentacoes();
  }, []);

  const loadMovimentacoes = async () => {
    try {
      const result = await dbListObjects('movimentacao', 100, true);
      setMovimentacoes(result.items || []);
    } catch (error) {
      console.error('Error loading movimentacoes:', error);
      setMovimentacoes([]);
    } finally {
      setLoading(false);
    }
  };

  const filteredMovimentacoes = movimentacoes.filter(mov => {
    const search = searchTerm.toLowerCase();
    const data = mov.objectData;
    return data.numeroPatrimonio?.toLowerCase().includes(search) ||
           data.descricaoBem?.toLowerCase().includes(search) ||
           data.localOrigem?.toLowerCase().includes(search) ||
           data.localDestino?.toLowerCase().includes(search) ||
           data.responsavel?.toLowerCase().includes(search);
  });

  if (!user) return null;

  return (
    <div className="bg-gray-100 min-h-screen flex flex-col">
      <Header user={user} />
      
      <main className="flex-grow p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-800">Ver Movimentações</h1>
            <button onClick={() => window.location.href = 'dashboard.html'} className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300">
              Voltar
            </button>
          </div>

          <div className="card mb-6">
            <input
              type="text"
              placeholder="Pesquisar por patrimônio, descrição, origem ou destino..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-field"
            />
          </div>

          {loading ? (
            <div className="card text-center py-12">
              <p className="text-gray-500 text-lg">Carregando...</p>
            </div>
          ) : filteredMovimentacoes.length === 0 ? (
            <div className="card text-center py-12">
              <div className="icon-inbox text-5xl text-gray-300 mx-auto mb-4 w-fit"></div>
              <p className="text-gray-500 text-lg">Nenhuma movimentação encontrada</p>
            </div>
          ) : (
            <div className="card">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Patrimônio</th>
                      <th className="text-left py-3 px-4">Descrição</th>
                      <th className="text-left py-3 px-4">Origem</th>
                      <th className="text-left py-3 px-4">Destino</th>
                      <th className="text-left py-3 px-4">Data</th>
                      <th className="text-left py-3 px-4">Responsável</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredMovimentacoes.map(mov => {
                      const data = mov.objectData.dataMovimentacao ? new Date(mov.objectData.dataMovimentacao) : null;
                      const dataFormatada = data && !isNaN(data.getTime()) 
                        ? data.toLocaleDateString('pt-BR')
                        : '-';
                      
                      return (
                        <tr key={mov.objectId} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4">{mov.objectData.numeroPatrimonio || '-'}</td>
                          <td className="py-3 px-4">{mov.objectData.descricaoBem || '-'}</td>
                          <td className="py-3 px-4">{mov.objectData.localOrigem || '-'}</td>
                          <td className="py-3 px-4">{mov.objectData.localDestino || '-'}</td>
                          <td className="py-3 px-4">{dataFormatada}</td>
                          <td className="py-3 px-4">{mov.objectData.responsavel || '-'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<VerMovimentacaoApp />);

