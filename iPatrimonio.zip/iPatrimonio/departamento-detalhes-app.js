function DepartamentoDetalhesApp() {
  const [user, setUser] = React.useState(null);
  const [departamento, setDepartamento] = React.useState(null);
  const [bens, setBens] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    setUser(currentUser);
    
    const urlParams = new URLSearchParams(window.location.search);
    const deptCodigo = urlParams.get('codigo');
    if (deptCodigo) {
      loadDepartamento(deptCodigo);
    } else {
      window.location.href = 'departamentos.html';
    }
  }, []);

  const loadDepartamento = async (codigo) => {
    try {
      const result = await dbListObjects('departamento', 100, true);
      const dept = result.items.find(d => d.objectData.codigo === codigo);
      
      if (!dept) {
        window.location.href = 'departamentos.html';
        return;
      }
      
      setDepartamento(dept);
      await loadBens(dept.objectData.nome);
    } catch (error) {
      console.error('Error loading department:', error);
      window.location.href = 'departamentos.html';
    } finally {
      setLoading(false);
    }
  };

  const loadBens = async (deptNome) => {
    try {
      const result = await dbListObjects('bem', 1000, true);
      const deptBens = result.items.filter(b => b.objectData.departamento === deptNome);
      setBens(deptBens);
    } catch (error) {
      console.error('Error loading bens:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Header user={user} currentPage="departamentos" />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-gray-600">Carregando...</div>
        </div>
      </div>
    );
  }

  if (!user || !departamento) return null;

  const totalBens = bens.length;
  const disponiveis = bens.filter(b => b.objectData.status === 'disponivel').length;
  const emUso = bens.filter(b => b.objectData.status === 'em_uso').length;
  const manutencao = bens.filter(b => b.objectData.status === 'manutencao').length;
  const materiais = bens.filter(b => b.objectData.categoria === 'Material').length;
  const consumiveis = bens.filter(b => b.objectData.categoria === 'Consumível').length;

  const usuariosComBens = {};
  bens.forEach(bem => {
    if (bem.objectData.usuarioAtual) {
      if (!usuariosComBens[bem.objectData.usuarioAtual]) {
        usuariosComBens[bem.objectData.usuarioAtual] = {
          nome: bem.objectData.responsavelAtual || bem.objectData.usuarioAtual,
          bens: []
        };
      }
      usuariosComBens[bem.objectData.usuarioAtual].bens.push(bem);
    }
  });

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} currentPage="departamentos" />
      <main className="flex-grow p-6 max-w-7xl mx-auto w-full">
        <button
          onClick={() => window.location.href = 'departamentos.html'}
          className="flex items-center gap-2 bg-white text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-100 transition text-sm mb-6 shadow-sm"
        >
          <div className="icon-arrow-left text-lg"></div>
          <span>Voltar</span>
        </button>

        <div className="card mb-6">
          <div className="flex items-start gap-4">
            <div className="w-20 h-20 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
              <div className="icon-building text-4xl text-blue-600"></div>
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2">{departamento.objectData.nome}</h1>
              {departamento.objectData.descricao && (
                <p className="text-gray-600 mb-3">{departamento.objectData.descricao}</p>
              )}
              <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                {departamento.objectData.edificio && (
                  <div className="flex items-center gap-1">
                    <div className="icon-building-2 text-base"></div>
                    <span>{departamento.objectData.edificio}</span>
                  </div>
                )}
                {departamento.objectData.piso && (
                  <div className="flex items-center gap-1">
                    <div className="icon-layers text-base"></div>
                    <span>{departamento.objectData.piso}</span>
                  </div>
                )}
                {departamento.objectData.sala && (
                  <div className="flex items-center gap-1">
                    <div className="icon-door-open text-base"></div>
                    <span>{departamento.objectData.sala}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <StatCard icon="package" label="Total de Bens" value={totalBens} color="blue" />
          <StatCard icon="circle-check" label="Disponíveis" value={disponiveis} color="gray" />
          <StatCard icon="users" label="Em Uso" value={emUso} color="green" />
          <StatCard icon="wrench" label="Manutenção" value={manutencao} color="orange" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="card">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <div className="icon-chart-bar text-blue-600"></div>
              Por Categoria
            </h3>
            <div className="space-y-4">
              <CategoryBar label="Materiais" value={materiais} total={totalBens} color="blue" />
              <CategoryBar label="Consumíveis" value={consumiveis} total={totalBens} color="purple" />
            </div>
          </div>

          <div className="card">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <div className="icon-activity text-green-600"></div>
              Taxa de Utilização
            </h3>
            <div className="space-y-4">
              <CategoryBar label="Em Uso" value={emUso} total={totalBens} color="green" showPercent />
              <CategoryBar label="Disponíveis" value={disponiveis} total={totalBens} color="gray" showPercent />
              <CategoryBar label="Manutenção" value={manutencao} total={totalBens} color="orange" showPercent />
            </div>
          </div>
        </div>

        {Object.keys(usuariosComBens).length > 0 && (
          <div className="card mb-6">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <div className="icon-users text-indigo-600"></div>
              Bens em Uso por Usuário
              <span className="ml-auto bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-sm">
                {Object.keys(usuariosComBens).length} {Object.keys(usuariosComBens).length === 1 ? 'usuário' : 'usuários'}
              </span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(usuariosComBens).map(([email, data]) => (
                <UserBensCard key={email} email={email} nome={data.nome} bens={data.bens} />
              ))}
            </div>
          </div>
        )}

        <div className="card">
          <h2 className="text-xl font-bold mb-4">Todos os Bens</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left">Código</th>
                  <th className="px-4 py-3 text-left">Nome</th>
                  <th className="px-4 py-3 text-left">Categoria</th>
                  <th className="px-4 py-3 text-left">Status</th>
                  <th className="px-4 py-3 text-left">Usuário</th>
                </tr>
              </thead>
              <tbody>
                {bens.map(bem => (
                  <BemRow key={bem.objectId} bem={bem.objectData} />
                ))}
                {bens.length === 0 && (
                  <tr>
                    <td colSpan="5" className="px-4 py-8 text-center text-gray-500">
                      Nenhum bem encontrado neste departamento
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  const colors = {
    blue: 'bg-blue-50 border-blue-200 text-blue-600',
    green: 'bg-gray-50 border-gray-200 text-green-600',
    gray: 'bg-gray-50 border-gray-200 text-gray-600',
    orange: 'bg-orange-50 border-orange-200 text-orange-600'
  };

  return (
    <div className={`card ${colors[color]} border`}>
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
          <div className={`icon-${icon} text-xl ${colors[color].split(' ')[2]}`}></div>
        </div>
        <div>
          <p className="text-sm mb-1">{label}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
      </div>
    </div>
  );
}

function CategoryBar({ label, value, total, color, showPercent }) {
  const percentage = total > 0 ? (value / total) * 100 : 0;
  const colors = {
    blue: 'bg-blue-500',
    purple: 'bg-purple-500',
    green: 'bg-gray-500',
    gray: 'bg-gray-400',
    orange: 'bg-orange-500'
  };

  return (
    <div>
      <div className="flex justify-between mb-2 text-sm">
        <span className="text-gray-700">{label}</span>
        <span className="font-semibold">
          {value} {showPercent && `(${percentage.toFixed(1)}%)`}
        </span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-3">
        <div className={`${colors[color]} h-3 rounded-full transition-all`} style={{ width: `${percentage}%` }}></div>
      </div>
    </div>
  );
}

function UserBensCard({ email, nome, bens }) {
  const handleViewHistory = () => {
    window.location.href = `historico-usuario.html?email=${encodeURIComponent(email)}`;
  };

  return (
    <div className="border rounded-lg p-4 bg-gradient-to-br from-indigo-50 to-white hover:shadow-lg transition-shadow">
      <div className="flex items-center justify-between mb-3">
        <div className="flex-1">
          <button 
            onClick={handleViewHistory}
            className="font-semibold text-gray-800 hover:text-indigo-600 transition text-left"
          >
            {nome}
          </button>
          <p className="text-xs text-gray-500">{email}</p>
        </div>
        <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-sm font-medium">
          {bens.length} {bens.length === 1 ? 'bem' : 'bens'}
        </span>
      </div>
      <div className="space-y-2 mb-3">
        {bens.map(bem => (
          <div key={bem.objectId} className="flex items-center justify-between text-sm bg-white p-2 rounded shadow-sm">
            <span className="text-gray-700 font-medium">{bem.objectData.nome}</span>
            <span className="text-gray-500 text-xs">{bem.objectData.codigo}</span>
          </div>
        ))}
      </div>
      <button
        onClick={handleViewHistory}
        className="w-full bg-indigo-600 text-white text-sm py-2 rounded-lg hover:bg-indigo-700 transition flex items-center justify-center gap-2"
      >
        <div className="icon-history text-base"></div>
        <span>Ver Histórico Completo</span>
      </button>
    </div>
  );
}

function BemRow({ bem }) {
  const statusColors = {
    disponivel: 'bg-gray-100 text-gray-700',
    em_uso: 'bg-green-100 text-green-700',
    manutencao: 'bg-orange-100 text-orange-700'
  };

  const categoryColors = {
    Material: 'bg-blue-100 text-blue-700',
    'Consumível': 'bg-purple-100 text-purple-700'
  };

  return (
    <tr className="border-t hover:bg-gray-50">
      <td className="px-4 py-3 font-mono text-xs">{bem.codigo}</td>
      <td className="px-4 py-3">{bem.nome}</td>
      <td className="px-4 py-3">
        <span className={`px-2 py-1 rounded text-xs ${categoryColors[bem.categoria]}`}>
          {bem.categoria}
        </span>
      </td>
      <td className="px-4 py-3">
        <span className={`px-2 py-1 rounded text-xs ${statusColors[bem.status]}`}>
          {bem.status === 'disponivel' ? 'Disponível' : bem.status === 'em_uso' ? 'Em Uso' : 'Manutenção'}
        </span>
      </td>
      <td className="px-4 py-3 text-gray-600">{bem.responsavelAtual || '-'}</td>
    </tr>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<DepartamentoDetalhesApp />);

