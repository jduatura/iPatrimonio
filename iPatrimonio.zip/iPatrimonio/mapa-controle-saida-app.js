function MapaControleSaidaApp() {
  const [user, setUser] = React.useState(null);
  const [registros, setRegistros] = React.useState([]);
  const [showModal, setShowModal] = React.useState(false);
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertType, setAlertType] = React.useState('success');
  const [filters, setFilters] = React.useState({
    dataInicio: '',
    dataFim: '',
    departamento: ''
  });

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    const isAdministracao = currentUser.department === 'Administração';
    if (currentUser.role !== 'patrimonio' && !isAdministracao) {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadRegistros();
  }, []);

  const loadRegistros = async () => {
    try {
      const result = await dbListObjects('saida_material', 100);
      setRegistros(result.items);
    } catch (error) {
      console.error('Error loading registros:', error);
      setRegistros([]);
    }
  };

  const handleCreateRegistro = async (data) => {
    try {
      await dbCreateObject('saida_material', {
        ...data,
        registradoPor: user.name,
        createdAt: new Date().toISOString()
      });
      setAlertMessage('Registro criado com sucesso!');
      setAlertType('success');
      setShowAlert(true);
      setShowModal(false);
      loadRegistros();
    } catch (error) {
      setAlertMessage('Erro ao criar registro');
      setAlertType('error');
      setShowAlert(true);
    }
  };

  const handlePrint = () => {
    const style = document.createElement('style');
    style.textContent = '@page { margin: 0; } @media print { body { margin: 1cm; } }';
    document.head.appendChild(style);
    window.print();
    document.head.removeChild(style);
  };

  if (!user) return null;

  const filteredRegistros = registros.filter(reg => {
    const data = reg.objectData;
    if (filters.dataInicio && new Date(data.dataSaida) < new Date(filters.dataInicio)) return false;
    if (filters.dataFim && new Date(data.dataSaida) > new Date(filters.dataFim)) return false;
    if (filters.departamento && data.departamentoDestino !== filters.departamento) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      {showAlert && <Alert message={alertMessage} type={alertType} onClose={() => setShowAlert(false)} />}
      <main className="flex-grow p-3 sm:p-4 md:p-6">
        <div className="no-print mb-3 md:mb-4">
          <button onClick={() => window.location.href = 'dashboard.html'}
            className="flex items-center gap-1.5 md:gap-2 bg-gray-200 text-gray-700 px-2.5 md:px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-xs md:text-sm">
            <div className="icon-arrow-left text-base md:text-lg"></div>
            <span>Voltar</span>
          </button>
        </div>

        <div className="mb-3 md:mb-6">
          <h1 className="text-lg sm:text-xl md:text-3xl font-bold mb-2 md:mb-3">Mapa de Controle de Saída de Material</h1>
          <div className="no-print flex flex-col sm:flex-row gap-2 mt-2 md:mt-3">
            <button onClick={handlePrint}
              className="btn bg-blue-600 text-white hover:bg-blue-700 flex items-center justify-center gap-1.5 md:gap-2 text-xs sm:text-sm md:text-base">
              <div className="icon-printer text-base md:text-lg"></div>
              <span>Imprimir</span>
            </button>
            <button onClick={() => setShowModal(true)} className="btn btn-primary flex items-center justify-center gap-1.5 md:gap-2 text-xs sm:text-sm md:text-base">
              <div className="icon-plus text-base md:text-lg"></div>
              <span>Novo Registro</span>
            </button>
          </div>
        </div>

        <MapaTable registros={filteredRegistros} filters={filters} setFilters={setFilters} />
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
      {showModal && <RegistroModal onClose={() => setShowModal(false)} onSave={handleCreateRegistro} />}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<MapaControleSaidaApp />);

