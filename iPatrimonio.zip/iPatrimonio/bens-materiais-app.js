function BensMateriaisApp() {
  const [user, setUser] = React.useState(null);
  const [bens, setBens] = React.useState([]);
  const [searchTerm, setSearchTerm] = React.useState('');

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    if (currentUser.role !== 'admin' && currentUser.role !== 'patrimonio' && currentUser.role !== 'administracao' && currentUser.department !== 'Administração') {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadBens();
  }, []);

  const loadBens = async () => {
    try {
      const result = await dbListObjects('bem', 1000, true);
      const bensMateriais = result.items.filter(item => 
        item.objectData.categoria === 'Material'
      );
      setBens(bensMateriais);
    } catch (error) {
      console.error('Erro ao carregar bens materiais:', error);
    }
  };

  const filteredBens = bens.filter(bem =>
    bem.objectData.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bem.objectData.codigo?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!user) return null;

  return (
    <div>
      <Header user={user} />
      
      <div className="container mx-auto px-4 py-4 md:py-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800">Bens Materiais</h1>
          <button onClick={() => window.location.href = 'dashboard.html'} 
                  className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm">
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar</span>
          </button>
        </div>

        <div className="card mb-6">
          <div className="flex items-center space-x-2">
            <div className="icon-search text-xl text-gray-400"></div>
            <input
              type="text"
              placeholder="Pesquisar por nome ou código..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-field"
            />
          </div>
        </div>

        <div className="card">
          <h2 className="text-lg md:text-xl font-semibold mb-4">
            Total: {filteredBens.length} bens materiais
          </h2>
          
          {/* Desktop Table View */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left">Código</th>
                  <th className="px-4 py-3 text-left">Nome</th>
                  <th className="px-4 py-3 text-left">Quantidade</th>
                  <th className="px-4 py-3 text-left">Estado</th>
                  <th className="px-4 py-3 text-left">Localização</th>
                </tr>
              </thead>
              <tbody>
                {filteredBens.map((bem) => (
                  <tr key={bem.objectId} className="border-t hover:bg-gray-50">
                    <td className="px-4 py-3">{bem.objectData.codigo}</td>
                    <td className="px-4 py-3">{bem.objectData.nome}</td>
                    <td className="px-4 py-3">{bem.objectData.quantidade || 1}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded text-sm ${
                        bem.objectData.estadoConservacao === 'bom' ? 'bg-blue-50 text-[var(--primary-color)] border border-blue-200' :
                        bem.objectData.estadoConservacao === 'razoavel' ? 'bg-gray-50 text-gray-700 border border-gray-200' :
                        'bg-gray-200 text-gray-800 border border-gray-300'
                      }`}>
                        {bem.objectData.estadoConservacao === 'bom' ? 'Bom' :
                         bem.objectData.estadoConservacao === 'razoavel' ? 'Razoável' : 'Avariado'}
                      </span>
                    </td>
                    <td className="px-4 py-3">{bem.objectData.localizacao || 'N/A'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Card View */}
          <div className="md:hidden space-y-4">
            {filteredBens.map((bem) => (
              <div key={bem.objectId} className="border rounded-lg p-4 space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm text-gray-600">Código</p>
                    <p className="font-semibold">{bem.objectData.codigo}</p>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs ${
                    bem.objectData.estadoConservacao === 'bom' ? 'bg-blue-50 text-[var(--primary-color)] border border-blue-200' :
                    bem.objectData.estadoConservacao === 'razoavel' ? 'bg-gray-50 text-gray-700 border border-gray-200' :
                    'bg-gray-200 text-gray-800 border border-gray-300'
                  }`}>
                    {bem.objectData.estadoConservacao === 'bom' ? 'Bom' :
                     bem.objectData.estadoConservacao === 'razoavel' ? 'Razoável' : 'Avariado'}
                  </span>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Nome</p>
                  <p className="font-medium">{bem.objectData.nome}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Quantidade</p>
                    <p>{bem.objectData.quantidade || 1}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Localização</p>
                    <p>{bem.objectData.localizacao || 'N/A'}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<BensMateriaisApp />);

