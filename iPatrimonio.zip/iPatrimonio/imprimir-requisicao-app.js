function ImprimirRequisicaoApp() {
  const [requisicao, setRequisicao] = React.useState(null);

  React.useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const reqId = urlParams.get('id');
    if (reqId) {
      loadRequisicao(reqId);
    }
  }, []);

  const loadRequisicao = async (id) => {
    try {
      const req = await dbGetObject('requisicao', id);
      setRequisicao(req);
    } catch (error) {
      console.error('Error loading requisicao:', error);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (!requisicao) {
    return <div className="text-center py-8">Carregando...</div>;
  }

  const data = requisicao.objectData;
  const numeroRequisicao = requisicao.objectId.substring(0, 8).toUpperCase();

  return (
    <div className="max-w-4xl mx-auto">
      <div className="no-print mb-4 flex justify-end gap-2">
        <button onClick={handlePrint} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
          Imprimir
        </button>
        <button onClick={() => window.close()} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300">
          Fechar
        </button>
      </div>

      <div className="border-2 border-gray-800 p-8 print-page">
        <div className="flex items-start justify-between mb-6 border-b-2 border-gray-800 pb-4">
          <img src="assets/logo.png" alt="UCM Logo" className="h-20" />
          <div className="text-right">
            <h1 className="text-lg font-bold">UNIVERSIDADE CATÓLICA DE MOÇAMBIQUE</h1>
            <h2 className="text-md font-semibold">Faculdade de Direito</h2>
          </div>
        </div>

        <div className="text-center mb-6">
          <h3 className="text-xl font-bold uppercase">REQUISIÇÃO DE MATERIAL CONSUMÍVEL</h3>
          <p className="text-sm mt-2">N° de Ordem: <span className="font-bold">{numeroRequisicao}</span></p>
        </div>

        <div className="mb-6">
          <div className="border border-gray-800 p-2 inline-block">
            <p className="text-sm"><strong>Data:</strong> {data.dataRequisicao ? new Date(data.dataRequisicao).toLocaleDateString('pt-BR') : new Date(data.createdAt).toLocaleDateString('pt-BR')}</p>
          </div>
        </div>

        <div className="mb-6">
          <div className="border border-gray-800 p-3 mb-3">
            <p className="text-sm"><strong>Departamento Requisitante:</strong></p>
            <p className="font-semibold text-base mt-1">{data.departamento}</p>
          </div>

          <div className="border border-gray-800 p-3">
            <p className="text-sm"><strong>Beneficiário:</strong></p>
            <p className="font-semibold text-base mt-1">{data.beneficiario || data.solicitante}</p>
          </div>
        </div>

        <div className="mb-6">
          <p className="text-sm font-bold mb-2">Detalhes:</p>
          <div className="border-2 border-gray-800">
            <div className="grid grid-cols-12 bg-gray-100 border-b-2 border-gray-800 text-sm font-bold">
              <div className="col-span-10 p-3 border-r-2 border-gray-800">Descrição</div>
              <div className="col-span-2 p-3 text-center">Quantidade</div>
            </div>
            {data.itensDetalhados && data.itensDetalhados.length > 0 ? (
              data.itensDetalhados.map((item, idx) => (
                <div key={idx} className="grid grid-cols-12 border-b border-gray-400 text-sm" style={{minHeight: '40px'}}>
                  <div className="col-span-10 p-3 border-r-2 border-gray-800 flex items-center">{item.descricao} {item.unidade && `(${item.unidade})`}</div>
                  <div className="col-span-2 p-3 text-center flex items-center justify-center">{item.quantidade || '-'}</div>
                </div>
              ))
            ) : Array.isArray(data.bens) ? (
              data.bens.map((bem, idx) => (
                <div key={idx} className="grid grid-cols-12 border-b border-gray-400 text-sm" style={{minHeight: '40px'}}>
                  <div className="col-span-10 p-3 border-r-2 border-gray-800 flex items-center">{bem}</div>
                  <div className="col-span-2 p-3 text-center flex items-center justify-center">-</div>
                </div>
              ))
            ) : (
              <div className="grid grid-cols-12 border-b border-gray-400 text-sm" style={{minHeight: '40px'}}>
                <div className="col-span-10 p-3 border-r-2 border-gray-800 flex items-center">{data.bens}</div>
                <div className="col-span-2 p-3 text-center flex items-center justify-center">-</div>
              </div>
            )}
          </div>
        </div>

        {data.motivo && data.motivo.trim() !== '' && data.motivo.toLowerCase() !== 'sem descrição' && (
          <div className="mb-6 border border-gray-800 p-3">
            <p className="text-sm font-bold mb-2">Comentários:</p>
            <p className="text-sm">{data.motivo}</p>
          </div>
        )}

        <div className="grid grid-cols-3 gap-6 mt-12 text-sm">
          <div className="text-center">
            <div className="border-t-2 border-gray-800 pt-2 mt-16">
              <p className="font-semibold">Requisitado Por:</p>
              <p className="text-xs mt-1">(Coordenador do Dpto)</p>
            </div>
          </div>
          <div className="text-center">
            <div className="mt-12 mb-2">
              <p className="font-signature text-lg italic">Joyce Afonso Fortes</p>
            </div>
            <div className="border-t-2 border-gray-800 pt-2">
              <p className="font-semibold">Autorizado Por:</p>
              <p className="text-xs mt-1">(Administração)</p>
            </div>
          </div>
          <div className="text-center">
            <div className="mt-12 mb-2">
              <p className="font-signature text-lg italic">Maria Alice</p>
            </div>
            <div className="border-t-2 border-gray-800 pt-2">
              <p className="font-semibold">Entregue Por:</p>
              <p className="text-xs mt-1">(Patrimônio)</p>
            </div>
          </div>
        </div>

        <div className="mt-8 text-xs text-gray-600 text-center border-t border-gray-400 pt-3">
          <p>Av. 25 de Setembro, 618 - C.P. 48 - Nampula - Moçambique</p>
          <p>Tel: (+258) 26 21 61 77 | Fax: (+258) 26 21 57 65 | E-mail: fdir@ucm.ac.mz</p>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ImprimirRequisicaoApp />);

