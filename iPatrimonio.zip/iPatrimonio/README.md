﻿# iPatrimônio - Documentação Técnica

## Visão Geral
O iPatrimônio é um Sistema Integrado de Gestão de Patrimônio desenvolvido para a Universidade Católica de Moçambique - Faculdade de Direito (UCM-FADIR).
A aplicação foi construída visando fornecer uma interface web responsiva, amigável e segura, sem dependência de plataformas externas (totalmente local/hospedável remotamente).

## Arquitetura e Tecnologias (Open Source)
- **Frontend**: React 18, Tailwind CSS, Babel Standalone.
- **Ícones**: Lucide Icons.
- **Banco de Dados (Adapter)**: `utils/db-adapter.js` (Abstração que suporta LocalStorage nativo, expansível para Supabase/PostgreSQL).
- **Autenticação**: Gestão interna no `utils/auth.js` (Role-based Access Control - RBAC).

## Estrutura do Projeto
- `*.html` e `*-app.js`: Telas e lógicas de cada módulo (Dashboard, Bens, Requisições, Termos de Entrega).
- `utils/`: Scripts essenciais do sistema (Autenticação, Banco de Dados, Logging).
- `components/`: Componentes modulares reutilizáveis em React (Header, Modais, Notificações).
- `assets/`: Imagens locais e recursos estáticos.

## Segurança e Gestão de Permissões
- Apenas Administradores e Administração podem gerenciar bens e usuários.
- O histórico de ações fica registrado no módulo de Auditoria (`logs-auditoria-app.js`).
- Controle rigoroso de requisições, transferências e abates.

