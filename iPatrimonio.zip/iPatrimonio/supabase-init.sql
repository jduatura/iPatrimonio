-- ============================================================
-- iPatrimônio — Schema Completo do Supabase
-- Execute no SQL Editor do Supabase (pode executar múltiplas vezes)
-- ============================================================

-- ─────────────────────────────────────────────────────────────
-- 1. TABELAS PRINCIPAIS
-- ─────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS usuario (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bem (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS departamento (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS manutencao (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS requisicao (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS movimentacao (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS termo_entrega (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS abate (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notificacao (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS auditoria (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS historico (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mapa_controle_saida (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- 2. TABELAS ADICIONAIS (Relatórios, Depreciação, QR Code, etc.)
-- ─────────────────────────────────────────────────────────────

-- Depreciação de bens patrimoniais
CREATE TABLE IF NOT EXISTS depreciacao (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Relatórios gerados e guardados
CREATE TABLE IF NOT EXISTS relatorio (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- QR Codes gerados para bens
CREATE TABLE IF NOT EXISTS qr_code (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Histórico de alterações de senha
CREATE TABLE IF NOT EXISTS historico_senha (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Sessões / perfil activo
CREATE TABLE IF NOT EXISTS sessao (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Bens consumíveis e materiais
CREATE TABLE IF NOT EXISTS bem_consumivel (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bem_material (
  id TEXT PRIMARY KEY,
  object_data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- 3. DESATIVAR RLS (segurança gerida pela Netlify Function)
-- ─────────────────────────────────────────────────────────────

ALTER TABLE usuario             DISABLE ROW LEVEL SECURITY;
ALTER TABLE bem                 DISABLE ROW LEVEL SECURITY;
ALTER TABLE departamento        DISABLE ROW LEVEL SECURITY;
ALTER TABLE manutencao          DISABLE ROW LEVEL SECURITY;
ALTER TABLE requisicao          DISABLE ROW LEVEL SECURITY;
ALTER TABLE movimentacao        DISABLE ROW LEVEL SECURITY;
ALTER TABLE termo_entrega       DISABLE ROW LEVEL SECURITY;
ALTER TABLE abate               DISABLE ROW LEVEL SECURITY;
ALTER TABLE notificacao         DISABLE ROW LEVEL SECURITY;
ALTER TABLE auditoria           DISABLE ROW LEVEL SECURITY;
ALTER TABLE historico           DISABLE ROW LEVEL SECURITY;
ALTER TABLE mapa_controle_saida DISABLE ROW LEVEL SECURITY;
ALTER TABLE depreciacao         DISABLE ROW LEVEL SECURITY;
ALTER TABLE relatorio           DISABLE ROW LEVEL SECURITY;
ALTER TABLE qr_code             DISABLE ROW LEVEL SECURITY;
ALTER TABLE historico_senha     DISABLE ROW LEVEL SECURITY;
ALTER TABLE sessao              DISABLE ROW LEVEL SECURITY;
ALTER TABLE bem_consumivel      DISABLE ROW LEVEL SECURITY;
ALTER TABLE bem_material        DISABLE ROW LEVEL SECURITY;

-- ─────────────────────────────────────────────────────────────
-- 4. ÍNDICES DE PERFORMANCE
-- ─────────────────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_usuario_created          ON usuario             (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_bem_created              ON bem                 (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_departamento_created     ON departamento        (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_manutencao_created       ON manutencao          (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_requisicao_created       ON requisicao          (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_movimentacao_created     ON movimentacao        (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_termo_entrega_created    ON termo_entrega       (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_abate_created            ON abate               (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notificacao_created      ON notificacao         (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_auditoria_created        ON auditoria           (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_historico_created        ON historico           (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mapa_controle_created    ON mapa_controle_saida (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_depreciacao_created      ON depreciacao         (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_relatorio_created        ON relatorio           (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_qr_code_created          ON qr_code             (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_bem_consumivel_created   ON bem_consumivel      (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_bem_material_created     ON bem_material        (created_at DESC);

-- ─────────────────────────────────────────────────────────────
-- 5. ATIVAR REAL-TIME em todas as tabelas
-- ─────────────────────────────────────────────────────────────

ALTER PUBLICATION supabase_realtime ADD TABLE usuario;
ALTER PUBLICATION supabase_realtime ADD TABLE bem;
ALTER PUBLICATION supabase_realtime ADD TABLE departamento;
ALTER PUBLICATION supabase_realtime ADD TABLE manutencao;
ALTER PUBLICATION supabase_realtime ADD TABLE requisicao;
ALTER PUBLICATION supabase_realtime ADD TABLE movimentacao;
ALTER PUBLICATION supabase_realtime ADD TABLE termo_entrega;
ALTER PUBLICATION supabase_realtime ADD TABLE abate;
ALTER PUBLICATION supabase_realtime ADD TABLE notificacao;
ALTER PUBLICATION supabase_realtime ADD TABLE auditoria;
ALTER PUBLICATION supabase_realtime ADD TABLE historico;
ALTER PUBLICATION supabase_realtime ADD TABLE mapa_controle_saida;
ALTER PUBLICATION supabase_realtime ADD TABLE depreciacao;
ALTER PUBLICATION supabase_realtime ADD TABLE relatorio;
ALTER PUBLICATION supabase_realtime ADD TABLE qr_code;
ALTER PUBLICATION supabase_realtime ADD TABLE bem_consumivel;
ALTER PUBLICATION supabase_realtime ADD TABLE bem_material;

-- ─────────────────────────────────────────────────────────────
-- 6. UTILIZADOR ADMINISTRADOR DO SISTEMA
--    Username: juatura@ucm.ac.mz
--    Senha:    iPatrimonio2026!
-- ─────────────────────────────────────────────────────────────

INSERT INTO usuario (id, object_data, created_at, updated_at)
VALUES (
  'admin-juatura-001',
  jsonb_build_object(
    'name',           'Jassei Uatura',
    'username',       'juatura@ucm.ac.mz',
    'password',       'iPatrimonio2026!',
    'role',           'admin',
    'department',     'Administração',
    'numeroElemento', '000001',
    'ativo',          true
  ),
  NOW(),
  NOW()
)
ON CONFLICT (id) DO NOTHING;

-- ─────────────────────────────────────────────────────────────
-- 7. DEPARTAMENTOS PADRÃO DA UCM-FADIR
-- ─────────────────────────────────────────────────────────────

INSERT INTO departamento (id, object_data, created_at, updated_at) VALUES
('dept-001', '{"codigo":"DEPT001","nome":"Limpeza","localizacao":"Edifício Principal, Térreo","descricao":"Responsável pela limpeza e manutenção das instalações","ativo":true}', NOW(), NOW()),
('dept-002', '{"codigo":"DEPT002","nome":"Biblioteca","localizacao":"Edifício B, 1º Piso","descricao":"Gestão do acervo bibliográfico e atendimento aos estudantes","ativo":true}', NOW(), NOW()),
('dept-003', '{"codigo":"DEPT003","nome":"Secretaria","localizacao":"Edifício A, Sala 101","descricao":"Atendimento administrativo e gestão de documentos","ativo":true}', NOW(), NOW()),
('dept-004', '{"codigo":"DEPT004","nome":"Registro Acadêmico","localizacao":"Edifício A, Sala 102","descricao":"Gestão de matrículas e históricos escolares","ativo":true}', NOW(), NOW()),
('dept-005', '{"codigo":"DEPT005","nome":"Sala dos Professores","localizacao":"Edifício A, 2º Piso","descricao":"Espaço de trabalho e descanso para docentes","ativo":true}', NOW(), NOW()),
('dept-006', '{"codigo":"DEPT006","nome":"Informática","localizacao":"Edifício C, Sala 201","descricao":"Suporte técnico e gestão de sistemas","ativo":true}', NOW(), NOW()),
('dept-007', '{"codigo":"DEPT007","nome":"Controle de Crédito","localizacao":"Edifício A, Sala 103","descricao":"Gestão financeira e controle de pagamentos","ativo":true}', NOW(), NOW()),
('dept-008', '{"codigo":"DEPT008","nome":"Departamento de Patrimônio","localizacao":"Edifício A, Sala 104","descricao":"Gestão e controle do patrimônio institucional","ativo":true}', NOW(), NOW()),
('dept-009', '{"codigo":"DEPT009","nome":"Administração","localizacao":"Edifício A, Sala 105","descricao":"Gestão administrativa geral","ativo":true}', NOW(), NOW()),
('dept-010', '{"codigo":"DEPT010","nome":"Diretor","localizacao":"Edifício A, Sala 201","descricao":"Direção executiva da instituição","ativo":true}', NOW(), NOW()),
('dept-011', '{"codigo":"DEPT011","nome":"Pedagógico","localizacao":"Edifício A, 2º Piso","descricao":"Coordenação pedagógica e apoio acadêmico","ativo":true}', NOW(), NOW()),
('dept-012', '{"codigo":"DEPT012","nome":"Recursos Humanos","localizacao":"Edifício A, Sala 106","descricao":"Gestão de pessoal e benefícios","ativo":true}', NOW(), NOW()),
('dept-013', '{"codigo":"DEPT013","nome":"Relações Públicas","localizacao":"Edifício A, Sala 107","descricao":"Comunicação institucional e relações externas","ativo":true}', NOW(), NOW()),
('dept-014', '{"codigo":"DEPT014","nome":"Manutenção","localizacao":"Edifício Técnico, Sala T-01","descricao":"Equipa técnica de reparação e manutenção preventiva e correctiva","ativo":true}', NOW(), NOW())
ON CONFLICT (id) DO NOTHING;

-- ─────────────────────────────────────────────────────────────
-- Schema concluído.
-- Verifique em: Database → Tables → supabase_realtime
-- ─────────────────────────────────────────────────────────────
