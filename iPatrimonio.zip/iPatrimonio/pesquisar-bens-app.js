﻿function PesquisarBensApp() {
  const [user, setUser] = React.useState(null);
  const [bens, setBens] = React.useState([]);
  const [filteredBens, setFilteredBens] = React.useState([]);
  const [filters, setFilters] = React.useState({
    searchTerm: '',
    categoria: '',
    departamento: '',
    status: '',
    localizacao: ''
  });
  const [selectedBem, setSelectedBem] = React.useState(null);
  const [isScannerOpen, setIsScannerOpen] = React.useState(false);

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    const isAdministracao = currentUser.department === 'Administração' && currentUser.role === 'default';
    const isPatrimonio = currentUser.role === 'patrimonio';
    if (!isPatrimonio && !isAdministracao) {
      window.location.href = 'dashboard.html';
      return;
    }
    setUser(currentUser);
    loadBens();

    // Se houver parâmetro de busca na URL (ex: ?code=MAT-0001)
    const urlParams = new URLSearchParams(window.location.search);
    const codeParam = urlParams.get('code') || urlParams.get('codigo');
    if (codeParam) {
      setFilters(prev => ({ ...prev, searchTerm: codeParam }));
    }
  }, []);

  React.useEffect(() => {
    applyFilters();
  }, [filters, bens]);

  const loadBens = async () => {
    const result = await dbListObjects('bem', 1000);
    setBens(result.items);
    
    // Abrir o bem diretamente se houver match exato do código via URL
    const urlParams = new URLSearchParams(window.location.search);
    const codeParam = urlParams.get('code') || urlParams.get('codigo');
    if (codeParam && result.items) {
      const match = result.items.find(b => b.objectData.codigo === codeParam);
      if (match) {
        setSelectedBem(match.objectData);
      }
    }
  };

  const handleScanSuccess = (scannedData) => {
    setIsScannerOpen(false);
    if (scannedData) {
      let scannedCode = scannedData;
      try {
        const url = new URL(scannedData);
        scannedCode = url.searchParams.get('codigo') || url.searchParams.get('code') || scannedData;
      } catch (e) {
        // Not a URL, use as is
      }

      setFilters(prev => ({ ...prev, searchTerm: scannedCode }));
      const match = bens.find(b => b.objectData.codigo === scannedCode);
      if (match) {
        setSelectedBem(match.objectData);
      }
    }
  };

  const applyFilters = () => {
    let filtered = [...bens];

    if (filters.searchTerm.trim()) {
      const term = filters.searchTerm.toLowerCase();
      filtered = filtered.filter(bem => 
        bem.objectData.nome.toLowerCase().includes(term) ||
        bem.objectData.codigo.toLowerCase().includes(term) ||
        (bem.objectData.responsavelAtual && bem.objectData.responsavelAtual.toLowerCase().includes(term))
      );
    }

    if (filters.categoria) {
      filtered = filtered.filter(bem => bem.objectData.categoria === filters.categoria);
    }

    if (filters.departamento.trim()) {
      const depTerm = filters.departamento.toLowerCase();
      filtered = filtered.filter(bem => 
        bem.objectData.departamento && bem.objectData.departamento.toLowerCase().includes(depTerm)
      );
    }

    if (filters.status) {
      filtered = filtered.filter(bem => bem.objectData.status === filters.status);
    } else {
      // By default, hide ABATIDO unless explicitly searched for
      filtered = filtered.filter(bem => bem.objectData.status !== 'ABATIDO');
    }

    if (filters.localizacao) {
      filtered = filtered.filter(bem => 
        bem.objectData.localizacao && bem.objectData.localizacao.toLowerCase().includes(filters.localizacao.toLowerCase())
      );
    }

    setFilteredBens(filtered);
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({...prev, [key]: value}));
  };

  const clearFilters = () => {
    setFilters({
      searchTerm: '',
      categoria: '',
      departamento: '',
      status: '',
      localizacao: ''
    });
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      <main className="flex-grow p-6">
        <button
          onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4"
        >
          <div className="icon-arrow-left text-lg"></div>
          <span>Voltar</span>
        </button>
        
        <h1 className="text-3xl font-bold mb-6">Pesquisar Bens</h1>
        
        <FilterPanel 
          filters={filters} 
          onFilterChange={handleFilterChange}
          onClearFilters={clearFilters}
          onOpenScanner={() => setIsScannerOpen(true)}
        />

        <div className="mb-4 text-gray-600">
          {filteredBens.length} {filteredBens.length === 1 ? 'bem encontrado' : 'bens encontrados'}
        </div>

        <BensList bens={filteredBens} onViewDetails={setSelectedBem} />
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
      {selectedBem && <BemDetailCard bem={selectedBem} onClose={() => setSelectedBem(null)} />}
      <QRScannerModal 
        isOpen={isScannerOpen} 
        onClose={() => setIsScannerOpen(false)} 
        onScanSuccess={handleScanSuccess} 
      />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<PesquisarBensApp />);