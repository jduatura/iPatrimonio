function ImprimirTermoApp() {
  const [termo, setTermo] = React.useState(null);
  const [requisicao, setRequisicao] = React.useState(null);
  const [userNames, setUserNames] = React.useState({});
  const [loading, setLoading] = React.useState(true);
  const [confirmado, setConfirmado] = React.useState(false);

  React.useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const termoId = urlParams.get('id');
    if (termoId) {
      loadTermo(termoId);
    }
  }, []);

  const loadTermo = async (id) => {
    try {
      setLoading(true);
      const t = await dbGetObject('termo_entrega', id);
      
      const allUsers = await dbListObjects('usuario', 100, true);
      
      const names = {};
      const emails = [
        t.objectData.responsavelEntrega,
        t.objectData.responsavelRecebimento,
        t.objectData.createdBy
      ];
      
      for (const email of emails) {
        if (email) {
          const user = allUsers.items.find(u => u.objectData.email === email);
          if (user && user.objectData.nome) {
            names[email] = {
              full: user.objectData.nome,
              first: user.objectData.nome.split(' ')[0]
            };
          } else {
            names[email] = {
              full: email.split('@')[0],
              first: email.split('@')[0]
            };
          }
        }
      }
      
      let reqData = null;
      if (t.objectData.requisicaoId) {
        try {
          const reqObj = await dbGetObject('requisicao', t.objectData.requisicaoId);
          reqData = reqObj.objectData;
        } catch (err) {
          console.error('Error loading attached requisicao:', err);
        }
      }
      
      setRequisicao(reqData);
      setUserNames(names);
      // Determine the real patrimônio user who forwarded this requisição.
      // Priority: requisicao.encaminhadaPor → termo.responsavelEntrega → fallback
      const encaminhadoPor = (reqData && reqData.encaminhadaPor) || t.objectData.responsavelEntrega || 'Património FADIR';
      setTermo({ ...t, _encaminhadoPor: encaminhadoPor });
      setConfirmado(!!t.objectData.confirmado);
      setLoading(false);
    } catch (error) {
      console.error('Error loading termo:', error);
      setLoading(false);
    }
  };

  const handleConfirmar = async () => {
    try {
      setConfirmado(true);
      if (termo && termo.id) {
        await dbUpdateObject('termo_entrega', termo.id, {
          ...termo.objectData,
          confirmado: true,
          confirmadoEm: new Date().toISOString()
        });
      }
    } catch (e) {
      console.error('Erro ao confirmar recebimento:', e);
      setConfirmado(true);
    }
  };

  if (loading || !termo) {
    return <div className="text-center py-8">Carregando...</div>;
  }

  const data = termo.objectData;
  const currentUser = typeof getCurrentUser === 'function' ? getCurrentUser() : null;
  const currentUserName = (currentUser?.name || '').trim().toLowerCase();
  const currentUserUsername = (currentUser?.username || '').trim().toLowerCase();
  const currentUserEmail = (currentUser?.email || '').trim().toLowerCase();

  const solicitanteStr = ((requisicao?.solicitante || data.responsavelRecebimento) || '').trim().toLowerCase();
  const recebimentoStr = (data.responsavelRecebimento || '').trim().toLowerCase();
  const receiverFullName = (userNames[data.responsavelRecebimento]?.full || '').trim().toLowerCase();

  const isRequisitante = Boolean(
    currentUser && (
      (currentUserName && (solicitanteStr === currentUserName || recebimentoStr === currentUserName || receiverFullName === currentUserName)) ||
      (currentUserUsername && (solicitanteStr === currentUserUsername || recebimentoStr === currentUserUsername)) ||
      (currentUserEmail && (solicitanteStr === currentUserEmail || recebimentoStr === currentUserEmail))
    )
  );

  return (
    <div className="max-w-4xl mx-auto py-6 px-4">
      <div className="no-print mb-6 flex justify-between items-center bg-gray-100 p-3 rounded-lg border">
        <span className="text-sm font-semibold text-gray-700">Documento Oficial - Termo de Entrega N° {data.numeroTermo}</span>
        <div className="flex gap-2 items-center">
          {!confirmado && isRequisitante && (
            <button
              onClick={handleConfirmar}
              className="bg-[var(--primary-color)] text-white px-4 py-2 rounded-lg font-medium text-sm hover:bg-blue-800 transition flex items-center shadow"
            >
              Confirmo que recebi os bens requisitados
            </button>
          )}
          {!confirmado && !isRequisitante && (
            <span className="text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-lg flex items-center gap-1 shadow-sm">
              <span>⏳</span> Aguardando confirmação do requisitante
            </span>
          )}
          <button
            onClick={() => {
              if (!confirmado) {
                alert('O termo não pode ser emitido antes da confirmação do requisitante.');
                return;
              }
              window.print();
            }}
            disabled={!confirmado}
            className={`px-4 py-2 rounded-lg font-medium text-sm transition flex items-center gap-1.5 shadow ${confirmado ? 'bg-[var(--primary-color)] text-white hover:bg-blue-800' : 'bg-gray-300 text-gray-500 cursor-not-allowed'}`}
          >
            <span>🖨️</span> Imprimir Documento
          </button>
          <button
            onClick={() => window.close()}
            className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg font-medium text-sm hover:bg-gray-300 transition"
          >
            Fechar
          </button>
        </div>
      </div>

      <div className="border-2 border-gray-800 p-8 sm:p-10 bg-white rounded shadow-sm font-serif">
        {/* Cabecalho Institucional */}
        <div className="flex items-center justify-between border-b-2 border-gray-800 pb-4 mb-6">
          <img 
            src="assets/logo.png" 
            alt="UCM Logo" 
            className="h-16 w-auto object-contain" 
          />
          <div className="text-right">
            <h1 className="text-base font-bold tracking-tight">UNIVERSIDADE CATÓLICA DE MOÇAMBIQUE</h1>
            <h2 className="text-sm font-semibold text-gray-800">Faculdade de Direito - FADIR</h2>
            <p className="text-xs text-gray-600">Departamento de Património & Administração</p>
          </div>
        </div>

        <div className="text-center mb-8">
          <h3 className="text-xl font-bold uppercase tracking-wider underline">TERMO DE ENTREGA E RECEBIMENTO</h3>
          <p className="text-sm font-mono mt-1 font-semibold">N.° {data.numeroTermo} | Data: {new Date(data.dataEntrega).toLocaleDateString('pt-BR')}</p>
        </div>

        {/* Secção 1: Identificação do Destino */}
        <div className="border border-gray-400 p-2.5 sm:p-3 rounded mb-4">
          <h3 className="font-bold border-b border-gray-300 pb-1 mb-2 text-[11px] sm:text-xs uppercase bg-gray-100 p-1">
            1. Dados de Destino
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <p><strong>Departamento Solicitante:</strong> {data.departamento}</p>
            <p><strong>Local de Destino:</strong> {data.localDestino}</p>
            {requisicao && (
              <>
                <p><strong>N.º Requisição Origem:</strong> {requisicao.numeroRequisicao}</p>
                <p><strong>Urgência da Requisição:</strong> {(requisicao.urgencia || 'Normal').toUpperCase()}</p>
              </>
            )}
          </div>
        </div>

        {/* Secção 2: Relação de Bens Entregues */}
        <div className="border border-gray-400 p-2.5 sm:p-3 rounded mb-4">
          <h3 className="font-bold border-b border-gray-300 pb-1 mb-2 text-[11px] sm:text-xs uppercase bg-gray-100 p-1">
            2. Relação de Bens Patrimoniais Entregues
          </h3>
          {requisicao && requisicao.itensDetalhados && requisicao.itensDetalhados.length > 0 ? (
            <table className="w-full text-left text-xs mb-2 border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-1 font-semibold">Qtd</th>
                  <th className="border border-gray-300 p-1 font-semibold">Descrição do Bem / Material</th>
                  <th className="border border-gray-300 p-1 font-semibold">Observação</th>
                </tr>
              </thead>
              <tbody>
                {requisicao.itensDetalhados.map((item, idx) => (
                  <tr key={idx}>
                    <td className="border border-gray-300 p-1 text-center w-12">{item.quantidade}</td>
                    <td className="border border-gray-300 p-1">{item.nome || item.descricao}</td>
                    <td className="border border-gray-300 p-1 text-gray-500 italic">Entregue</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="text-xs text-gray-700 p-2 border border-dashed border-gray-300 text-center mb-2">
              <p>Os itens específicos desta entrega encontram-se descritos no anexo de movimentação ou mapa de carga.</p>
            </div>
          )}
          
          <p className="pt-2 text-gray-800 text-xs text-justify">
            <strong>Declaração Oficial:</strong> Por este termo de entrega e recebimento, declara-se que os bens patrimoniais/materiais acima relacionados (ou descritos em anexo) foram devidamente inspecionados, entregues pelo Departamento de Patrimônio e recebidos pelo solicitante em plenas condições de uso e funcionamento.
          </p>
        </div>

        {/* Quadro de Assinaturas Triplo Oficial */}
        <h3 className="font-bold border-b border-gray-300 pb-1 mt-6 mb-4 text-[11px] sm:text-xs uppercase bg-gray-100 p-1 rounded border border-gray-400">
          3. Assinaturas e Vistos Oficiais
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 text-xs font-sans">
          {/* 1. Aprovado Por (Administração) */}
          <div className="border border-gray-300 rounded-lg bg-gray-50 flex flex-col justify-between overflow-hidden shadow-sm">
            <div className="bg-gray-600 px-4 py-2 flex items-center justify-center">
              <p className="font-bold text-white uppercase text-[10px] tracking-widest">APROVADO POR (Administração)</p>
            </div>
            <div className="p-4 flex-1 flex flex-col space-y-4">
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-500 uppercase tracking-wider mb-0.5">Nome</span>
                <div className="border-b border-dashed border-gray-400 pb-1 font-medium text-gray-800 text-[12px]">
                  {data.aprovadoPor || data.registradoPor || 'Administração FADIR'}
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-500 uppercase tracking-wider mb-0.5">Cargo</span>
                <div className="border-b border-dashed border-gray-400 pb-1 font-medium text-gray-800 text-[12px]">
                  Administradora
                </div>
              </div>
            </div>
            <div className="px-4 pb-4 mt-2 flex flex-col items-center">
              <div className="w-full border-t border-gray-800 pt-2 text-center">
                <p className="font-signature text-2xl" style={{ color: '#374151', fontFamily: "'Dancing Script', 'Brush Script MT', cursive", minHeight: '32px' }}>
                  {data.aprovadoPor || data.registradoPor || 'Administração FADIR'}
                </p>
                <p className="text-[10px] text-gray-600 font-bold uppercase tracking-wider mt-1">Assinatura & Despacho</p>
              </div>
            </div>
          </div>

          {/* 2. Entregue Por (Patrimônio — quem encaminhou a requisição) */}
          <div className="border border-gray-300 rounded-lg bg-gray-50 flex flex-col justify-between overflow-hidden shadow-sm">
            <div className="bg-gray-700 px-4 py-2 flex items-center justify-center">
              <p className="font-bold text-white uppercase text-[10px] tracking-widest">ENTREGUE POR (Património)</p>
            </div>
            <div className="p-4 flex-1 flex flex-col space-y-4">
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-500 uppercase tracking-wider mb-0.5">Nome</span>
                <div className="border-b border-dashed border-gray-400 pb-1 font-medium text-gray-800 text-[12px]">
                  {termo._encaminhadoPor || 'Património FADIR'}
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-500 uppercase tracking-wider mb-0.5">Cargo</span>
                <div className="border-b border-dashed border-gray-400 pb-1 font-medium text-gray-800 text-[12px]">
                  Administrador Patrimonio
                </div>
              </div>
            </div>
            <div className="px-4 pb-4 mt-2 flex flex-col items-center">
              <div className="w-full border-t border-gray-800 pt-2 text-center">
                <p className="font-signature text-2xl" style={{ color: '#374151', fontFamily: "'Dancing Script', 'Brush Script MT', cursive", minHeight: '32px' }}>
                  {termo._encaminhadoPor || 'Património FADIR'}
                </p>
                <p className="text-[10px] text-gray-600 font-bold uppercase tracking-wider mt-1">Assinatura & Entrega</p>
              </div>
            </div>
          </div>

          {/* 3. Recebido Por (Departamento solicitante) */}
          <div className="border border-gray-300 rounded-lg bg-gray-50 flex flex-col justify-between overflow-hidden shadow-sm">
            <div className="bg-gray-800 px-4 py-2 flex items-center justify-center">
              <p className="font-bold text-white uppercase text-[10px] tracking-widest">RECEBIDO POR (Departamento)</p>
            </div>
            <div className="p-4 flex-1 flex flex-col space-y-4">
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-500 uppercase tracking-wider mb-0.5">Nome</span>
                <div className="border-b border-dashed border-gray-400 pb-1 font-medium text-gray-800 text-[12px]">
                  {userNames[data.responsavelRecebimento]?.full || data.responsavelRecebimento}
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-500 uppercase tracking-wider mb-0.5">Cargo</span>
                <div className="border-b border-dashed border-gray-400 pb-1 font-medium text-gray-800 text-[12px] truncate" title={`Responsável do Departamento de ${data.departamento}`}>
                  Responsável do Departamento de {data.departamento}
                </div>
              </div>
            </div>
            <div className="px-4 pb-4 mt-2 flex flex-col items-center">
              <div className="w-full border-t border-gray-800 pt-2 text-center">
                <p className="font-signature text-2xl" style={{ color: '#374151', fontFamily: "'Dancing Script', 'Brush Script MT', cursive", minHeight: '32px' }}>
                  {confirmado ? (userNames[data.responsavelRecebimento]?.full || data.responsavelRecebimento) : ''}
                </p>
                <p className="text-[10px] text-gray-600 font-bold uppercase tracking-wider mt-1">
                  {confirmado ? 'Assinatura & Recebimento' : 'Assinatura & Recebimento (Pendente)'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {data.observacoes && (
          <div className="text-xs border-t pt-3 mt-4 text-gray-700 font-sans">
            <p className="font-semibold mb-1 text-gray-800 uppercase">Observações Adicionais:</p>
            <p className="bg-gray-50 p-2.5 rounded border">{data.observacoes}</p>
          </div>
        )}

        <div className="mt-10 pt-4 border-t text-[11px] text-gray-500 text-center font-sans space-y-0.5">
          <p className="font-bold text-gray-700">UNIVERSIDADE CATÓLICA DE MOÇAMBIQUE - FACULDADE DE DIREITO</p>
          <p>Sistema Integrado de Gestão de Património (iPatrimônio) | Documento Processado Digitalmente</p>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ImprimirTermoApp />);

