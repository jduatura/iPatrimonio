function EstatisticasApp() {
  const [user, setUser] = React.useState(null);
  const [stats, setStats] = React.useState(null);

  React.useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      window.location.href = 'login.html';
      return;
    }
    setUser(currentUser);
    loadStats();
  }, []);

  const loadStats = async () => {
    const bens = await dbListObjects('bem', 100);
    const requisicoes = await dbListObjects('requisicao', 100);
    
    setStats({
      totalBens: bens.items.length,
      bensDisponiveis: bens.items.filter(b => b.objectData.status === 'disponivel').length,
      totalRequisicoes: requisicoes.items.length,
      requisicoesAprovadas: requisicoes.items.filter(r => r.objectData.status === 'aprovada').length,
      requisicoesPendentes: requisicoes.items.filter(r => r.objectData.status === 'pendente').length,
      requisicoesRejeitadas: requisicoes.items.filter(r => r.objectData.status === 'rejeitada').length,
      requisicoesPessoais: requisicoes.items.filter(r => r.objectData.tipo === 'pessoal').length,
      requisicoesDepartamento: requisicoes.items.filter(r => r.objectData.tipo === 'departamento').length
    });
  };

  if (!user || !stats) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header user={user} />
      <main className="flex-grow p-6">
        <button onClick={() => window.location.href = 'dashboard.html'}
          className="flex items-center gap-2 bg-gray-200 text-gray-700 px-3 py-1.5 rounded-lg font-medium hover:bg-gray-300 transition text-sm mb-4">
          <div className="icon-arrow-left text-lg"></div>
          <span>Voltar</span>
        </button>
        <h1 className="text-3xl font-bold mb-6">Estatísticas do Sistema</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <StatsCard title="Bens" data={[
            { label: 'Total', value: stats.totalBens },
            { label: 'Disponíveis', value: stats.bensDisponiveis }
          ]} />
          <StatsCard title="Requisições" data={[
            { label: 'Total', value: stats.totalRequisicoes },
            { label: 'Aprovadas', value: stats.requisicoesAprovadas },
            { label: 'Pendentes', value: stats.requisicoesPendentes },
            { label: 'Rejeitadas', value: stats.requisicoesRejeitadas }
          ]} />
          <StatsCard title="Tipo de Requisição" data={[
            { label: 'Pessoais', value: stats.requisicoesPessoais },
            { label: 'Departamento', value: stats.requisicoesDepartamento }
          ]} />
        </div>
      </main>
      <footer className="bg-white py-3 text-center text-gray-500 text-sm border-t">
        © 2026 - iPatrimônio | UCM-FADIR
      </footer>
    </div>
  );
}

function StatsCard({ title, data }) {
  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-4">{title}</h2>
      <div className="space-y-3">
        {data.map((item, idx) => (
          <div key={idx} className="flex justify-between items-center py-2 border-b">
            <span className="text-gray-600">{item.label}</span>
            <span className="text-2xl font-bold text-[var(--primary-color)]">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<EstatisticasApp />);

